package com.example.assistvolume

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

/**
 * A good-looking round / rounded-square button with a hand-drawn icon.
 * style: 0 Solid, 1 Glass, 2 Neon, 3 Gradient, 4 Outline
 */
class StyledButton(
    ctx: Context,
    private val kind: Int,
    private val style: Int,
    private val shape: Int,
    private val accent: Int,
    private val iconScale: Float,
    private val design: Int = 0
) : View(ctx) {

    companion object {
        const val PLUS = 0
        const val MINUS = 1
        const val POWER = 2
        const val SLIDERS = 3
        const val LOCK = 4
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val ic = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        if (style == 2 || style == 5) setLayerType(LAYER_TYPE_SOFTWARE, null) // glow and soft shadow
    }

    private fun contrast(c: Int): Int {
        val l = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
        return if (l > 150) 0xFF1B1B1F.toInt() else Color.WHITE
    }

    private fun shiftHue(c: Int, deg: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[0] = (hsv[0] + deg) % 360f
        hsv[1] = (hsv[1] * 0.9f).coerceAtLeast(0.35f)
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val inset = context.dp(if (style == 5) 5 else 3).toFloat()
        val r = RectF(inset, inset, w - inset, h - inset)
        val corner = if (shape == 0) r.width() / 2 else r.width() * 0.28f
        val sw = context.dp(2).toFloat()
        var iconColor = Color.WHITE

        when (style) {
            0 -> { // Solid
                fill.shader = null
                fill.color = accent
                c.drawRoundRect(r, corner, corner, fill)
                iconColor = contrast(accent)
            }
            1 -> { // Glass
                fill.shader = null
                fill.color = 0x66000000
                c.drawRoundRect(r, corner, corner, fill)
                fill.shader = LinearGradient(0f, r.top, 0f, r.bottom, 0x66FFFFFF, 0x1AFFFFFF, Shader.TileMode.CLAMP)
                c.drawRoundRect(r, corner, corner, fill)
                fill.shader = null
                line.shader = null
                line.strokeWidth = context.dp(1).toFloat() * 1.5f
                line.color = alpha(accent, 0xCC)
                c.drawRoundRect(r, corner, corner, line)
                iconColor = accent
            }
            2 -> { // Neon
                fill.shader = null
                fill.color = 0xDD0B0F1A.toInt()
                c.drawRoundRect(r, corner, corner, fill)
                line.shader = null
                line.strokeWidth = sw
                line.color = accent
                line.maskFilter = BlurMaskFilter(context.dp(4).toFloat(), BlurMaskFilter.Blur.NORMAL)
                c.drawRoundRect(r, corner, corner, line)
                line.maskFilter = null
                c.drawRoundRect(r, corner, corner, line)
                iconColor = accent
            }
            3 -> { // Gradient
                fill.shader = LinearGradient(
                    r.left, r.top, r.right, r.bottom,
                    accent, shiftHue(accent, 55f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(r, corner, corner, fill)
                fill.shader = null
                // soft top highlight
                fill.shader = LinearGradient(0f, r.top, 0f, r.centerY(), 0x44FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
                c.drawRoundRect(r, corner, corner, fill)
                fill.shader = null
                iconColor = Color.WHITE
            }
            5 -> { // Crystal Glass
                // soft shadow
                fill.shader = null
                fill.color = 0x45000000
                fill.maskFilter = BlurMaskFilter(context.dp(3).toFloat(), BlurMaskFilter.Blur.NORMAL)
                c.drawRoundRect(RectF(r.left, r.top + context.dp(2), r.right, r.bottom + context.dp(2)), corner, corner, fill)
                fill.maskFilter = null
                // frosted body: smoke + white sheen
                fill.color = 0x30000000
                c.drawRoundRect(r, corner, corner, fill)
                fill.shader = LinearGradient(0f, r.top, 0f, r.bottom, 0x59FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP)
                c.drawRoundRect(r, corner, corner, fill)
                fill.shader = null
                if (accent != Color.WHITE) {
                    fill.color = alpha(accent, 0x55)
                    c.drawRoundRect(r, corner, corner, fill)
                }
                val clip = Path().apply { addRoundRect(r, corner, corner, Path.Direction.CW) }
                c.save()
                c.clipPath(clip)
                fill.shader = RadialGradient(r.left + r.width() * 0.30f, r.top + r.height() * 0.10f, r.width() * 0.80f,
                    0xA0FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
                c.drawRect(r, fill)
                fill.shader = LinearGradient(0f, r.bottom - r.height() * 0.35f, 0f, r.bottom, 0x00FFFFFF, 0x38FFFFFF, Shader.TileMode.CLAMP)
                c.drawRect(r, fill)
                fill.shader = null
                c.restore()
                // bright refracting rim
                val sw5 = context.dp(1).toFloat() * 1.3f
                line.maskFilter = null
                line.strokeWidth = sw5
                line.shader = LinearGradient(r.left, r.top, r.right, r.bottom,
                    intArrayOf(0xF2FFFFFF.toInt(), 0x28FFFFFF, 0x85FFFFFF.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                val ri = RectF(r); ri.inset(sw5 / 2f, sw5 / 2f)
                c.drawRoundRect(ri, corner - sw5 / 2f, corner - sw5 / 2f, line)
                line.shader = null
                iconColor = Color.WHITE
            }
            else -> { // Outline
                fill.shader = null
                fill.color = 0x55000000
                c.drawRoundRect(r, corner, corner, fill)
                line.shader = null
                line.maskFilter = null
                line.strokeWidth = sw
                line.color = accent
                c.drawRoundRect(r, corner, corner, line)
                iconColor = accent
            }
        }
        drawIcon(c, w / 2, h / 2, min(w, h), iconColor)
    }

    private fun drawIcon(c: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        val rad = size * iconScale / 2f
        ic.color = color
        ic.strokeWidth = size * 0.085f
        fill.shader = null
        fill.color = color
        when (kind) {
            PLUS -> {
                c.drawLine(cx - rad, cy, cx + rad, cy, ic)
                c.drawLine(cx, cy - rad, cx, cy + rad, ic)
            }
            MINUS -> c.drawLine(cx - rad, cy, cx + rad, cy, ic)
            POWER -> {
                val a = rad * 0.88f
                c.drawArc(RectF(cx - a, cy - a, cx + a, cy + a), -50f, 280f, false, ic)
                c.drawLine(cx, cy - rad, cx, cy - rad * 0.05f, ic)
            }
            LOCK -> SvgIcon.draw(c, SvgIcon.LOCK, cx, cy, rad * 2.0f, color, 2)
            else -> if (design > 0) {
                SvgIcon.draw(c, Sliders.btnPaths[design], cx, cy, rad * 2.1f, color, 2)
            } else { // SLIDERS (mixer lines)
                val xs = floatArrayOf(cx - rad * 0.8f, cx, cx + rad * 0.8f)
                val ys = floatArrayOf(cy - rad * 0.35f, cy + rad * 0.4f, cy - rad * 0.05f)
                for (i in xs.indices) {
                    c.drawLine(xs[i], cy - rad, xs[i], cy + rad, ic)
                    c.drawCircle(xs[i], ys[i], rad * 0.26f, fill)
                }
            }
        }
    }
}
