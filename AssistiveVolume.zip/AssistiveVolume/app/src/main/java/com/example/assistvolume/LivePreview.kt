package com.example.assistvolume

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A miniature phone screen that shows the floating shortcut exactly as it will look,
 * and replays how it opens, closes, hides and fades, using the current settings.
 * Every setting change calls update() / replay() / demoLock(), so changes are visible instantly.
 */
class LivePreview(ctx: Context, private val p: Prefs) : FrameLayout(ctx) {

    private val handler = Handler(Looper.getMainLooper())
    private var gen = 0
    private var group: LinearLayout? = null
    private var openPanel: View? = null
    private var openPanelW = 0
    private var openBase = 1f
    private var autoHides = false

    init {
        val r = context.dp(18).toFloat()
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#3A2F9B"), Color.parseColor("#1F5FD0"), Color.parseColor("#B23A84"))
        ).apply { cornerRadius = r }
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        clipToOutline = true
        setOnClickListener { replay() }
    }

    private fun d(v: Int) = context.dp(v)

    // ------------------------------------------------------------------ lifecycle
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w > 0 && h > 0) update()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (width > 0 && height > 0) update()
    }

    override fun onDetachedFromWindow() {
        gen++
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ public API
    /** Rebuild with the latest settings and restart the open/close loop after a short pause. */
    fun update() {
        rebuild()
        val my = gen
        handler.postDelayed({ if (my == gen && isAttachedToWindow) loop() }, 1200)
    }

    /** Rebuild, then play close and open once so the chosen animation can be seen. */
    fun replay() {
        rebuild()
        val my = gen
        val panel = openPanel
        handler.postDelayed({
            if (my != gen || !isAttachedToWindow) return@postDelayed
            if (panel == null) { loop(); return@postDelayed }
            anim(panel, false, openBase, openPanelW) {
                anim(panel, true, openBase, openPanelW) { if (my == gen) loop() }
            }
        }, 250)
    }

    /** Show what the screen looks like while the touch lock (kids mode) is on. */
    fun demoLock() {
        rebuild()
        val g = group ?: return
        val my = gen
        val right = p.side == 1
        val size = d(24) + d(p.btnSize) * 4 / 5
        val dimAlpha = intArrayOf(0, 0x30, 0x99)[p.lockDim.coerceIn(0, 2)]
        val layer = FrameLayout(context)
        layer.addView(View(context).apply { setBackgroundColor(Color.argb(dimAlpha, 0, 0, 0)) },
            FrameLayout.LayoutParams(MATCH, MATCH))
        val lockBtn = StyledButton(context, StyledButton.LOCK, p.btnStyle, p.btnShape, 0xFFFFB020.toInt(), p.iconScale / 100f)
        lockBtn.alpha = 1f - p.btnTransparency / 100f
        layer.addView(lockBtn, FrameLayout.LayoutParams(size, size, (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL).apply {
            if (right) marginEnd = d(10) else marginStart = d(10)
        })
        val msg = "\uD83D\uDD12 Touch locked\n" +
            (if (p.lockSafeUnlock) "Press and hold the lock button to unlock" else "Double-tap the lock button to unlock")
        layer.addView(TextView(context).apply {
            text = msg; setTextColor(Color.WHITE); textSize = 12.5f; gravity = Gravity.CENTER
            setPadding(d(14), d(10), d(14), d(10))
            background = GradientDrawable().apply { setColor(0xE6202534.toInt()); cornerRadius = d(16).toFloat() }
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        g.visibility = View.INVISIBLE
        addView(layer, FrameLayout.LayoutParams(MATCH, MATCH))
        handler.postDelayed({ if (my == gen && isAttachedToWindow) update() }, 3800)
    }

    // ------------------------------------------------------------------ building
    private fun btn(kind: Int, accent: Int, design: Int): StyledButton =
        StyledButton(context, kind, p.btnStyle, p.btnShape, accent, p.iconScale / 100f, design)
            .apply { alpha = 1f - p.btnTransparency / 100f }

    private fun slider(id: Int, fr: Float): VolumeSliderView {
        val v = VolumeSliderView(context, p.style, id) { }
        val auto = p.sliderAccent()
        val lc = p.levelColor(id)
        v.accent = if (lc == 0) auto else lc
        v.alpha = 1f - p.sliderTransparency / 100f
        v.showIcon = p.sliderIcons
        v.iconStyle = p.sliderIconStyle
        v.iconTop = p.sliderIconPos == 1
        v.iconSizePct = p.sliderIconSize
        v.showPercent = p.sliderPercent
        v.customLevel = p.lvMode != 0
        v.fillAlpha = p.lvAlpha * 255 / 100
        v.trackAlpha = p.lvTrack * 255 / 100
        v.iconOverride = when (p.iconColorMode) { 1 -> Color.WHITE; 2 -> 0xFF2A2F3A.toInt(); else -> null }
        v.fraction = fr
        return v
    }

    private fun rebuild() {
        gen++
        handler.removeCallbacksAndMessages(null)
        removeAllViews()
        group = null; openPanel = null
        if (width <= 0 || height <= 0) return

        val right = p.side == 1
        val size = d(24) + d(p.btnSize) * 4 / 5
        val gap = d(p.btnGap)
        val accent = p.accent()

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        fun add(v: View, s: Int) {
            col.addView(v, LinearLayout.LayoutParams(s, s).apply { topMargin = if (col.childCount > 0) gap else 0 })
        }
        if (p.powerEnabled) add(btn(StyledButton.POWER, 0xFFE53935.toInt(), 0), size)
        if (p.showVolButtons) {
            add(btn(StyledButton.PLUS, accent, 0), size)
            add(btn(StyledButton.MINUS, accent, 0), size)
        }
        if (p.multiEnabled) add(btn(StyledButton.SLIDERS, p.sbAccent(), p.sbIcon), size * p.sbScale / 100)

        val sw = d(p.sliderWidth); val sh = d(p.sliderHeight); val g12 = d(12)
        val ids = if (p.multiEnabled) Sliders.names.indices.filter { (p.multiMask and (1 shl it)) != 0 } else emptyList()
        val fr = floatArrayOf(0.62f, 0.41f, 0.78f, 0.30f, 0.55f, 0.20f, 0.70f)

        val panel: View
        val panelLp: LinearLayout.LayoutParams
        if (ids.isNotEmpty()) {
            val m = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (id in ids) {
                m.addView(slider(id, fr[id % fr.size]), LinearLayout.LayoutParams(sw, sh).apply {
                    if (right) marginEnd = g12 else marginStart = g12
                })
            }
            panel = m
            panelLp = LinearLayout.LayoutParams(WRAP, WRAP)
            openPanelW = ids.size * (sw + g12)
            openBase = 1f
            autoHides = true
        } else {
            panel = slider(0, 0.62f)
            panelLp = LinearLayout.LayoutParams(sw, sh).apply { if (right) marginEnd = g12 else marginStart = g12 }
            openPanelW = sw + g12
            openBase = 1f - p.sliderTransparency / 100f
            autoHides = p.sliderAutoHide
        }
        openPanel = panel

        val g = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (col.childCount == 0) {
            g.addView(TextView(context).apply {
                text = "No buttons turned on"; setTextColor(0xCCFFFFFF.toInt()); textSize = 13f
                setPadding(d(8), d(8), d(8), d(8))
            })
        } else if (!right) {
            g.addView(col); g.addView(panel, panelLp)
        } else {
            g.addView(panel, panelLp); g.addView(col)
        }
        g.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val mw = g.measuredWidth.coerceAtLeast(1)
        val mh = g.measuredHeight.coerceAtLeast(1)
        val margin = d(10)
        val scale = minOf(1f, (width - 2 * margin).toFloat() / mw, (height - d(16)).toFloat() / mh)
        g.pivotX = if (right) mw.toFloat() else 0f
        g.pivotY = mh / 2f
        g.scaleX = scale; g.scaleY = scale
        addView(g, FrameLayout.LayoutParams(mw, mh, (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL).apply {
            if (right) marginEnd = margin else marginStart = margin
        })
        group = g
    }

    // ------------------------------------------------------------------ loop: open -> hold -> close -> (idle fade) -> open
    private fun loop() {
        val my = ++gen
        val g = group ?: return
        val panel = openPanel
        val dur = if (p.animEnabled) p.animDuration.toLong() else 0L
        fun later(ms: Long, f: () -> Unit) {
            handler.postDelayed({ if (my == gen && isAttachedToWindow) f() }, ms)
        }
        fun idleThen(next: () -> Unit) {
            if (!p.idleFade) { next(); return }
            later(p.idleDelay * 1000L) {
                g.animate().alpha(p.idleOpacity / 100f).setDuration(400).start()
                later(1900) {
                    g.animate().alpha(1f).setDuration(150).start()
                    later(450) { next() }
                }
            }
        }
        if (panel == null || !autoHides) {
            if (p.idleFade) idleThen { loop() }
            return
        }
        val hold = (if (p.multiEnabled) maxOf(p.hideDelay, 3) else p.hideDelay) * 1000L
        later(hold) {
            anim(panel, false, openBase, openPanelW) {}
            later(dur + 700) {
                idleThen {
                    anim(panel, true, openBase, openPanelW) { if (my == gen) loop() }
                }
            }
        }
    }

    // ------------------------------------------------------------------ animation (same behaviour as the real shortcut)
    private fun resetProps(v: View, base: Float) {
        v.alpha = base; v.translationX = 0f; v.scaleX = 1f; v.scaleY = 1f; v.rotationY = 0f
    }

    private fun hiddenState(v: View, w: Int, right: Boolean) {
        when (p.animType) {
            0 -> v.alpha = 0f
            1 -> { v.alpha = 0f; v.translationX = if (right) w.toFloat() else -w.toFloat() }
            2 -> { v.alpha = 0f; v.scaleX = 0.3f; v.scaleY = 0.3f }
            3 -> { v.alpha = 0f; v.scaleX = 0f; v.scaleY = 0f }
            else -> { v.alpha = 0f; v.rotationY = if (right) -90f else 90f }
        }
    }

    private fun anim(v: View, show: Boolean, base: Float, wHint: Int, end: (() -> Unit)? = null) {
        v.animate().cancel()
        val right = p.side == 1
        val w = if (v.width > 0) v.width else wHint.coerceAtLeast(d(40))
        v.pivotX = if (right) w.toFloat() else 0f
        v.pivotY = (if (v.height > 0) v.height else d(100)) / 2f
        v.cameraDistance = 9000f * resources.displayMetrics.density
        val dur = if (p.animEnabled) p.animDuration.toLong() else 0L
        val type = p.animType
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.visibility = View.VISIBLE
                if (dur > 0) hiddenState(v, w, right)
            }
            if (dur == 0L) { resetProps(v, base); end?.invoke(); return }
            v.animate().alpha(base).translationX(0f).scaleX(1f).scaleY(1f).rotationY(0f)
                .setDuration(dur)
                .setInterpolator(if (type == 3) OvershootInterpolator(2.4f) else DecelerateInterpolator())
                .withEndAction { end?.invoke() }.start()
        } else {
            if (dur == 0L) { v.visibility = View.GONE; resetProps(v, base); end?.invoke(); return }
            val a = v.animate().alpha(0f).setDuration(dur).setInterpolator(AccelerateInterpolator())
            when (type) {
                1 -> a.translationX(if (right) w.toFloat() else -w.toFloat())
                2 -> a.scaleX(0.3f).scaleY(0.3f)
                3 -> a.scaleX(0f).scaleY(0f)
                4 -> a.rotationY(if (right) -90f else 90f)
            }
            a.withEndAction { v.visibility = View.GONE; resetProps(v, base); end?.invoke() }.start()
        }
    }
}
