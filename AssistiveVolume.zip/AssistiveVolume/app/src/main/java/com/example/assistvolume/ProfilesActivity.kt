package com.example.assistvolume

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class ProfilesActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var holder: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        applyAppTheme()
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        holder = FrameLayout(this)
        setContentView(holder)
        applyBars()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::holder.isInitialized) render()
    }

    private fun fmt(v: Int) = if (v < 0) "\u2014" else "$v%"

    private fun summary(pr: Profile) =
        "${listOf("Normal", "Vibrate", "Silent")[pr.ringer]} \u00B7 Media ${fmt(pr.media)} \u00B7 Brightness ${fmt(pr.bright)}"

    private fun render() {
        holder.removeAllViews()
        val col = lin().apply { setPadding(dp(14), dp(18), dp(14), dp(28)) }
        col.addView(pageTitle("Volume profiles", "One tap, or automatic by time"))

        // ---- profiles ----
        col.addView(sectionLabel("Profiles"))
        val c = card()
        Profiles.names.forEachIndexed { i, n ->
            val pr = Profiles.get(p, i)
            val apply = tv("Apply", 13f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(7), dp(14), dp(7))
                background = gradient(12)
                setOnClickListener {
                    Profiles.apply(this@ProfilesActivity, i)
                    Toast.makeText(this@ProfilesActivity, "${Profiles.emojis[i]} $n applied", Toast.LENGTH_SHORT).show()
                }
            }
            c.addRow(settingRow(Profiles.emojis[i], C.PRIMARY, n, summary(pr), apply) { editProfile(i) })
        }
        col.addView(c)
        col.addView(tv("Tap a profile to edit it.", 12.5f, C.TEXT2).apply { setPadding(dp(8), dp(8), dp(8), 0) })

        // ---- schedule ----
        col.addView(sectionLabel("Schedule"))
        val sc = card()
        for (i in 0 until ScheduleManager.SLOTS) {
            val s = ScheduleManager.get(p, i)
            val sw = Switch(this).apply {
                isChecked = s.enabled
                setOnCheckedChangeListener { _, on ->
                    ScheduleManager.save(p, i, ScheduleManager.get(p, i).copy(enabled = on))
                    ScheduleManager.schedule(this@ProfilesActivity, i)
                }
            }
            sc.addRow(settingRow("\u23F0", C.AMBER, "Schedule ${i + 1}", ScheduleManager.describe(s), sw) { editSlot(i) })
        }
        col.addView(sc)
        col.addView(tv("Schedules keep working after the phone restarts. Android may run them a few minutes late to save battery.",
            12.5f, C.TEXT2).apply { setPadding(dp(8), dp(8), dp(8), 0) })

        // ---- DND ----
        col.addView(sectionLabel("Silent mode"))
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val granted = nm.isNotificationPolicyAccessGranted
        val trailing = if (granted) pill("Granted", C.GREEN) else tv("Grant", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(14), dp(7), dp(14), dp(7)); background = gradient(12)
        }
        val dnd = card()
        dnd.addRow(settingRow("\uD83D\uDD15", C.RED, "Do Not Disturb access",
            "Needed for the fully Silent profile. Without it Silent becomes Vibrate.", trailing,
            if (granted) null else { { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } }))
        col.addView(dnd)

        holder.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
    }

    private fun optRow(label: String, v: Int): Pair<LinearLayout, () -> Int> {
        val box = lin().apply { setPadding(0, dp(6), 0, dp(2)) }
        val cb = CheckBox(this).apply { text = label; isChecked = v >= 0 }
        val sb = SeekBar(this).apply { max = 100; progress = if (v >= 0) v else 50 }
        box.addView(cb); box.addView(sb)
        return box to { if (cb.isChecked) sb.progress else -1 }
    }

    private fun editProfile(i: Int) {
        val pr = Profiles.get(p, i)
        var ringer = pr.ringer
        val box = lin().apply { setPadding(dp(20), dp(8), dp(20), dp(4)) }
        box.addView(tv("Ringer mode", 13f, C.TEXT2, true))
        box.addView(chipRow(listOf("Normal", "Vibrate", "Silent"), ringer) { ringer = it })
        val media = optRow("Set media volume", pr.media)
        val ring = optRow("Set ring volume", pr.ring)
        val notif = optRow("Set notification volume", pr.notif)
        val bright = optRow("Set brightness", pr.bright)
        listOf(media, ring, notif, bright).forEach { box.addView(it.first) }

        AlertDialog.Builder(this)
            .setTitle("${Profiles.emojis[i]} ${Profiles.names[i]}")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                Profiles.save(p, i, Profile(ringer, media.second(), ring.second(), notif.second(), bright.second()))
                render()
            }
            .setNeutralButton("Reset") { _, _ -> Profiles.reset(p, i); render() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun editSlot(i: Int) {
        val s = ScheduleManager.get(p, i)
        var days = s.days
        val tp = TimePicker(this).apply { setIs24HourView(true); hour = s.hour; minute = s.minute }
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@ProfilesActivity, android.R.layout.simple_spinner_dropdown_item,
                Profiles.names.mapIndexed { k, n -> "${Profiles.emojis[k]} $n" })
            setSelection(s.profile)
        }
        val box = lin().apply { setPadding(dp(16), dp(8), dp(16), dp(4)) }
        box.addView(tp)
        box.addView(tv("Profile", 13f, C.TEXT2, true).apply { setPadding(0, dp(8), 0, dp(2)) })
        box.addView(spin)
        box.addView(tv("Repeat on", 13f, C.TEXT2, true).apply { setPadding(0, dp(12), 0, 0) })
        box.addView(multiChipRow(listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"), days) { days = it })

        AlertDialog.Builder(this)
            .setTitle("Schedule ${i + 1}")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                ScheduleManager.save(p, i, ScheduleManager.Slot(true, tp.hour, tp.minute, spin.selectedItemPosition, days))
                ScheduleManager.schedule(this, i)
                render()
            }
            .setNeutralButton("Turn off") { _, _ ->
                ScheduleManager.save(p, i, s.copy(enabled = false))
                ScheduleManager.schedule(this, i)
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
