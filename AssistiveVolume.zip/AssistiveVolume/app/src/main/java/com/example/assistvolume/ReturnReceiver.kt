package com.example.assistvolume

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fired by AlarmManager when the hide time is over. Brings the shortcut back even if the app was stopped. */
class ReturnReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try {
            c.startForegroundService(Intent(c, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
        } catch (_: Exception) {}
    }
}
