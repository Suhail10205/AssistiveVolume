package com.example.assistvolume

import android.app.AppOpsManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.Process

/** Explains, in plain words, whether this phone lets the app change the call volume. */
object CallDiag {
    fun report(ctx: Context): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = AudioManager.STREAM_VOICE_CALL
        val sb = StringBuilder()
        val mode = when (am.mode) {
            0 -> "Normal (no call)"
            1 -> "Ringing"
            2 -> "On a phone call"
            3 -> "On a VoIP call (WhatsApp etc.)"
            else -> "Other (${am.mode})"
        }
        val mn = if (Build.VERSION.SDK_INT >= 28) am.getStreamMinVolume(s) else 1
        val max = am.getStreamMaxVolume(s)
        sb.append("Audio mode: $mode\n")
        sb.append("Speakerphone: ${if (am.isSpeakerphoneOn) "on" else "off"}\n")
        sb.append("Bluetooth call audio: ${try { if (am.isBluetoothScoOn) "on" else "off" } catch (_: Exception) { "unknown" }}\n")
        sb.append("Call volume now: ${am.getStreamVolume(s)}  (lowest $mn, highest $max)\n")
        sb.append("Phone with fixed volume: ${try { if (am.isVolumeFixed) "yes" else "no" } catch (_: Exception) { "unknown" }}\n")

        val st = try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow("android:audio_voice_volume", Process.myUid(), ctx.packageName)
            else ops.checkOpNoThrow("android:audio_voice_volume", Process.myUid(), ctx.packageName)
        } catch (_: Exception) { -99 }
        sb.append("System permission for call volume: ${
            when (st) { 0 -> "allowed"; 1 -> "BLOCKED by the system"; 2 -> "ERROR"; 3 -> "default"; 4 -> "foreground only"; else -> "not reported" }
        }\n\n")

        val start = am.getStreamVolume(s)
        val up = start < max
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        fun test(name: String, act: () -> Unit) {
            val before = am.getStreamVolume(s)
            try { act() } catch (e: Exception) { sb.append("$name: error (${e.javaClass.simpleName})\n"); return }
            val after = am.getStreamVolume(s)
            sb.append("$name: ${if (after != before) "WORKED ($before to $after)" else "no change"}\n")
            try { am.setStreamVolume(s, before, 0) } catch (_: Exception) {}
        }
        sb.append("Live test (changes one step and puts it back):\n")
        test("1. Volume-key method") { am.adjustSuggestedStreamVolume(dir, s, 0) }
        test("2. Direct adjust") { am.adjustStreamVolume(s, dir, 0) }
        test("3. Set exact value") { am.setStreamVolume(s, if (up) start + 1 else start - 1, 0) }
        try { am.setStreamVolume(s, start, 0) } catch (_: Exception) {}
        sb.append("\nFor the best result run this test while a call is in progress.")
        return sb.toString()
    }
}
