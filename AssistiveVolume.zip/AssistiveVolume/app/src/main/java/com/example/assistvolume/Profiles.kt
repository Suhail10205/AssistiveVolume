package com.example.assistvolume

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import java.util.Calendar
import java.util.Locale

object Actions {
    val names = listOf(
        "None", "Mute / unmute media", "Next volume profile", "Take screenshot",
        "Open notifications", "Screen off", "Power menu", "Hide buttons", "Touch lock (kids mode)", "Banking mode (hide + Accessibility off)"
    )
}

/** ringer: 0 Normal, 1 Vibrate, 2 Silent. A value of -1 means "leave unchanged". */
data class Profile(val ringer: Int, val media: Int, val ring: Int, val notif: Int, val bright: Int)

object Profiles {
    val names = listOf("Silent", "Meeting", "Night", "Outdoor", "Driving")
    val emojis = listOf("\uD83D\uDD15", "\uD83E\uDD1D", "\uD83C\uDF19", "\uD83C\uDF33", "\uD83D\uDE97")
    private val defaults = listOf(
        Profile(2, 0, 0, 0, -1),
        Profile(1, 20, 0, 0, -1),
        Profile(0, 15, 20, 10, 10),
        Profile(0, 90, 100, 80, 90),
        Profile(0, 80, 100, 100, -1)
    )

    fun get(p: Prefs, i: Int): Profile {
        val raw = p.profileRaw(i) ?: return defaults[i]
        return try {
            val a = raw.split(",")
            Profile(a[0].toInt(), a[1].toInt(), a[2].toInt(), a[3].toInt(), a[4].toInt())
        } catch (e: Exception) { defaults[i] }
    }

    fun save(p: Prefs, i: Int, pr: Profile) =
        p.setProfileRaw(i, "${pr.ringer},${pr.media},${pr.ring},${pr.notif},${pr.bright}")

    fun reset(p: Prefs, i: Int) = p.setProfileRaw(i, null)

    fun apply(ctx: Context, i: Int) {
        val prefs = Prefs(ctx)
        val pr = get(prefs, i)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            am.ringerMode = when (pr.ringer) {
                1 -> AudioManager.RINGER_MODE_VIBRATE
                2 -> AudioManager.RINGER_MODE_SILENT
                else -> AudioManager.RINGER_MODE_NORMAL
            }
        } catch (_: SecurityException) {
            // silent needs Do Not Disturb access; fall back to vibrate
            if (pr.ringer == 2) try { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE } catch (_: SecurityException) {}
        }
        fun pct(stream: Int, v: Int) {
            if (v < 0) return
            try { am.setStreamVolume(stream, Math.round(am.getStreamMaxVolume(stream) * v / 100f), 0) }
            catch (_: SecurityException) {}
        }
        pct(AudioManager.STREAM_MUSIC, pr.media)
        if (pr.ringer == 0) {
            pct(AudioManager.STREAM_RING, pr.ring)
            pct(AudioManager.STREAM_NOTIFICATION, pr.notif)
        }
        if (pr.bright >= 0 && Settings.System.canWrite(ctx)) {
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (pr.bright * 255 / 100).coerceIn(1, 255))
            } catch (_: Exception) {}
        }
        prefs.curProfile = i
        OverlayService.instance?.syncFromOutside()
    }

    /** Applies the next profile and returns its index. */
    fun next(ctx: Context): Int {
        val n = (Prefs(ctx).curProfile + 1) % names.size
        apply(ctx, n)
        return n
    }
}

object ScheduleManager {
    const val SLOTS = 3

    /** days: bit0 = Monday ... bit6 = Sunday (127 = every day) */
    data class Slot(val enabled: Boolean, val hour: Int, val minute: Int, val profile: Int, val days: Int)

    private val defaults = listOf(
        Slot(false, 22, 0, 2, 127),
        Slot(false, 7, 0, 3, 127),
        Slot(false, 13, 0, 1, 31)
    )

    fun get(p: Prefs, i: Int): Slot {
        val raw = p.schedRaw(i) ?: return defaults[i]
        return try {
            val a = raw.split(",")
            Slot(a[0] == "1", a[1].toInt(), a[2].toInt(), a[3].toInt(), a[4].toInt())
        } catch (e: Exception) { defaults[i] }
    }

    fun save(p: Prefs, i: Int, s: Slot) =
        p.setSchedRaw(i, "${if (s.enabled) 1 else 0},${s.hour},${s.minute},${s.profile},${s.days}")

    fun describe(s: Slot): String {
        val t = String.format(Locale.getDefault(), "%02d:%02d", s.hour, s.minute)
        val d = when (s.days) {
            127 -> "Every day"
            31 -> "Weekdays"
            96 -> "Weekends"
            0 -> "No days"
            else -> listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                .filterIndexed { k, _ -> (s.days and (1 shl k)) != 0 }.joinToString(" ")
        }
        return "$t \u00B7 ${Profiles.emojis[s.profile]} ${Profiles.names[s.profile]} \u00B7 $d"
    }

    fun scheduleAll(ctx: Context) { for (i in 0 until SLOTS) schedule(ctx, i) }

    fun schedule(ctx: Context, i: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, i)
        am.cancel(pi)
        val s = get(Prefs(ctx), i)
        if (!s.enabled || s.days == 0) return
        val t = nextTrigger(s) ?: return
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }

    private fun nextTrigger(s: Slot): Long? {
        val now = System.currentTimeMillis()
        for (add in 0..7) {
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, s.hour); set(Calendar.MINUTE, s.minute)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, add)
            }
            val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7   // Monday = 0 ... Sunday = 6
            if (c.timeInMillis > now + 1000 && (s.days and (1 shl dow)) != 0) return c.timeInMillis
        }
        return null
    }

    private fun pending(ctx: Context, i: Int) = PendingIntent.getBroadcast(
        ctx, 7000 + i,
        Intent(ctx, ScheduleReceiver::class.java).putExtra("slot", i),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val slot = i.getIntExtra("slot", -1)
        if (slot !in 0 until ScheduleManager.SLOTS) return
        val s = ScheduleManager.get(Prefs(c), slot)
        if (s.enabled) Profiles.apply(c, s.profile)
        ScheduleManager.schedule(c, slot)
    }
}
