package com.example.assistvolume

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class VolumeSliderView(
    ctx: Context,
    private val style: Int,
    private val icon: String,
    private val onChange: (Float) -> Unit
) : View(ctx) {

    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blue = 0xFF1A73E8.toInt()

    private fun pad() = if (style == 0) context.dp(14).toFloat() else 0f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = pad()
        paint.style = Paint.Style.FILL

        if (style == 0) {
            // thin track + round thumb
            val tw = context.dp(5).toFloat()
            val cx = w / 2
            val track = RectF(cx - tw / 2, pad, cx + tw / 2, h - pad)
            paint.color = 0xFFE0E0E0.toInt()
            c.drawRoundRect(track, tw / 2, tw / 2, paint)
            val ty = h - pad - (h - 2 * pad) * fraction
            paint.color = blue
            c.drawRoundRect(RectF(track.left, ty, track.right, track.bottom), tw / 2, tw / 2, paint)
            c.drawCircle(cx, ty, context.dp(9).toFloat(), paint)
        } else {
            val r = w / 2
            val rect = RectF(0f, 0f, w, h)
            paint.color = if (style == 1) 0xFF3C4043.toInt() else 0xFF5A5A5E.toInt()
            c.drawRoundRect(rect, r, r, paint)
            val path = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
            c.save()
            c.clipPath(path)
            paint.color = if (style == 1) blue else Color.WHITE
            c.drawRect(0f, h - h * fraction, w, h, paint)
            c.restore()
            // music note icon
            paint.color = if (style == 1) Color.WHITE else 0xFF3C4043.toInt()
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = w * 0.45f
            c.drawText(icon, w / 2, h - w * 0.35f, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = pad()
                val f = 1f - (e.y - pad) / (height - 2 * pad)
                fraction = f
                onChange(fraction)
            }
        }
        return true
    }
}
