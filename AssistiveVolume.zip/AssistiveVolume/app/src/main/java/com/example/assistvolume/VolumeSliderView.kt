package com.example.assistvolume

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class VolumeSliderView(
    ctx: Context,
    private val style: Int,
    private val icon: String,
    private val onChange: (Float) -> Unit
) : View(ctx) {

    var accent: Int = 0xFF1A73E8.toInt()
        set(v) { field = v; invalidate() }

    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun pad() = if (style == 0) context.dp(14).toFloat() else 0f

    private fun lighten(c: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = (hsv[1] * 0.55f)
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = pad()
        paint.style = Paint.Style.FILL
        paint.shader = null

        if (style == 0) {
            // thin track + glowing thumb
            val tw = context.dp(5).toFloat()
            val cx = w / 2
            val track = RectF(cx - tw / 2, pad, cx + tw / 2, h - pad)
            paint.color = 0x55FFFFFF
            c.drawRoundRect(track, tw / 2, tw / 2, paint)
            val ty = h - pad - (h - 2 * pad) * fraction
            paint.color = accent
            c.drawRoundRect(RectF(track.left, ty, track.right, track.bottom), tw / 2, tw / 2, paint)
            paint.color = Color.WHITE
            c.drawCircle(cx, ty, context.dp(11).toFloat(), paint)
            paint.color = accent
            c.drawCircle(cx, ty, context.dp(7).toFloat(), paint)
        } else {
            val r = w / 2
            val rect = RectF(0f, 0f, w, h)
            paint.color = if (style == 1) 0xFF2B2D31.toInt() else 0xFF5A5A5E.toInt()
            c.drawRoundRect(rect, r, r, paint)
            val path = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
            c.save()
            c.clipPath(path)
            if (style == 1) {
                paint.shader = LinearGradient(0f, h - h * fraction, 0f, h, lighten(accent), accent, Shader.TileMode.CLAMP)
            } else {
                paint.color = Color.WHITE
            }
            c.drawRect(0f, h - h * fraction, w, h, paint)
            paint.shader = null
            c.restore()
            // icon at the bottom
            paint.color = if (style == 1) Color.WHITE else 0xFF3C4043.toInt()
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = w * 0.42f
            c.drawText(icon, w / 2, h - w * 0.32f, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = pad()
                fraction = 1f - (e.y - pad) / (height - 2 * pad)
                onChange(fraction)
            }
        }
        return true
    }
}
