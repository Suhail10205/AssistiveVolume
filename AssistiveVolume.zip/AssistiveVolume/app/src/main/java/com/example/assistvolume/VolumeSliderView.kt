package com.example.assistvolume

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/**
 * Vertical slider. style: 0 Android (thin), 1 Android 12 (pill), 2 iOS, 3 Glass, 4 Segments, 5 Crystal Glass
 */
class VolumeSliderView(
    ctx: Context,
    private val style: Int,
    var iconId: Int,
    private val onChange: (Float) -> Unit
) : View(ctx) {

    var accent: Int = 0xFF1A73E8.toInt()
        set(v) { field = v; invalidate() }
    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    // icon options
    var showIcon = true
    var iconStyle = 2          // 0 Line, 1 Bold, 2 Filled
    var iconTop = false
    var iconSizePct = 100
    var showPercent = false

    // colour options
    var fillAlpha = 255        // level opacity
    var trackAlpha = 255       // empty-part opacity
    var customLevel = false    // true when the user picked the level colour
    var iconOverride: Int? = null
    private fun lv(c: Int) = Color.argb(fillAlpha, Color.red(c), Color.green(c), Color.blue(c))
    private fun ta(c: Int) = Color.argb(Color.alpha(c) * trackAlpha / 255, Color.red(c), Color.green(c), Color.blue(c))

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

    private fun iconSize() = (width * 0.42f * iconSizePct / 100f).coerceAtMost(width * 0.8f)
    private fun reserves() = showIcon && (style == 0 || style == 4)

    private fun top(): Float {
        var t = if (style == 0 || style == 4) context.dp(12).toFloat() else 0f
        if (reserves() && iconTop) t += iconSize() + context.dp(8)
        if (showPercent && (style == 0 || style == 4) && !iconTop) t += context.dp(16)
        return t
    }

    private fun bottom(): Float {
        var b = height - (if (style == 0 || style == 4) context.dp(12).toFloat() else 0f)
        if (reserves() && !iconTop) b -= iconSize() + context.dp(8)
        if (showPercent && (style == 0 || style == 4) && iconTop) b -= context.dp(16)
        return b
    }

    private fun lighten(c: Int): Int {
        val hsv = FloatArray(3); Color.colorToHSV(c, hsv)
        hsv[1] *= 0.55f; hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun iconColor(cy: Float): Int = iconOverride ?: when (style) {
        2 -> 0xFF3C4043.toInt()
        5 -> if (cy >= height - height * fraction) 0xFF2A2F3A.toInt() else Color.WHITE
        else -> Color.WHITE
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        paint.style = Paint.Style.FILL; paint.shader = null
        val t = top(); val b = bottom()
        val tl = (b - t).coerceAtLeast(1f)
        val levelY = b - tl * fraction

        when (style) {
            0 -> {
                paint.color = ta(0x66000000)
                c.drawRoundRect(RectF(0f, 0f, w, h), w / 2, w / 2, paint)
                val tw = context.dp(5).toFloat(); val cx = w / 2
                val track = RectF(cx - tw / 2, t, cx + tw / 2, b)
                paint.color = ta(0x55FFFFFF)
                c.drawRoundRect(track, tw / 2, tw / 2, paint)
                paint.color = lv(accent)
                c.drawRoundRect(RectF(track.left, levelY, track.right, b), tw / 2, tw / 2, paint)
                paint.color = Color.WHITE
                c.drawCircle(cx, levelY, context.dp(11).toFloat(), paint)
                paint.color = lv(accent)
                c.drawCircle(cx, levelY, context.dp(7).toFloat(), paint)
            }
            1, 2, 3 -> {
                val r = w / 2
                val rect = RectF(0f, 0f, w, h)
                paint.color = ta(when (style) { 1 -> 0xFF2B2D31.toInt(); 2 -> 0xFF5A5A5E.toInt(); else -> 0x66000000 })
                c.drawRoundRect(rect, r, r, paint)
                if (style == 3) {
                    paint.shader = LinearGradient(0f, 0f, 0f, h, 0x33FFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP)
                    c.drawRoundRect(rect, r, r, paint); paint.shader = null
                }
                val path = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
                c.save(); c.clipPath(path)
                val fy = h - h * fraction
                when (style) {
                    1 -> paint.shader = LinearGradient(0f, fy, 0f, h, lighten(accent), accent, Shader.TileMode.CLAMP)
                    2 -> paint.color = if (customLevel) accent else Color.WHITE
                    else -> paint.shader = LinearGradient(0f, fy, 0f, h, Color.argb(235, Color.red(lighten(accent)), Color.green(lighten(accent)), Color.blue(lighten(accent))),
                        Color.argb(200, Color.red(accent), Color.green(accent), Color.blue(accent)), Shader.TileMode.CLAMP)
                }
                paint.alpha = fillAlpha
                c.drawRect(0f, fy, w, h, paint)
                paint.shader = null; paint.alpha = 255
                c.restore()
                if (style == 3) {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = context.dp(1).toFloat() * 1.5f
                    paint.color = 0x88FFFFFF.toInt()
                    c.drawRoundRect(RectF(1f, 1f, w - 1, h - 1), r, r, paint)
                    paint.style = Paint.Style.FILL
                }
            }
            5 -> { // Crystal Glass
                val r = w / 2
                val rect = RectF(0f, 0f, w, h)
                val inner = RectF(rect)
                paint.color = ta(0x38000000)
                c.drawRoundRect(rect, r, r, paint)
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0x33FFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP)
                c.drawRoundRect(rect, r, r, paint); paint.shader = null
                val path = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
                c.save(); c.clipPath(path)
                val fy = h - h * fraction
                // liquid fill
                paint.shader = LinearGradient(0f, fy, 0f, h, lighten(accent), accent, Shader.TileMode.CLAMP)
                paint.alpha = fillAlpha * 235 / 255
                c.drawRect(0f, fy, w, h, paint)
                paint.shader = null; paint.alpha = 255
                if (fraction > 0.02f) {
                    // glossy surface line
                    paint.color = 0xCCFFFFFF.toInt()
                    c.drawRoundRect(RectF(w * 0.12f, fy, w * 0.88f, fy + context.dp(2).toFloat()), context.dp(1).toFloat(), context.dp(1).toFloat(), paint)
                }
                // vertical specular stripe
                paint.shader = LinearGradient(0f, 0f, w * 0.55f, 0f, 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w * 0.55f, h, paint)
                paint.shader = null
                c.restore()
                // rim
                val sw = context.dp(1).toFloat() * 1.3f
                paint.style = Paint.Style.STROKE; paint.strokeWidth = sw
                paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xF2FFFFFF.toInt(), 0x28FFFFFF, 0x85FFFFFF.toInt()),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                inner.inset(sw / 2f, sw / 2f)
                c.drawRoundRect(inner, r - sw / 2f, r - sw / 2f, paint)
                paint.shader = null; paint.style = Paint.Style.FILL
            }
            else -> { // segments
                paint.color = ta(0x66000000)
                c.drawRoundRect(RectF(0f, 0f, w, h), w * 0.32f, w * 0.32f, paint)
                val n = 10
                val gap = context.dp(4).toFloat()
                val sh = (tl - gap * (n - 1)) / n
                val lit = Math.round(fraction * n)
                for (i in 0 until n) {
                    val yb = b - i * (sh + gap)
                    paint.color = if (i < lit) lv(accent) else ta(0x33FFFFFF)
                    c.drawRoundRect(RectF(w * 0.2f, yb - sh, w * 0.8f, yb), sh / 2, sh / 2, paint)
                }
            }
        }

        // icon
        if (showIcon) {
            val s = iconSize()
            val pad = context.dp(8).toFloat()
            val cy = if (iconTop) (if (reserves()) context.dp(12) + s / 2 else pad + s / 2)
            else (if (reserves()) h - context.dp(12) - s / 2 else h - pad - s / 2)
            SvgIcon.draw(c, Sliders.paths[iconId], w / 2, cy, s, iconColor(cy), iconStyle)
        }

        // percentage
        if (showPercent) {
            text.color = if ((style == 2 || style == 5) && fraction > 0.88f && !iconTop) 0xFF3C4043.toInt() else Color.WHITE
            text.textSize = (w * 0.26f).coerceAtLeast(context.dp(10).toFloat())
            val label = "${Math.round(fraction * 100)}"
            val y = if (iconTop) h - context.dp(10) else context.dp(10) + text.textSize
            c.drawText(label, w / 2, if (iconTop) y else y, text)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val t = top(); val b = bottom()
                fraction = 1f - (e.y - t) / (b - t).coerceAtLeast(1f)
                onChange(fraction)
            }
        }
        return true
    }
}
