package com.example.assistvolume

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Restarts the shortcut (and re-arms schedules) after the phone is switched on or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action ?: return
        val booted = a == Intent.ACTION_BOOT_COMPLETED || a.endsWith("QUICKBOOT_POWERON")
        val updated = a == Intent.ACTION_MY_PACKAGE_REPLACED
        if (!booted && !updated) return
        try { ScheduleManager.scheduleAll(c) } catch (_: Exception) {}
        val p = Prefs(c)
        if (p.enabled && (p.bootStart || updated) && Settings.canDrawOverlays(c)) {
            try { c.startForegroundService(Intent(c, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
