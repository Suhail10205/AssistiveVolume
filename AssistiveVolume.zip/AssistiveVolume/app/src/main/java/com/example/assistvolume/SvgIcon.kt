package com.example.assistvolume

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path

/** Tiny SVG path renderer so we can draw crisp vector icons on a Canvas (24 x 24 grid). */
object SvgIcon {
    private val cache = HashMap<String, Path>()
    private val re = Regex("[MmLlHhVvCcSsZz]|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?")
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // 24dp grid paths
    const val MUSIC = "M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z"
    const val BELL = "M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.89,2 2,2zM18,16v-5c0,-3.07 -1.64,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.63,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z"
    const val CHAT = "M20,2H4c-1.1,0 -2,0.9 -2,2v18l4,-4h14c1.1,0 2,-0.9 2,-2V4c0,-1.1 -0.9,-2 -2,-2z"
    const val CALL = "M6.62,10.79c1.44,2.83 3.76,5.14 6.59,6.59l2.2,-2.2c0.27,-0.27 0.67,-0.36 1.02,-0.24 1.12,0.37 2.33,0.57 3.57,0.57 0.55,0 1,0.45 1,1V20c0,0.55 -0.45,1 -1,1 -9.39,0 -17,-7.61 -17,-17 0,-0.55 0.45,-1 1,-1h3.5c0.55,0 1,0.45 1,1 0,1.25 0.2,2.45 0.57,3.57 0.11,0.35 0.03,0.74 -0.25,1.02l-2.2,2.2z"
    const val SUN = "M20,8.69V4h-4.69L12,0.69 8.69,4H4v4.69L0.69,12 4,15.31V20h4.69L12,23.31 15.31,20H20v-4.69L23.31,12 20,8.69zM12,18c-3.31,0 -6,-2.69 -6,-6s2.69,-6 6,-6 6,2.69 6,6 -2.69,6 -6,6zM12,8c-2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4 -1.79,-4 -4,-4z"
    const val SPEAKER = "M3,9v6h4l5,5V4L7,9H3zM16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v8.05c1.48,-0.73 2.5,-2.25 2.5,-4.02zM14,3.23v2.06c2.89,0.86 5,3.54 5,6.71s-2.11,5.85 -5,6.71v2.06c4.01,-0.91 7,-4.49 7,-8.77s-2.99,-7.86 -7,-8.77z"
    const val MOON = "M9,2c-1.05,0 -2.05,0.16 -3,0.46 4.06,1.27 7,5.06 7,9.54 0,4.48 -2.94,8.27 -7,9.54 0.95,0.3 1.95,0.46 3,0.46 5.52,0 10,-4.48 10,-10S14.52,2 9,2z"
    const val TUNE = "M3,17v2h6v-2H3zM3,5v2h10V5H3zM13,21v-2h8v-2h-8v-2h-2v6h2zM7,9v2H3v2h4v2h2V9H7zM21,13v-2H11v2h10zM15,9h2V7h4V5h-4V3h-2v6z"
    const val EQUALIZER = "M10,20h4V4h-4v16zM4,20h4v-8H4v8zM16,9v11h4V9h-4z"
    const val WAVE = "M7,18h2V6H7v12zM11,22h2V2h-2v20zM3,14h2v-4H3v4zM15,18h2V6h-2v12zM19,10v4h2v-4h-2z"
    const val GRID = "M4,8h4V4H4v4zM10,20h4v-4h-4v4zM4,20h4v-4H4v4zM4,14h4v-4H4v4zM10,14h4v-4h-4v4zM16,4v4h4V4h-4zM10,8h4V4h-4v4zM16,14h4v-4h-4v4zM16,20h4v-4h-4v4z"

    fun path(d: String): Path = cache.getOrPut(d) { parse(d) }

    /** style: 0 Line, 1 Bold, 2 Filled */
    fun draw(c: Canvas, d: String, cx: Float, cy: Float, size: Float, color: Int, style: Int) {
        val sc = size / 24f
        paint.color = color
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        when (style) {
            0 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.3f }
            1 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.4f }
            else -> { paint.style = Paint.Style.FILL }
        }
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(sc, sc)
        c.drawPath(path(d), paint)
        c.restore()
    }

    private fun parse(d: String): Path {
        val t = re.findAll(d).map { it.value }.toList()
        val p = Path()
        var i = 0
        var x = 0f; var y = 0f; var sx = 0f; var sy = 0f
        var lcx = 0f; var lcy = 0f
        var cmd = ' '
        fun num(): Float = t[i++].toFloat()
        while (i < t.size) {
            if (t[i][0].isLetter()) {
                cmd = t[i][0]; i++
                if (cmd == 'z' || cmd == 'Z') { p.close(); x = sx; y = sy; lcx = x; lcy = y }
                continue
            }
            when (cmd) {
                'M' -> { x = num(); y = num(); p.moveTo(x, y); sx = x; sy = y; lcx = x; lcy = y; cmd = 'L' }
                'm' -> { x += num(); y += num(); p.moveTo(x, y); sx = x; sy = y; lcx = x; lcy = y; cmd = 'l' }
                'L' -> { x = num(); y = num(); p.lineTo(x, y); lcx = x; lcy = y }
                'l' -> { x += num(); y += num(); p.lineTo(x, y); lcx = x; lcy = y }
                'H' -> { x = num(); p.lineTo(x, y); lcx = x; lcy = y }
                'h' -> { x += num(); p.lineTo(x, y); lcx = x; lcy = y }
                'V' -> { y = num(); p.lineTo(x, y); lcx = x; lcy = y }
                'v' -> { y += num(); p.lineTo(x, y); lcx = x; lcy = y }
                'C' -> {
                    val x1 = num(); val y1 = num(); val x2 = num(); val y2 = num(); val nx = num(); val ny = num()
                    p.cubicTo(x1, y1, x2, y2, nx, ny); lcx = x2; lcy = y2; x = nx; y = ny
                }
                'c' -> {
                    val x1 = x + num(); val y1 = y + num(); val x2 = x + num(); val y2 = y + num()
                    val nx = x + num(); val ny = y + num()
                    p.cubicTo(x1, y1, x2, y2, nx, ny); lcx = x2; lcy = y2; x = nx; y = ny
                }
                'S' -> {
                    val x1 = 2 * x - lcx; val y1 = 2 * y - lcy
                    val x2 = num(); val y2 = num(); val nx = num(); val ny = num()
                    p.cubicTo(x1, y1, x2, y2, nx, ny); lcx = x2; lcy = y2; x = nx; y = ny
                }
                's' -> {
                    val x1 = 2 * x - lcx; val y1 = 2 * y - lcy
                    val x2 = x + num(); val y2 = y + num(); val nx = x + num(); val ny = y + num()
                    p.cubicTo(x1, y1, x2, y2, nx, ny); lcx = x2; lcy = y2; x = nx; y = ny
                }
                else -> i++
            }
        }
        return p
    }
}
