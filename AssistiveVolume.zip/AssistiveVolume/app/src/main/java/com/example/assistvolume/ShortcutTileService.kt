package com.example.assistvolume

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: tap to hide or show the floating shortcut over any app. */
class ShortcutTileService : TileService() {

    override fun onStartListening() { refreshTile() }

    override fun onClick() {
        try {
            if (OverlayService.instance == null) {
                if (Settings.canDrawOverlays(this)) {
                    Prefs(this).enabled = true
                    startForegroundService(Intent(this, OverlayService::class.java))
                }
            } else {
                startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_TOGGLE))
            }
        } catch (_: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({ refreshTile() }, 400)
    }

    private fun refreshTile() {
        val t = qsTile ?: return
        val svc = OverlayService.instance
        t.state = if (svc != null && !svc.isHiddenNow()) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Assistive Volume"
        t.updateTile()
    }
}
