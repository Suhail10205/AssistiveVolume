package com.example.assistvolume

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager

class ControlService : AccessibilityService() {
    companion object {
        var instance: ControlService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        e ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val pkg = e.packageName?.toString() ?: return
                if (pkg == packageName || pkg == "com.android.systemui" || isIme(pkg)) return
                OverlayService.instance?.onForegroundApp(pkg)
            }
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> checkKeyboard()
        }
    }

    private fun isIme(pkg: String): Boolean = try {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .inputMethodList.any { it.packageName == pkg }
    } catch (_: Exception) { false }

    private fun checkKeyboard() {
        val svc = OverlayService.instance ?: return
        var top = -1
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                    val r = Rect(); w.getBoundsInScreen(r); top = r.top
                }
            }
        } catch (_: Exception) {}
        svc.onKeyboard(top)
    }

    override fun onInterrupt() {}
}
