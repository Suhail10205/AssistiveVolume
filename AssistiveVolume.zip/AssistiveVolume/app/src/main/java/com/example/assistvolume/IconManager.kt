package com.example.assistvolume

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object IconManager {
    val names = listOf("Aurora", "Sunset", "Emerald", "Neon", "Minimal")
    val logos = intArrayOf(R.drawable.logo_1, R.drawable.logo_2, R.drawable.logo_3, R.drawable.logo_4, R.drawable.logo_5)

    fun apply(ctx: Context, variant: Int) {
        val pm = ctx.packageManager
        for (i in names.indices) {
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, "com.example.assistvolume.Icon${i + 1}"),
                if (i == variant) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        Prefs(ctx).iconVariant = variant
    }
}
