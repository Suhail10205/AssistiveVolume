package com.example.assistvolume

import android.animation.ValueAnimator
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Frosted "crystal glass" panel: translucent body, soft sheen from the top-left
 * and a bright refracting rim. With overlayOnly = true only the sheen and rim are drawn
 * (used on top of coloured buttons).
 */
class GlassDrawable(
    private val radius: Float,
    private val strokePx: Float,
    private val overlayOnly: Boolean = false,
    private val light: Boolean = false
) : Drawable() {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val rimRect = RectF()
    private val clip = Path()
    private var rad = 0f
    private var bodyShader: Shader? = null
    private var sheenShader: Shader? = null
    private var rimShader: Shader? = null
    private var glowShader: Shader? = null

    override fun onBoundsChange(b: Rect) {
        rect.set(b)
        val w = rect.width(); val h = rect.height()
        if (w <= 0f || h <= 0f) return
        rad = min(radius, min(w, h) / 2f)
        clip.reset(); clip.addRoundRect(rect, rad, rad, Path.Direction.CW)
        rimRect.set(rect); rimRect.inset(strokePx / 2f, strokePx / 2f)
        bodyShader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            if (light) intArrayOf(0xB8FFFFFF.toInt(), 0x80FFFFFF.toInt()) else intArrayOf(0x33FFFFFF, 0x12FFFFFF),
            null, Shader.TileMode.CLAMP
        )
        sheenShader = RadialGradient(
            rect.left + w * 0.25f, rect.top, max(w, h) * 0.95f,
            intArrayOf(if (light) 0xCCFFFFFF.toInt() else 0x4DFFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        glowShader = LinearGradient(
            0f, rect.bottom - h * 0.3f, 0f, rect.bottom,
            intArrayOf(0x00FFFFFF, if (light) 0x66FFFFFF else 0x22FFFFFF), null, Shader.TileMode.CLAMP
        )
        rimShader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(0xE6FFFFFF.toInt(), 0x22FFFFFF, 0x70FFFFFF),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        if (rect.isEmpty) return
        if (!overlayOnly) {
            fill.shader = bodyShader
            c.drawRoundRect(rect, rad, rad, fill)
        }
        c.save()
        c.clipPath(clip)
        fill.shader = sheenShader
        c.drawRect(rect, fill)
        fill.shader = glowShader
        c.drawRect(rect, fill)
        c.restore()
        fill.shader = null
        rim.strokeWidth = strokePx
        rim.shader = rimShader
        c.drawRoundRect(rimRect, max(0f, rad - strokePx / 2f), max(0f, rad - strokePx / 2f), rim)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Slowly drifting colourful backdrop that makes the glass panels shine. */
class AuroraDrawable(private val dark: Boolean, private val animated: Boolean) : Drawable() {

    private class Blob(val color: Int, val x: Float, val y: Float, val r: Float) {
        var shader: Shader? = null
        var rad = 0f
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var baseShader: Shader? = null
    private var phase = 0f
    private var animator: ValueAnimator? = null
    private var lastTick = 0L
    private val blobs = listOf(
        Blob(0xFF7C4DFF.toInt(), 0.18f, 0.10f, 0.80f),
        Blob(0xFF2D8CFF.toInt(), 0.90f, 0.32f, 0.85f),
        Blob(0xFFFF4F9A.toInt(), 0.08f, 0.70f, 0.80f),
        Blob(0xFF14D8C4.toInt(), 0.88f, 0.93f, 0.75f)
    )

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onBoundsChange(b: Rect) {
        val w = b.width().toFloat(); val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        baseShader = LinearGradient(
            0f, 0f, 0f, h,
            if (dark) Color.parseColor("#0A0B1E") else Color.parseColor("#EEF1FF"),
            if (dark) Color.parseColor("#1A0F36") else Color.parseColor("#F7EEFF"),
            Shader.TileMode.CLAMP
        )
        val a = if (dark) 0x99 else 0x66
        for (bl in blobs) {
            bl.rad = bl.r * max(w, h) * 0.7f
            bl.shader = RadialGradient(0f, 0f, bl.rad, intArrayOf(withAlpha(bl.color, a), withAlpha(bl.color, 0)),
                null, Shader.TileMode.CLAMP)
        }
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val w = b.width().toFloat(); val h = b.height().toFloat()
        paint.shader = baseShader
        c.drawRect(b, paint)
        val t = phase * 2.0 * Math.PI
        blobs.forEachIndexed { i, bl ->
            val dx = (sin(t + i * 1.7) * 0.07 * w).toFloat()
            val dy = (cos(t + i * 2.3) * 0.05 * h).toFloat()
            c.save()
            c.translate(b.left + bl.x * w + dx, b.top + bl.y * h + dy)
            paint.shader = bl.shader
            c.drawCircle(0f, 0f, bl.rad, paint)
            c.restore()
        }
        paint.shader = null
    }

    private fun start() {
        if (!animated || animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 40000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastTick >= 60) {   // ~16 fps is plenty for a slow drift
                    lastTick = now
                    phase = it.animatedFraction
                    invalidateSelf()
                }
            }
            start()
        }
    }

    private fun stop() {
        animator?.cancel()
        animator = null
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val r = super.setVisible(visible, restart)
        if (visible) start() else stop()
        return r
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
