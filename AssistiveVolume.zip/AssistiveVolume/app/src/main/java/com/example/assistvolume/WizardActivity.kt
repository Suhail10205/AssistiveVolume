package com.example.assistvolume

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

/** Opens the best "auto-start" screen for the phone brand (Xiaomi, Oppo, Vivo, Huawei, ...). */
object Autostart {
    private val targets = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity",
        "com.asus.mobilemanager" to "com.asus.mobilemanager.autostart.AutoStartActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
    )

    fun open(ctx: Context) {
        for ((pkg, cls) in targets) {
            try {
                ctx.startActivity(Intent().setComponent(ComponentName(pkg, cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
}

class WizardActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var body: LinearLayout
    private lateinit var dots: LinearLayout
    private var step = 0
    private val last = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        applyAppTheme()
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        val root = lin().apply { setBackgroundColor(C.BG); setPadding(dp(22), dp(28), dp(22), dp(20)) }
        dots = lin(false).apply { gravity = Gravity.CENTER }
        root.addView(dots, LinearLayout.LayoutParams(MATCH, WRAP))
        body = lin().apply { gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(body) },
            LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        applyBars()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized) render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (step > 0) go(-1) else super.onBackPressed()
    }

    private fun go(delta: Int) {
        step += delta
        if (step == 3 && Build.VERSION.SDK_INT < 33) step += delta
        step = step.coerceIn(0, last)
        render()
    }

    private fun notifGranted() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun render() {
        body.removeAllViews()
        dots.removeAllViews()
        for (i in 0..last) {
            dots.addView(View(this).apply {
                background = if (i == step) gradient(4) else shape(C.STROKE, 4)
            }, LinearLayout.LayoutParams(if (i == step) dp(26) else dp(8), dp(8)).apply { marginEnd = dp(6) })
        }
        when (step) {
            0 -> {
                header("\u2728", "Welcome", "Assistive Volume adds floating shortcuts for power, volume, brightness and more. Let's set it up in under a minute.")
                bottom(next = "Get started", onNext = { go(1) }, skip = "Skip setup", onSkip = { finishWizard(false) })
            }
            1 -> perm("\uD83E\uDEA7", "Display over other apps",
                "Needed so the shortcut can float above every app on your phone.",
                Settings.canDrawOverlays(this), "Allow", true) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            2 -> perm("\u267F", "Accessibility service",
                "Lets the Power button open the power menu, lock the screen and take screenshots, and powers per-app rules. It never reads or stores your screen.",
                ControlService.instance != null, "Open settings", false) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            3 -> perm("\uD83D\uDD14", "Notifications",
                "Shows a tiny 'Running' notification so Android keeps the shortcut alive.",
                notifGranted(), "Allow", false) {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            4 -> {
                header("\uD83D\uDD0B", "Keep it running",
                    "So the shortcut starts by itself after a restart and is never stopped, set battery to 'Not optimized' and allow Auto-start (Xiaomi, Oppo, Vivo, Huawei and similar phones).")
                val c = card()
                c.addRow(navRow("\uD83D\uDD0B", C.AMBER, "Battery optimization", "Choose 'Not optimized' for this app") {
                    try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                })
                c.addRow(navRow("\uD83D\uDE80", C.PRIMARY, "Auto-start", "Allow the app to start after restart") { Autostart.open(this) })
                body.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(22) })
                bottom(next = "Next", onNext = { go(1) })
            }
            else -> {
                header("\uD83C\uDF89", "You're all set",
                    "Tap start to show the floating shortcut. You can change everything later from the app.")
                bottom(next = "Start shortcut", onNext = { finishWizard(true) })
            }
        }
    }

    private fun header(emoji: String, title: String, text: String) {
        body.addView(tv(emoji, 42f).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.PRIMARY, C.PRIMARY2))
                .apply { shape = GradientDrawable.OVAL }
        }, LinearLayout.LayoutParams(dp(96), dp(96)).apply { topMargin = dp(40) })
        body.addView(tv(title, 25f, C.TEXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(22), 0, dp(8)) })
        body.addView(tv(text, 14.5f, C.TEXT2).apply { gravity = Gravity.CENTER; setPadding(dp(6), 0, dp(6), 0) })
    }

    private fun perm(emoji: String, title: String, text: String, granted: Boolean, label: String, required: Boolean, grant: () -> Unit) {
        header(emoji, title, text)
        val status = if (granted) pill("\u2714 Granted", C.GREEN)
        else if (required) pill("Required", C.RED) else pill("Recommended", C.AMBER)
        body.addView(status, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(20) })
        if (!granted) {
            body.addView(primaryButton(label) { grant() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(20) })
        }
        if (granted) bottom(next = "Next", onNext = { go(1) })
        else if (required) bottom(next = null, onNext = null)
        else bottom(next = null, onNext = null, skip = "Skip for now", onSkip = { go(1) })
    }

    private fun bottom(next: String?, onNext: (() -> Unit)?, skip: String? = null, onSkip: (() -> Unit)? = null) {
        val row = lin(false).apply { setPadding(0, dp(26), 0, 0) }
        if (step > 0) row.addView(ghostButton("Back") { go(-1) }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(10) })
        if (skip != null && onSkip != null) {
            row.addView(ghostButton(skip, C.TEXT2) { onSkip() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(10) })
        }
        if (next != null && onNext != null) row.addView(primaryButton(next) { onNext() }, LinearLayout.LayoutParams(0, WRAP, 1.4f))
        body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun finishWizard(start: Boolean) {
        if (start) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
                step = 1; render(); return
            }
            p.enabled = true
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
        p.wizardDone = true
        finish()
    }
}
