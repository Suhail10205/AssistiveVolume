package com.example.assistvolume

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.Configuration
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object C {
    var light = false
    var BG = Color.parseColor("#0B0D12")
    var SURFACE = Color.parseColor("#151922")
    var SURFACE2 = Color.parseColor("#1D2330")
    var STROKE = Color.parseColor("#262D3D")
    val PRIMARY = Color.parseColor("#6C63FF")
    val PRIMARY2 = Color.parseColor("#2D8CFF")
    var PRIMARY_LIGHT = Color.parseColor("#A9A4FF")
    var TEXT = Color.parseColor("#F2F4F8")
    var TEXT2 = Color.parseColor("#8E96AA")
    var GREEN = Color.parseColor("#2ED573")
    var AMBER = Color.parseColor("#FFB020")
    var RED = Color.parseColor("#FF5C6C")

    private fun c(s: String) = Color.parseColor(s)

    /** mode: 0 Dark, 1 AMOLED black, 2 Light, 3 Auto (follow phone) */
    fun apply(mode: Int, ctx: Context) {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val m = if (mode == 3) (if (night) 0 else 2) else mode
        light = m == 2
        if (m == 2) {
            BG = c("#F2F4FA"); SURFACE = c("#FFFFFF"); SURFACE2 = c("#EEF0F8"); STROKE = c("#E0E4EF")
            TEXT = c("#14161F"); TEXT2 = c("#667089"); PRIMARY_LIGHT = c("#5B52E6")
            GREEN = c("#16A34A"); AMBER = c("#D97706"); RED = c("#E11D48")
        } else {
            BG = if (m == 1) c("#000000") else c("#0B0D12")
            SURFACE = if (m == 1) c("#0C0D10") else c("#151922")
            SURFACE2 = if (m == 1) c("#15171C") else c("#1D2330")
            STROKE = if (m == 1) c("#22252D") else c("#262D3D")
            TEXT = c("#F2F4F8"); TEXT2 = c("#8E96AA"); PRIMARY_LIGHT = c("#A9A4FF")
            GREEN = c("#2ED573"); AMBER = c("#FFB020"); RED = c("#FF5C6C")
        }
    }
}

/** Call before super.onCreate() */
fun Activity.applyAppTheme() {
    C.apply(Prefs(this).theme, this)
    setTheme(if (C.light) R.style.AppTheme_Light else R.style.AppTheme)
}

/** Call after setContentView() */
fun Activity.applyBars() {
    window.statusBarColor = C.BG
    window.navigationBarColor = C.SURFACE
    window.setBackgroundDrawable(ColorDrawable(C.BG))
    var f = window.decorView.systemUiVisibility
    f = if (C.light) f or 0x2000 or 0x10 else f and (0x2000 or 0x10).inv()
    window.decorView.systemUiVisibility = f
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.shape(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0) =
    GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.gradient(radiusDp: Int) =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.PRIMARY, C.PRIMARY2))
        .apply { cornerRadius = dp(radiusDp).toFloat() }

fun Context.tv(t: String, size: Float = 15f, color: Int = C.TEXT, bold: Boolean = false) =
    TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.lin(vertical: Boolean = true) =
    LinearLayout(this).apply { orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }

fun Context.card(): LinearLayout = lin().apply {
    background = shape(C.SURFACE, 20, C.STROKE, 1)
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
}

fun Context.sectionLabel(t: String) = tv(t.uppercase(), 11.5f, C.TEXT2, true).apply {
    letterSpacing = 0.08f
    setPadding(dp(6), dp(20), 0, dp(2))
}

fun Context.pageTitle(t: String, sub: String? = null): View {
    val b = lin().apply { setPadding(dp(6), dp(8), 0, dp(4)) }
    b.addView(tv(t, 28f, C.TEXT, true))
    if (sub != null) b.addView(tv(sub, 13.5f, C.TEXT2).apply { setPadding(0, dp(2), 0, 0) })
    return b
}

fun LinearLayout.addRow(v: View) {
    if (childCount > 0) {
        addView(View(context).apply { setBackgroundColor(C.STROKE) },
            LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = context.dp(70); marginEnd = context.dp(16) })
    }
    addView(v)
}

fun Context.badge(emoji: String, tint: Int): View = TextView(this).apply {
    text = emoji; textSize = 17f; gravity = Gravity.CENTER
    background = shape(Color.argb(46, Color.red(tint), Color.green(tint), Color.blue(tint)), 12)
    layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
}

private fun Context.ripple(radiusDp: Int = 0): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), null, ColorDrawable(Color.WHITE))

fun Context.settingRow(
    emoji: String, tint: Int, title: String, subtitle: String?, trailing: View?, onClick: (() -> Unit)? = null
): LinearLayout {
    val row = lin(false).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
    row.addView(badge(emoji, tint))
    val col = lin().apply { setPadding(dp(14), 0, dp(8), 0) }
    col.addView(tv(title, 15f, C.TEXT, true))
    if (subtitle != null) {
        val s = tv(subtitle, 12.5f, C.TEXT2).apply { setPadding(0, dp(2), 0, 0) }
        col.addView(s); row.tag = s
    }
    row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
    trailing?.let { row.addView(it) }
    if (onClick != null) { row.isClickable = true; row.background = ripple(); row.setOnClickListener { onClick() } }
    return row
}

fun Context.switchRow(
    emoji: String, tint: Int, title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit
): View {
    val sw = Switch(this).apply { isChecked = checked; setOnCheckedChangeListener { _, v -> onChange(v) } }
    return settingRow(emoji, tint, title, subtitle, sw) { sw.toggle() }
}

fun Context.choiceRow(
    emoji: String, tint: Int, title: String, options: List<String>, current: Int, onSelect: (Int) -> Unit
): View {
    var cur = current
    lateinit var row: LinearLayout
    row = settingRow(emoji, tint, title, options[cur], tv("\u203A", 22f, C.TEXT2)) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(options.toTypedArray(), cur) { d, which ->
                cur = which
                (row.tag as? TextView)?.text = options[which]
                onSelect(which)
                d.dismiss()
            }.show()
    }
    return row
}

fun Context.navRow(emoji: String, tint: Int, title: String, subtitle: String?, onClick: () -> Unit): View =
    settingRow(emoji, tint, title, subtitle, tv("\u203A", 22f, C.TEXT2), onClick)

fun Context.infoRow(emoji: String, tint: Int, title: String, value: String): View =
    settingRow(emoji, tint, title, null, tv(value, 13.5f, C.TEXT2).apply { maxWidth = dp(190); gravity = Gravity.END })

fun Context.seekRow(
    emoji: String, tint: Int, title: String, min: Int, max: Int, cur: Int, suffix: String, onChange: (Int) -> Unit
): View {
    val box = lin().apply { setPadding(dp(16), dp(12), dp(16), dp(8)) }
    val top = lin(false).apply { gravity = Gravity.CENTER_VERTICAL }
    top.addView(badge(emoji, tint))
    top.addView(tv(title, 15f, C.TEXT, true).apply { setPadding(dp(14), 0, 0, 0) },
        LinearLayout.LayoutParams(0, WRAP, 1f))
    val value = tv("$cur$suffix", 14f, C.PRIMARY_LIGHT, true)
    top.addView(value)
    val sb = SeekBar(this)
    sb.max = max - min
    sb.progress = cur - min
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
            val v = pr + min
            value.text = "$v$suffix"
            if (fromUser) onChange(v)
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    box.addView(top)
    box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })
    return box
}

private fun Context.chipPaint(chips: List<TextView>, selected: (Int) -> Boolean) {
    chips.forEachIndexed { i, c ->
        if (selected(i)) { c.background = gradient(18); c.setTextColor(Color.WHITE) }
        else { c.background = shape(C.SURFACE2, 18, C.STROKE, 1); c.setTextColor(C.TEXT2) }
    }
}

private fun Context.chipScroller(chips: List<TextView>): View {
    val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
    val row = lin(false).apply { setPadding(dp(16), dp(10), dp(16), dp(14)) }
    chips.forEach { row.addView(it, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) }) }
    scroll.addView(row)
    return scroll
}

private fun Context.chip(t: String) = tv(t, 13.5f, C.TEXT2, true).apply {
    gravity = Gravity.CENTER; setPadding(dp(16), dp(9), dp(16), dp(9))
}

fun Context.chipRow(options: List<String>, current: Int, onSelect: (Int) -> Unit): View {
    var sel = current
    val chips = options.map { chip(it) }
    chipPaint(chips) { it == sel }
    chips.forEachIndexed { i, c -> c.setOnClickListener { sel = i; chipPaint(chips) { j -> j == sel }; onSelect(i) } }
    return chipScroller(chips)
}

fun Context.multiChipRow(options: List<String>, mask: Int, onChange: (Int) -> Unit): View {
    var m = mask
    val chips = options.map { chip(it) }
    chipPaint(chips) { (m and (1 shl it)) != 0 }
    chips.forEachIndexed { i, c ->
        c.setOnClickListener {
            m = m xor (1 shl i)
            chipPaint(chips) { j -> (m and (1 shl j)) != 0 }
            onChange(m)
        }
    }
    return chipScroller(chips)
}

fun Context.swatchRow(colors: List<Int>, selected: Int?, onSelect: (Int) -> Unit): View {
    val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
    val row = lin(false).apply { setPadding(dp(16), dp(10), dp(16), dp(14)) }
    val dots = mutableListOf<View>()
    fun paint(sel: Int?) {
        dots.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(colors[i])
                if (colors[i] == sel) setStroke(dp(3), C.PRIMARY_LIGHT) else setStroke(dp(1), C.STROKE)
            }
        }
    }
    colors.forEach { c ->
        val v = View(this)
        v.setOnClickListener { paint(c); onSelect(c) }
        dots.add(v)
        row.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(12) })
    }
    paint(selected)
    scroll.addView(row)
    return scroll
}

fun Context.primaryButton(text: String, onClick: () -> Unit): View = tv(text, 15f, Color.WHITE, true).apply {
    gravity = Gravity.CENTER; setPadding(dp(18), dp(14), dp(18), dp(14))
    background = gradient(14)
    setOnClickListener { onClick() }
}

fun Context.ghostButton(text: String, color: Int = C.PRIMARY_LIGHT, onClick: () -> Unit): View =
    tv(text, 14.5f, color, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(18), dp(13), dp(18), dp(13))
        background = shape(Color.TRANSPARENT, 14, color, 1)
        setOnClickListener { onClick() }
    }

fun Context.pill(text: String, color: Int): TextView = tv(text, 12f, color, true).apply {
    gravity = Gravity.CENTER; setPadding(dp(12), dp(6), dp(12), dp(6))
    background = shape(Color.argb(36, Color.red(color), Color.green(color), Color.blue(color)), 12)
}

fun Context.infoDialog(title: String, msg: String) {
    AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
}

/** Bottom navigation icon drawn with canvas paths. kind: 0 Home, 1 Style, 2 Behavior, 3 Settings, 4 About */
class NavIcon(ctx: Context, private val kind: Int) : View(ctx) {
    var active = false
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(2).toFloat()
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = min(width, height) * 0.30f
        p.color = if (active) Color.WHITE else C.TEXT2
        p.style = Paint.Style.STROKE
        when (kind) {
            0 -> {
                val roof = Path().apply {
                    moveTo(cx - r * 1.15f, cy - r * 0.05f); lineTo(cx, cy - r * 1.1f); lineTo(cx + r * 1.15f, cy - r * 0.05f)
                }
                c.drawPath(roof, p)
                val body = Path().apply {
                    moveTo(cx - r * 0.8f, cy - r * 0.25f); lineTo(cx - r * 0.8f, cy + r)
                    lineTo(cx + r * 0.8f, cy + r); lineTo(cx + r * 0.8f, cy - r * 0.25f)
                }
                c.drawPath(body, p)
            }
            1 -> {
                val s = r * 0.95f; val g = r * 0.16f
                for (dx in intArrayOf(-1, 1)) for (dy in intArrayOf(-1, 1)) {
                    val l = if (dx < 0) cx - g - s else cx + g
                    val t = if (dy < 0) cy - g - s else cy + g
                    c.drawRoundRect(RectF(l, t, l + s, t + s), r * 0.25f, r * 0.25f, p)
                }
            }
            2 -> {
                val b = Path().apply {
                    moveTo(cx + r * 0.25f, cy - r * 1.2f); lineTo(cx - r * 0.65f, cy + r * 0.1f); lineTo(cx - r * 0.02f, cy + r * 0.1f)
                    lineTo(cx - r * 0.25f, cy + r * 1.2f); lineTo(cx + r * 0.65f, cy - r * 0.1f); lineTo(cx + r * 0.02f, cy - r * 0.1f)
                    close()
                }
                c.drawPath(b, p)
            }
            3 -> {
                c.drawCircle(cx, cy, r * 0.4f, p)
                c.drawCircle(cx, cy, r * 0.85f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    c.drawLine(cx + (r * 0.85f * cos(a)).toFloat(), cy + (r * 0.85f * sin(a)).toFloat(),
                        cx + (r * 1.2f * cos(a)).toFloat(), cy + (r * 1.2f * sin(a)).toFloat(), p)
                }
            }
            else -> {
                c.drawCircle(cx, cy, r * 1.15f, p)
                c.drawLine(cx, cy - r * 0.05f, cx, cy + r * 0.6f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy - r * 0.5f, context.dp(1).toFloat() * 1.6f, p)
            }
        }
    }
}
