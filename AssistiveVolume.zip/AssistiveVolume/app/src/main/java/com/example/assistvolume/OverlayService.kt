package com.example.assistvolume

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.roundToInt

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var p: Prefs
    private var root: View? = null
    private var slider: VolumeSliderView? = null
    private var lp: WindowManager.LayoutParams? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = syncSlider()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        p = Prefs(this)
        val f = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        build()
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("avb", "Assistive volume", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "avb")
            .setContentTitle("Assistive volume button")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun removeOverlay() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; slider = null
    }

    private fun build() {
        removeOverlay()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        val style = p.style
        val d = dp(24) + dp(p.btnSize) * 4 / 5
        val (btnBg, btnFg) = if (p.applyStyleColors) when (style) {
            1 -> 0xFF1A73E8.toInt() to Color.WHITE
            else -> Color.WHITE to 0xFF1A73E8.toInt()
        } else {
            val lum = (Color.red(p.bgColor) * 0.299 + Color.green(p.bgColor) * 0.587 + Color.blue(p.bgColor) * 0.114)
            p.bgColor to (if (lum > 140) Color.BLACK else Color.WHITE)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = p.posX; y = p.posY }
        lp = params

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val plus = makeButton("+", d, btnBg, btnFg) { change(AudioManager.ADJUST_RAISE) }
        val minus = makeButton("\u2212", d, btnBg, btnFg) { change(AudioManager.ADJUST_LOWER) }
        col.addView(plus, LinearLayout.LayoutParams(d, d).apply { bottomMargin = dp(12) })
        col.addView(minus, LinearLayout.LayoutParams(d, d))
        panel.addView(col)

        val sv = VolumeSliderView(this, style) { f ->
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).roundToInt(), uiFlag())
        }
        sv.alpha = 1f - p.sliderTransparency / 100f
        val sw = if (style == 0) dp(36) else dp(56)
        panel.addView(sv, LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply { marginStart = dp(12) })
        slider = sv

        root = panel
        wm.addView(panel, params)
        syncSlider()
    }

    private fun uiFlag() = if (p.useSystemSlider) AudioManager.FLAG_SHOW_UI else 0

    private fun change(dir: Int) {
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, uiFlag())
        syncSlider()
    }

    private fun syncSlider() {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        slider?.fraction = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    private fun makeButton(sym: String, d: Int, bg: Int, fg: Int, onTap: () -> Unit): View {
        val tv = TextView(this).apply {
            text = sym
            gravity = Gravity.CENTER
            setTextColor(fg)
            textSize = d / resources.displayMetrics.density * 0.5f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
            alpha = 1f - p.btnTransparency / 100f
        }
        var downX = 0f; var downY = 0f; var sx = 0; var sy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            val params = lp ?: return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; sx = params.x; sy = params.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> if (!p.pinned) {
                    val mx = e.rawX - downX; val my = e.rawY - downY
                    if (moved || hypot(mx, my) > dp(8)) {
                        moved = true
                        params.x = (sx + mx).toInt(); params.y = (sy + my).toInt()
                        root?.let { wm.updateViewLayout(it, params) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { p.posX = params.x; p.posY = params.y } else onTap()
                }
            }
            true
        }
        return tv
    }
}
