package com.example.assistvolume

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.assistvolume.SHOW"
    }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var p: Prefs
    private var root: View? = null
    private var slider: VolumeSliderView? = null
    private var multiPanel: LinearLayout? = null
    private val multiSliders = mutableListOf<Pair<Int, VolumeSliderView>>()
    private var lp: WindowManager.LayoutParams? = null
    private var hidden = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { if (p.sliderAutoHide) slider?.visibility = View.GONE }
    private val hideMultiRunnable = Runnable { closeMulti() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { syncSlider(); showSliderTemporarily() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        p = Prefs(this)
        val f = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        hidden = false
        startFg()
        build()
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    // ---------------- notification ----------------
    private fun buildNotification(): Notification {
        val b = Notification.Builder(this, "avb")
            .setContentTitle("Assistive volume button")
            .setContentText(if (hidden) "Buttons hidden" else "Running")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
        if (hidden) {
            val pi = PendingIntent.getForegroundService(
                this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_SHOW),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Show buttons", pi
                ).build()
            )
        }
        return b.build()
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("avb", "Assistive volume", NotificationManager.IMPORTANCE_MIN)
        )
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(hideMultiRunnable)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; slider = null; multiPanel = null
        multiSliders.clear()
    }

    // ---------------- actions ----------------
    private fun global(action: Int) {
        val s = ControlService.instance
        if (s == null) {
            Toast.makeText(this, "Turn on 'Assistive volume button' in Accessibility settings", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        if (Build.VERSION.SDK_INT < 28 &&
            (action == AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN || action == AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        ) {
            Toast.makeText(this, "Needs Android 9 or newer", Toast.LENGTH_SHORT).show(); return
        }
        s.performGlobalAction(action)
    }

    private fun hideButtons() {
        hidden = true
        removeOverlay()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification())
    }

    private fun powerLongAction() {
        when (p.powerLong) {
            0 -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            1 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            else -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    private fun multiLongAction() {
        when (p.multiLong) {
            0 -> hideButtons()
            1 -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            2 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            3 -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, uiFlag())
            else -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    // ---------------- levels ----------------
    private fun uiFlag() = if (p.useSystemSlider) AudioManager.FLAG_SHOW_UI else 0

    private fun level(id: Int): Float {
        val s = Sliders.streams[id]
        return if (s == -1) {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        } else {
            am.getStreamVolume(s).toFloat() / am.getStreamMaxVolume(s).coerceAtLeast(1)
        }
    }

    private fun setLevel(id: Int, f: Float) {
        val s = Sliders.streams[id]
        try {
            if (s == -1) {
                if (Settings.System.canWrite(this)) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                        (f * 255).roundToInt().coerceIn(1, 255))
                } else {
                    Toast.makeText(this, "Allow 'Modify system settings' in the app", Toast.LENGTH_SHORT).show()
                }
            } else {
                val max = am.getStreamMaxVolume(s)
                am.setStreamVolume(s, (f * max).roundToInt(), uiFlag())
            }
        } catch (_: SecurityException) {
            Toast.makeText(this, "Not allowed (check Do Not Disturb)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun syncSlider() {
        slider?.fraction = level(0)
        multiSliders.forEach { (id, v) -> v.fraction = level(id) }
    }

    private fun change(dir: Int) {
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, uiFlag())
        syncSlider()
        showSliderTemporarily()
    }

    // ---------------- show / hide sliders ----------------
    private fun multiVisible() = multiPanel?.visibility == View.VISIBLE

    private fun showSliderTemporarily() {
        val s = slider ?: return
        if (!p.sliderAutoHide || multiVisible()) return
        s.visibility = View.VISIBLE
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 2000)
    }

    private fun toggleMulti() {
        val mp = multiPanel ?: return
        if (multiVisible()) closeMulti() else {
            syncSlider()
            slider?.visibility = View.GONE
            mp.visibility = View.VISIBLE
            showMultiTemporarily()
        }
    }

    private fun showMultiTemporarily() {
        handler.removeCallbacks(hideMultiRunnable)
        handler.postDelayed(hideMultiRunnable, 5000)
    }

    private fun closeMulti() {
        multiPanel?.visibility = View.GONE
        handler.removeCallbacks(hideMultiRunnable)
        slider?.visibility = if (p.sliderAutoHide) View.GONE else View.VISIBLE
    }

    // ---------------- build overlay ----------------
    private fun build() {
        removeOverlay()
        if (hidden) return
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        val style = p.style
        val d = dp(24) + dp(p.btnSize) * 4 / 5
        val (btnBg, btnFg) = if (p.applyStyleColors) when (style) {
            1 -> 0xFF1A73E8.toInt() to Color.WHITE
            else -> Color.WHITE to 0xFF1A73E8.toInt()
        } else {
            val lum = (Color.red(p.bgColor) * 0.299 + Color.green(p.bgColor) * 0.587 + Color.blue(p.bgColor) * 0.114)
            p.bgColor to (if (lum > 140) Color.BLACK else Color.WHITE)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = p.posX; y = p.posY }
        lp = params

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val gap = dp(12)
        fun addBtn(v: View) {
            col.addView(v, LinearLayout.LayoutParams(d, d).apply { topMargin = if (col.childCount > 0) gap else 0 })
        }

        val powerBtn = makeButton(null, android.R.drawable.ic_lock_power_off, d, 0xFFD32F2F.toInt(), Color.WHITE,
            onTap = { global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) },
            onLong = { powerLongAction() })

        if (p.powerEnabled && p.powerPos == 0) addBtn(powerBtn)
        addBtn(makeButton("+", null, d, btnBg, btnFg, onTap = { change(AudioManager.ADJUST_RAISE) }))
        addBtn(makeButton("\u2212", null, d, btnBg, btnFg, onTap = { change(AudioManager.ADJUST_LOWER) }))
        if (p.powerEnabled && p.powerPos == 1) addBtn(powerBtn)
        if (p.multiEnabled) {
            addBtn(makeButton("\u2630", null, d, btnBg, btnFg,
                onTap = { toggleMulti() }, onLong = { multiLongAction() }))
        }
        panel.addView(col)

        val sw = if (style == 0) dp(36) else dp(56)

        // single media slider (shown only while adjusting)
        val sv = VolumeSliderView(this, style, Sliders.icons[0]) { f ->
            setLevel(0, f)
            showSliderTemporarily()
        }
        sv.alpha = 1f - p.sliderTransparency / 100f
        panel.addView(sv, LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply { marginStart = dp(12) })
        slider = sv
        if (p.sliderAutoHide) sv.visibility = View.GONE

        // multi sliders panel
        if (p.multiEnabled) {
            val mp = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
            for (id in Sliders.names.indices) {
                if (p.multiMask and (1 shl id) == 0) continue
                val v = VolumeSliderView(this, style, Sliders.icons[id]) { f ->
                    setLevel(id, f)
                    showMultiTemporarily()
                }
                v.alpha = 1f - p.sliderTransparency / 100f
                mp.addView(v, LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply { marginStart = dp(10) })
                multiSliders.add(id to v)
            }
            panel.addView(mp)
            multiPanel = mp
        }

        root = panel
        wm.addView(panel, params)
        syncSlider()
    }

    private fun makeButton(
        sym: String?, iconRes: Int?, d: Int, bg: Int, fg: Int,
        onTap: () -> Unit, onLong: (() -> Unit)? = null
    ): View {
        val v: View = if (iconRes != null) {
            ImageView(this).apply {
                setImageResource(iconRes)
                setColorFilter(fg)
                val pd = d / 4
                setPadding(pd, pd, pd, pd)
            }
        } else {
            TextView(this).apply {
                text = sym
                gravity = Gravity.CENTER
                setTextColor(fg)
                textSize = d / resources.displayMetrics.density * 0.5f
            }
        }
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
        v.alpha = 1f - p.btnTransparency / 100f

        var downX = 0f; var downY = 0f; var sx = 0; var sy = 0
        var moved = false; var longFired = false
        val longRun = Runnable { if (!moved) { longFired = true; onLong?.invoke() } }

        v.setOnTouchListener { _, e ->
            val params = lp ?: return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; sx = params.x; sy = params.y
                    moved = false; longFired = false
                    if (onLong != null) handler.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> if (!p.pinned) {
                    val mx = e.rawX - downX; val my = e.rawY - downY
                    if (moved || hypot(mx, my) > dp(8)) {
                        moved = true
                        handler.removeCallbacks(longRun)
                        params.x = (sx + mx).toInt(); params.y = (sy + my).toInt()
                        root?.let { wm.updateViewLayout(it, params) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (moved) { p.posX = params.x; p.posY = params.y }
                    else if (!longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
            }
            true
        }
        return v
    }
}
