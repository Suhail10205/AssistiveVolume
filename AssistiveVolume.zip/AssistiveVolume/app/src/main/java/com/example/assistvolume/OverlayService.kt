package com.example.assistvolume

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.assistvolume.SHOW"
        @Volatile var instance: OverlayService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var p: Prefs
    private var root: View? = null
    private var slider: VolumeSliderView? = null
    private var multiPanel: LinearLayout? = null
    private val multiSliders = mutableListOf<Pair<Int, VolumeSliderView>>()
    private var lp: WindowManager.LayoutParams? = null
    private var hidden = false
    private var appHidden = false
    private var lastPkg: String? = null
    private var kbTop = -1
    private var darkView: View? = null
    private var enhancer: LoudnessEnhancer? = null
    private var sensorManager: SensorManager? = null
    private var proxListener: SensorEventListener? = null
    private var lastNear: Boolean? = null
    private val shown = HashMap<View, Boolean>()
    private var sliderW = 0
    private var multiW = 0

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { if (p.sliderAutoHide) slider?.let { setShown(it, false, sliderBase(), sliderW) } }
    private val hideMultiRunnable = Runnable { closeMulti() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { syncSlider(); showSliderTemporarily() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        p = Prefs(this)
        val f = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fresh = root == null
        hidden = false
        startFg()
        updateDark(p.dark)
        build(fresh)
        setupProximity()
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        stopProximity()
        removeOverlay()
        darkView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        darkView = null
        try { enhancer?.release() } catch (_: Exception) {}
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    // ---------------- notification ----------------
    private fun buildNotification(): Notification {
        val b = Notification.Builder(this, "avb")
            .setContentTitle("Assistive Volume")
            .setContentText(if (hidden) "Buttons hidden" else "Running")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
        if (hidden) {
            val pi = PendingIntent.getForegroundService(
                this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_SHOW),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Show buttons", pi
                ).build()
            )
        }
        return b.build()
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("avb", "Assistive Volume", NotificationManager.IMPORTANCE_MIN)
        )
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(hideMultiRunnable)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; slider = null; multiPanel = null
        multiSliders.clear()
        shown.clear()
    }

    // ---------------- animations ----------------
    private fun sliderBase() = 1f - p.sliderTransparency / 100f

    private fun resetProps(v: View, base: Float) {
        v.alpha = base; v.translationX = 0f; v.scaleX = 1f; v.scaleY = 1f; v.rotationY = 0f
    }

    private fun hiddenState(v: View, w: Int, right: Boolean) {
        when (p.animType) {
            0 -> v.alpha = 0f
            1 -> { v.alpha = 0f; v.translationX = if (right) w.toFloat() else -w.toFloat() }
            2 -> { v.alpha = 0f; v.scaleX = 0.3f; v.scaleY = 0.3f }
            3 -> { v.alpha = 0f; v.scaleX = 0f; v.scaleY = 0f }
            else -> { v.alpha = 0f; v.rotationY = if (right) -90f else 90f }
        }
    }

    private fun animateView(
        v: View, show: Boolean, base: Float, wHint: Int, edgePivot: Boolean = true, end: (() -> Unit)? = null
    ) {
        v.animate().cancel()
        val right = p.side == 1
        val w = if (v.width > 0) v.width else wHint.coerceAtLeast(dp(40))
        v.pivotX = if (edgePivot) (if (right) w.toFloat() else 0f) else w / 2f
        v.pivotY = (if (v.height > 0) v.height else dp(100)) / 2f
        v.cameraDistance = 9000f * resources.displayMetrics.density
        val dur = if (p.animEnabled) p.animDuration.toLong() else 0L
        val type = p.animType

        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.visibility = View.VISIBLE
                if (dur > 0) hiddenState(v, w, right)
            }
            if (dur == 0L) { resetProps(v, base); end?.invoke(); return }
            v.animate().alpha(base).translationX(0f).scaleX(1f).scaleY(1f).rotationY(0f)
                .setDuration(dur)
                .setInterpolator(if (type == 3) OvershootInterpolator(2.4f) else DecelerateInterpolator())
                .withEndAction { end?.invoke() }.start()
        } else {
            if (dur == 0L) { v.visibility = View.GONE; resetProps(v, base); end?.invoke(); return }
            val a = v.animate().alpha(0f).setDuration(dur).setInterpolator(AccelerateInterpolator())
            when (type) {
                1 -> a.translationX(if (right) w.toFloat() else -w.toFloat())
                2 -> a.scaleX(0.3f).scaleY(0.3f)
                3 -> a.scaleX(0f).scaleY(0f)
                4 -> a.rotationY(if (right) -90f else 90f)
            }
            a.withEndAction { v.visibility = View.GONE; resetProps(v, base); end?.invoke() }.start()
        }
    }

    private fun setShown(v: View?, show: Boolean, base: Float, wHint: Int) {
        v ?: return
        if (shown[v] == show) return
        shown[v] = show
        animateView(v, show, base, wHint)
    }

    private fun hideInstant(v: View?) {
        v ?: return
        v.animate().cancel()
        v.visibility = View.GONE
        resetProps(v, if (v === slider) sliderBase() else 1f)
        shown[v] = false
    }

    /** Used by the "Preview animation" button in the app. */
    fun previewAnimation() {
        handler.post {
            val r = root ?: return@post
            animateView(r, false, 1f, r.width, false) {
                animateView(r, true, 1f, r.width, false)
            }
        }
    }

    // ---------------- actions ----------------
    private fun global(action: Int) {
        val s = ControlService.instance
        if (s == null) {
            Toast.makeText(this, "Turn on 'Assistive Volume' in Accessibility settings", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        if (Build.VERSION.SDK_INT < 28 &&
            (action == AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN || action == AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        ) {
            Toast.makeText(this, "Needs Android 9 or newer", Toast.LENGTH_SHORT).show(); return
        }
        s.performGlobalAction(action)
    }

    private fun hideButtons() {
        val r = root
        val finish = {
            hidden = true
            removeOverlay()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification())
        }
        if (r == null) finish() else animateView(r, false, 1f, r.width, false) { finish() }
    }

    private fun powerLongAction() {
        when (p.powerLong) {
            0 -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            1 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            else -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    private fun multiLongAction() {
        when (p.multiLong) {
            0 -> hideButtons()
            1 -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            2 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            3 -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, uiFlag())
            else -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    // ---------------- levels ----------------
    private fun uiFlag() = if (p.useSystemSlider) AudioManager.FLAG_SHOW_UI else 0

    private fun level(id: Int): Float {
        val s = Sliders.streams[id]
        return if (s == -1) {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        } else if (s == -2) {
            p.boost
        } else if (s == -3) {
            p.dark
        } else {
            am.getStreamVolume(s).toFloat() / am.getStreamMaxVolume(s).coerceAtLeast(1)
        }
    }

    private fun setLevel(id: Int, f: Float) {
        val s = Sliders.streams[id]
        try {
            if (s == -2) {
                p.boost = f; updateBoost(f)
            } else if (s == -3) {
                p.dark = f; updateDark(f)
            } else if (s == -1) {
                if (Settings.System.canWrite(this)) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                        (f * 255).roundToInt().coerceIn(1, 255))
                } else {
                    Toast.makeText(this, "Allow 'Modify system settings' in the app", Toast.LENGTH_SHORT).show()
                }
            } else {
                val max = am.getStreamMaxVolume(s)
                am.setStreamVolume(s, (f * max).roundToInt(), uiFlag())
            }
        } catch (_: SecurityException) {
            Toast.makeText(this, "Not allowed (check Do Not Disturb)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun syncSlider() {
        slider?.fraction = level(0)
        multiSliders.forEach { (id, v) -> v.fraction = level(id) }
    }

    private fun change(dir: Int) {
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, uiFlag())
        syncSlider()
        showSliderTemporarily()
    }

    // ---------------- show / hide sliders ----------------
    private fun multiVisible() = multiPanel?.let { shown[it] == true } ?: false

    private fun showSliderTemporarily() {
        val s = slider ?: return
        if (!p.sliderAutoHide || multiVisible()) return
        setShown(s, true, sliderBase(), sliderW)
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, p.hideDelay * 1000L)
    }

    private fun toggleMulti() {
        val mp = multiPanel ?: return
        if (multiVisible()) closeMulti() else {
            syncSlider()
            handler.removeCallbacks(hideRunnable)
            hideInstant(slider)
            setShown(mp, true, 1f, multiW)
            showMultiTemporarily()
        }
    }

    private fun showMultiTemporarily() {
        handler.removeCallbacks(hideMultiRunnable)
        handler.postDelayed(hideMultiRunnable, maxOf(p.hideDelay, 3) * 1000L)
    }

    private fun closeMulti() {
        handler.removeCallbacks(hideMultiRunnable)
        multiPanel?.let { setShown(it, false, 1f, multiW) }
        if (!p.sliderAutoHide) slider?.let { setShown(it, true, sliderBase(), sliderW) }
    }

    /** Called when the user touches anywhere outside our buttons. */
    private fun dismissSliders() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(hideMultiRunnable)
        if (multiVisible()) closeMulti()
        if (p.sliderAutoHide) slider?.let { setShown(it, false, sliderBase(), sliderW) }
    }

    // ---------------- dark overlay & booster ----------------
    private fun updateDark(f: Float) {
        if (!Settings.canDrawOverlays(this)) return
        if (f < 0.02f) {
            darkView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            darkView = null
            return
        }
        if (darkView == null) {
            val v = View(this).apply { setBackgroundColor(Color.BLACK) }
            val dp2 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(v, dp2)
            darkView = v
            val r = root; val l = lp
            if (r != null && l != null) {
                try { wm.removeView(r); wm.addView(r, l) } catch (_: Exception) {}
            }
        }
        darkView?.alpha = f * 0.85f
    }

    private fun updateBoost(f: Float) {
        try {
            if (enhancer == null) enhancer = LoudnessEnhancer(0)
            enhancer?.setTargetGain((f * 1000).toInt())
            enhancer?.enabled = f > 0.02f
        } catch (_: Exception) {
            Toast.makeText(this, "Media booster is not supported on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------- per app / keyboard (called by ControlService) ----------------
    fun onForegroundApp(pkg: String) {
        if (!p.perApp) { setAppHidden(false); return }
        if (pkg == lastPkg) return
        lastPkg = pkg
        val cfg = p.appCfg(pkg)
        setAppHidden(cfg?.hide == true)
        if (cfg != null) {
            if (cfg.media >= 0) setLevel(0, cfg.media / 100f)
            if (cfg.bright >= 0) setLevel(4, cfg.bright / 100f)
            syncSlider()
        }
    }

    private fun setAppHidden(h: Boolean) {
        if (appHidden == h) return
        appHidden = h
        root?.let { r -> setShown(r, !h, 1f, r.width) }
    }

    fun onKeyboard(top: Int) {
        kbTop = top
        applyPosition()
    }

    private fun applyPosition() {
        val r = root ?: return
        val params = lp ?: return
        var y = p.posY
        if (p.keyboardSensitive && kbTop > 0) {
            val maxY = kbTop - r.height - dp(8)
            if (y > maxY) y = maxY.coerceAtLeast(0)
        }
        if (params.y != y) {
            params.y = y
            try { wm.updateViewLayout(r, params) } catch (_: Exception) {}
        }
    }

    // ---------------- proximity sensor ----------------
    private fun stopProximity() {
        proxListener?.let { sensorManager?.unregisterListener(it) }
        proxListener = null
        lastNear = null
    }

    private fun setupProximity() {
        stopProximity()
        if (p.proxNear == 0 && p.proxAway == 0) return
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY, true)
            ?: sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) ?: return
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val near = e.values[0] < sensor.maximumRange.coerceAtMost(5f)
                val prev = lastNear
                lastNear = near
                if (prev == null || prev == near) return
                if (near && p.proxNear == 1 && Build.VERSION.SDK_INT >= 28)
                    ControlService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                if (!near && p.proxAway == 1) wakeScreen()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager = sm
        proxListener = l
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "avb:prox"
        ).acquire(3000)
    }

    // ---------------- build overlay ----------------
    private fun build(animateIn: Boolean) {
        removeOverlay()
        if (hidden) return
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        val style = p.style
        val right = p.side == 1
        val d = dp(24) + dp(p.btnSize) * 4 / 5
        val accent = p.accent()
        val sliderAccent = p.sliderAccent()
        val red = 0xFFE53935.toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
            x = dp(4); y = p.posY
        }
        lp = params

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panel.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && p.tapOutside) dismissSliders()
            false
        }

        // ---- button column ----
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val gap = dp(p.btnGap)
        fun addBtn(v: View) {
            col.addView(v, LinearLayout.LayoutParams(d, d).apply { topMargin = if (col.childCount > 0) gap else 0 })
        }
        if (p.powerEnabled) {
            addBtn(makeButton(StyledButton.POWER, red,
                onTap = { global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) },
                onLong = { powerLongAction() }))
        }
        if (p.showVolButtons) {
            addBtn(makeButton(StyledButton.PLUS, accent, onTap = { change(AudioManager.ADJUST_RAISE) }))
            addBtn(makeButton(StyledButton.MINUS, accent, onTap = { change(AudioManager.ADJUST_LOWER) }))
        }
        if (p.multiEnabled) {
            addBtn(makeButton(StyledButton.SLIDERS, accent,
                onTap = { toggleMulti() }, onLong = { multiLongAction() }))
        }

        val sw = dp(p.sliderWidth)
        val g12 = dp(12)
        sliderW = sw + g12

        // ---- single media slider (appears while adjusting) ----
        val sv = VolumeSliderView(this, style, Sliders.icons[0]) { f ->
            setLevel(0, f)
            showSliderTemporarily()
        }
        sv.accent = sliderAccent
        sv.alpha = sliderBase()
        slider = sv
        val svLp = LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply {
            if (right) marginEnd = g12 else marginStart = g12
        }

        // ---- multi sliders panel ----
        var mp: LinearLayout? = null
        if (p.multiEnabled) {
            val m = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
            var n = 0
            for (id in Sliders.names.indices) {
                if (p.multiMask and (1 shl id) == 0) continue
                val v = VolumeSliderView(this, style, Sliders.icons[id]) { f ->
                    setLevel(id, f)
                    showMultiTemporarily()
                }
                v.accent = sliderAccent
                v.alpha = sliderBase()
                m.addView(v, LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply {
                    if (right) marginEnd = g12 else marginStart = g12
                })
                multiSliders.add(id to v); n++
            }
            multiW = n * (sw + g12)
            mp = m
            multiPanel = m
            shown[m] = false
        }

        // order depends on which edge we are on: buttons always touch the edge
        if (!right) {
            panel.addView(col); panel.addView(sv, svLp); mp?.let { panel.addView(it) }
        } else {
            mp?.let { panel.addView(it) }; panel.addView(sv, svLp); panel.addView(col)
        }

        sv.visibility = if (p.sliderAutoHide) View.GONE else View.VISIBLE
        shown[sv] = !p.sliderAutoHide

        root = panel
        panel.visibility = if (appHidden) View.GONE else View.VISIBLE
        shown[panel] = !appHidden
        val doAnim = animateIn && !appHidden && p.animEnabled
        if (doAnim) hiddenState(panel, dp(80), right)
        wm.addView(panel, params)
        syncSlider()
        panel.post {
            applyPosition()
            if (doAnim) animateView(panel, true, 1f, panel.width, false)
        }
    }

    // ---------------- drag along the screen edges ----------------
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun startDrag(params: WindowManager.LayoutParams) {
        val r = root ?: return
        if ((params.gravity and Gravity.RELATIVE_HORIZONTAL_GRAVITY_MASK) == Gravity.END) {
            params.x = screenW() - r.width - params.x
            params.gravity = Gravity.TOP or Gravity.START
        }
    }

    private fun endDrag(params: WindowManager.LayoutParams) {
        val r = root ?: return
        val newSide = if (params.x + r.width / 2 < screenW() / 2) 0 else 1
        val margin = dp(4)
        val targetX = if (newSide == 0) margin else screenW() - r.width - margin
        val targetY = params.y.coerceIn(0, (screenH() - r.height).coerceAtLeast(0))
        val startX = params.x; val startY = params.y
        p.side = newSide; p.posY = targetY
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 180
            addUpdateListener {
                val f = it.animatedValue as Float
                params.x = startX + ((targetX - startX) * f).toInt()
                params.y = startY + ((targetY - startY) * f).toInt()
                try { wm.updateViewLayout(r, params) } catch (_: Exception) {}
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { build(false) }
            })
            start()
        }
    }

    private fun makeButton(kind: Int, accent: Int, onTap: () -> Unit, onLong: (() -> Unit)? = null): View {
        val v = StyledButton(this, kind, p.btnStyle, p.btnShape, accent, p.iconScale / 100f)
        v.alpha = 1f - p.btnTransparency / 100f

        var downX = 0f; var downY = 0f; var sx = 0; var sy = 0
        var dragging = false; var longFired = false
        val longRun = Runnable { if (!dragging) { longFired = true; onLong?.invoke() } }

        v.setOnTouchListener { _, e ->
            val params = lp ?: return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    dragging = false; longFired = false
                    if (onLong != null) handler.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> if (!p.pinned) {
                    if (dragging || hypot(e.rawX - downX, e.rawY - downY) > dp(8)) {
                        if (!dragging) {
                            dragging = true
                            handler.removeCallbacks(longRun)
                            startDrag(params)
                            sx = params.x; sy = params.y
                            downX = e.rawX; downY = e.rawY
                        }
                        params.x = (sx + (e.rawX - downX)).toInt()
                        params.y = (sy + (e.rawY - downY)).toInt()
                        root?.let { try { wm.updateViewLayout(it, params) } catch (_: Exception) {} }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (dragging) endDrag(params)
                    else if (!longFired) {
                        if (p.haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        onTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
            }
            true
        }
        return v
    }
}
