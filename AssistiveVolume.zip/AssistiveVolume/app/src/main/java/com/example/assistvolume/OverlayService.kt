package com.example.assistvolume

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.assistvolume.SHOW"
        const val ACTION_HIDE = "com.example.assistvolume.HIDE"
        const val ACTION_TOGGLE = "com.example.assistvolume.TOGGLE"
        const val ACTION_BANKING = "com.example.assistvolume.BANKING"
        val AUTO_SHOW_MIN = intArrayOf(0, 1, 5, 15, 30)
        @Volatile var instance: OverlayService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var p: Prefs
    private var root: View? = null
    private var slider: VolumeSliderView? = null
    private var multiPanel: LinearLayout? = null
    private val multiSliders = mutableListOf<Pair<Int, VolumeSliderView>>()
    private var lp: WindowManager.LayoutParams? = null
    private var hidden = false
    private var darkSuspended = false
    private var peekView: View? = null
    private val autoShowRunnable = Runnable { if (hidden) setHidden(false) }
    private var appHidden = false
    private var lastPkg: String? = null
    private var kbTop = -1
    private var darkView: View? = null
    private var darkParams: WindowManager.LayoutParams? = null
    private var enhancer: LoudnessEnhancer? = null
    private var sensorManager: SensorManager? = null
    private var proxListener: SensorEventListener? = null
    private var lastNear: Boolean? = null
    private val shown = HashMap<View, Boolean>()
    private var sliderW = 0
    private var multiW = 0
    private var autoHidden = false
    private var fullscreenHidden = false

    /** true while the kids-mode touch lock is on (read by ControlService) */
    @Volatile var touchLocked = false
        private set
    private var lockView: FrameLayout? = null
    private var lockHint: TextView? = null
    private val hideHintRunnable = Runnable {
        lockHint?.animate()?.alpha(0f)?.setDuration(250)?.withEndAction { lockHint?.visibility = View.GONE }?.start()
    }
    private val autoUnlockRunnable = Runnable { if (touchLocked) setTouchLock(false) }

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { if (p.sliderAutoHide) slider?.let { setShown(it, false, sliderBase(), sliderW) } }
    private val hideMultiRunnable = Runnable { closeMulti() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { syncSlider(); showSliderTemporarily() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        p = Prefs(this)
        val f = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fresh = root == null
        val wasHidden = hidden
        val action = intent?.action
        val wantHidden = when (action) {
            ACTION_SHOW -> false
            ACTION_HIDE, ACTION_BANKING -> true
            ACTION_TOGGLE -> !wasHidden
            else -> wasHidden   // settings changes keep the current state; a fresh start is never hidden
        }
        startFg()
        updateDark(p.dark)
        restoreLock()
        if (p.boost > 0.02f) updateBoost(p.boost)
        when {
            wantHidden && !wasHidden -> setHidden(true)
            !wantHidden && wasHidden -> setHidden(false)
            else -> build(fresh)
        }
        if (action == ACTION_BANKING) disableAccessibility()
        setupProximity()
        try { ScheduleManager.scheduleAll(this) } catch (_: Exception) {}
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(autoShowRunnable)
        removePeek()
        handler.removeCallbacks(autoUnlockRunnable)
        removeLockView()
        stopProximity()
        removeOverlay()
        darkView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        darkView = null
        try { enhancer?.release() } catch (_: Exception) {}
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    // ---------------- notification ----------------
    private fun act(action: String, req: Int) = PendingIntent.getForegroundService(
        this, req, Intent(this, OverlayService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildNotification(): Notification {
        val accessOff = ControlService.instance == null
        val b = Notification.Builder(this, "avb")
            .setContentTitle("Assistive Volume")
            .setContentText(when {
                hidden && accessOff -> "Hidden \u00B7 Accessibility is off \u00B7 tap to show"
                hidden -> "Hidden \u00B7 tap to show"
                else -> "Running"
            })
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
        if (hidden) {
            b.setContentIntent(act(ACTION_SHOW, 1))
            b.addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Show buttons", act(ACTION_SHOW, 1)).build())
            if (accessOff) {
                val open = PendingIntent.getActivity(
                    this, 2, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                b.addAction(Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_manage), "Turn accessibility on", open).build())
            }
        } else {
            b.addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Hide", act(ACTION_HIDE, 3)).build())
            b.addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_lock_lock), "Banking mode", act(ACTION_BANKING, 4)).build())
        }
        return b.build()
    }

    private fun notifyState() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification())
    }

    fun refreshNotification() { notifyState() }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("avb", "Assistive Volume", NotificationManager.IMPORTANCE_MIN)
        )
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(hideMultiRunnable)
        handler.removeCallbacks(idleRunnable)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; slider = null; multiPanel = null
        multiSliders.clear()
        shown.clear()
    }

    // ---------------- animations ----------------
    private fun sliderBase() = 1f - p.sliderTransparency / 100f

    private fun resetProps(v: View, base: Float) {
        v.alpha = base; v.translationX = 0f; v.scaleX = 1f; v.scaleY = 1f; v.rotationY = 0f
    }

    private fun hiddenState(v: View, w: Int, right: Boolean) {
        when (p.animType) {
            0 -> v.alpha = 0f
            1 -> { v.alpha = 0f; v.translationX = if (right) w.toFloat() else -w.toFloat() }
            2 -> { v.alpha = 0f; v.scaleX = 0.3f; v.scaleY = 0.3f }
            3 -> { v.alpha = 0f; v.scaleX = 0f; v.scaleY = 0f }
            else -> { v.alpha = 0f; v.rotationY = if (right) -90f else 90f }
        }
    }

    private fun animateView(
        v: View, show: Boolean, base: Float, wHint: Int, edgePivot: Boolean = true, end: (() -> Unit)? = null
    ) {
        v.animate().cancel()
        val right = p.side == 1
        val w = if (v.width > 0) v.width else wHint.coerceAtLeast(dp(40))
        v.pivotX = if (edgePivot) (if (right) w.toFloat() else 0f) else w / 2f
        v.pivotY = (if (v.height > 0) v.height else dp(100)) / 2f
        v.cameraDistance = 9000f * resources.displayMetrics.density
        val dur = if (p.animEnabled) p.animDuration.toLong() else 0L
        val type = p.animType

        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.visibility = View.VISIBLE
                if (dur > 0) hiddenState(v, w, right)
            }
            if (dur == 0L) { resetProps(v, base); end?.invoke(); return }
            v.animate().alpha(base).translationX(0f).scaleX(1f).scaleY(1f).rotationY(0f)
                .setDuration(dur)
                .setInterpolator(if (type == 3) OvershootInterpolator(2.4f) else DecelerateInterpolator())
                .withEndAction { end?.invoke() }.start()
        } else {
            if (dur == 0L) { v.visibility = View.GONE; resetProps(v, base); end?.invoke(); return }
            val a = v.animate().alpha(0f).setDuration(dur).setInterpolator(AccelerateInterpolator())
            when (type) {
                1 -> a.translationX(if (right) w.toFloat() else -w.toFloat())
                2 -> a.scaleX(0.3f).scaleY(0.3f)
                3 -> a.scaleX(0f).scaleY(0f)
                4 -> a.rotationY(if (right) -90f else 90f)
            }
            a.withEndAction { v.visibility = View.GONE; resetProps(v, base); end?.invoke() }.start()
        }
    }

    private fun setShown(v: View?, show: Boolean, base: Float, wHint: Int) {
        v ?: return
        if (shown[v] == show) return
        shown[v] = show
        animateView(v, show, base, wHint)
    }

    private fun hideInstant(v: View?) {
        v ?: return
        v.animate().cancel()
        v.visibility = View.GONE
        resetProps(v, if (v === slider) sliderBase() else 1f)
        shown[v] = false
    }

    /** Used by the "Preview animation" button in the app. */
    fun previewAnimation() {
        handler.post {
            val r = root ?: return@post
            animateView(r, false, 1f, r.width, false) {
                animateView(r, true, 1f, r.width, false)
            }
        }
    }

    // ---------------- actions ----------------
    private fun global(action: Int) {
        val s = ControlService.instance
        if (s == null) {
            Toast.makeText(this, "Accessibility is off. Turn it on from the notification or the app to use this.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT < 28 &&
            (action == AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN || action == AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        ) {
            Toast.makeText(this, "Needs Android 9 or newer", Toast.LENGTH_SHORT).show(); return
        }
        val ok = s.performGlobalAction(action)
        if (ok && action == AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) vibrateShot()
    }

    /** A short, light buzz so you feel that the screenshot was taken. */
    private fun vibrateShot() {
        if (!p.shotVibrate) return
        try {
            val effect = VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
            if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(effect)
            }
        } catch (_: Exception) {}
    }

    private fun hideButtons() { setHidden(true) }

    fun isHiddenNow() = hidden

    fun showAgain() { handler.post { setHidden(false) } }

    /** Hide everything that floats over other apps (buttons, handle and, if wanted, the Darkness layer). */
    private fun setHidden(h: Boolean) {
        if (h == hidden) return
        if (h && touchLocked) return          // never hide the unlock button while the touch lock is on
        handler.removeCallbacks(autoShowRunnable)
        if (h) {
            val r = root
            val finish = {
                hidden = true
                removeOverlay()
                refreshDarkSuspend()
                if (p.peekHandle) addPeek()
                val mins = AUTO_SHOW_MIN[p.hideAutoShow.coerceIn(0, AUTO_SHOW_MIN.size - 1)]
                if (mins > 0) handler.postDelayed(autoShowRunnable, mins * 60_000L)
                notifyState()
            }
            if (r == null) finish() else animateView(r, false, 1f, r.width, false) { finish() }
        } else {
            hidden = false
            removePeek()
            refreshDarkSuspend()
            notifyState()
            build(true)
        }
    }

    /** For banking and other strict apps: hide the shortcut and switch our Accessibility service off. */
    fun enterBankingMode() {
        handler.post {
            setHidden(true)
            disableAccessibility()
        }
    }

    private fun disableAccessibility() {
        val s = ControlService.instance ?: return
        if (Build.VERSION.SDK_INT >= 24) { try { s.disableSelf() } catch (_: Exception) {} }
        ControlService.instance = null
        notifyState()
    }

    private fun refreshDarkSuspend() {
        darkSuspended = p.hideDarkToo && (hidden || appHidden)
        updateDark(p.dark)
    }

    private fun addPeek() {
        if (peekView != null || !Settings.canDrawOverlays(this)) return
        val right = p.side == 1
        val v = object : View(this) {
            private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3FFFFFF.toInt() }
            override fun onDraw(c: Canvas) {
                val w = width.toFloat(); val h = height.toFloat(); val bw = dp(5).toFloat()
                val x0 = if (right) w - bw - dp(2) else dp(2).toFloat()
                c.drawRoundRect(RectF(x0, h * 0.1f, x0 + bw, h * 0.9f), bw / 2, bw / 2, pt)
            }
        }
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) handler.post { setHidden(false) }
            true
        }
        val lp2 = WindowManager.LayoutParams(
            dp(24), dp(72), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START); y = p.posY }
        try { wm.addView(v, lp2); peekView = v } catch (_: Exception) {}
    }

    private fun removePeek() {
        peekView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        peekView = null
    }

    private fun powerLongAction() {
        when (p.powerLong) {
            0 -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            1 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            else -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    private fun multiLongAction() {
        when (p.multiLong) {
            0 -> hideButtons()
            1 -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            2 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            3 -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, uiFlag())
            4 -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            else -> runAction(2)
        }
    }

    // ---------------- levels ----------------
    private fun uiFlag() = if (p.useSystemSlider) AudioManager.FLAG_SHOW_UI else 0

    // ---- stream helpers: real minimum (the call stream starts at 1), call-aware main slider ----
    private fun inCall(): Boolean {
        val m = am.mode
        return m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION
    }

    /** The volume buttons, swipe and the single slider follow the call while you are on a call. */
    private fun mainStream() = if (inCall()) AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    private fun minVol(s: Int): Int =
        if (Build.VERSION.SDK_INT >= 28) am.getStreamMinVolume(s)
        else if (s == AudioManager.STREAM_VOICE_CALL) 1 else 0

    private fun streamFraction(s: Int): Float {
        val mn = minVol(s)
        val span = (am.getStreamMaxVolume(s) - mn).coerceAtLeast(1)
        return ((am.getStreamVolume(s) - mn).toFloat() / span).coerceIn(0f, 1f)
    }

    private fun setStreamFraction(s: Int, f: Float) {
        val mn = minVol(s)
        val mx = am.getStreamMaxVolume(s)
        val target = (mn + Math.round(f * (mx - mn))).coerceIn(mn, mx)
        if (am.getStreamVolume(s) == target) return
        try {
            am.setStreamVolume(s, target, uiFlag())
            // Some phones ignore setStreamVolume for the call stream. Step it with the same call the
            // hardware volume keys use, which always works.
            var guard = 0
            while (am.getStreamVolume(s) != target && guard++ < 25) {
                val cur = am.getStreamVolume(s)
                am.adjustStreamVolume(s, if (cur < target) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, uiFlag())
                if (am.getStreamVolume(s) == cur) break
            }
        } catch (_: SecurityException) {
            Toast.makeText(this, "Not allowed (check Do Not Disturb)", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- call volume: tries every route a phone may accept, and checks the result after each one ----
    private var lastCallToast = 0L

    private fun scoActive(): Boolean = try { am.isBluetoothScoOn } catch (_: Exception) { false }

    private fun callFailed() {
        val now = SystemClock.uptimeMillis()
        if (now - lastCallToast < 4000) return
        lastCallToast = now
        Toast.makeText(this, "This phone did not accept the call volume change. Use Settings > Test call volume to see why.",
            Toast.LENGTH_LONG).show()
    }

    /** Volume up / down while on a call. Shows the system call-volume bar so you can see it working. */
    private fun adjustCall(dir: Int) {
        val s = AudioManager.STREAM_VOICE_CALL
        val before = am.getStreamVolume(s)
        val flags = AudioManager.FLAG_SHOW_UI
        // 1) the very same route the hardware volume keys use
        try { am.adjustSuggestedStreamVolume(dir, s, flags) } catch (_: Exception) {}
        if (am.getStreamVolume(s) != before) return
        // 2) adjust the call stream directly
        try { am.adjustStreamVolume(s, dir, flags) } catch (_: Exception) {}
        if (am.getStreamVolume(s) != before) return
        // 3) Bluetooth headset / car call stream
        if (scoActive()) {
            try { am.adjustStreamVolume(6, dir, flags) } catch (_: Exception) {}
        }
        val atEnd = if (dir == AudioManager.ADJUST_RAISE) before >= am.getStreamMaxVolume(s) else before <= minVol(s)
        if (!atEnd && am.getStreamVolume(s) == before) callFailed()
    }

    /** Slider drag for the call volume. */
    private fun setCallFraction(f: Float) {
        val s = AudioManager.STREAM_VOICE_CALL
        val mn = minVol(s)
        val mx = am.getStreamMaxVolume(s)
        val target = (mn + Math.round(f * (mx - mn))).coerceIn(mn, mx)
        if (am.getStreamVolume(s) == target) return
        try { am.setStreamVolume(s, target, 0) } catch (_: SecurityException) {}
        var guard = 0
        while (am.getStreamVolume(s) != target && guard++ < 25) {
            val cur = am.getStreamVolume(s)
            val dir = if (cur < target) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            try { am.adjustSuggestedStreamVolume(dir, s, 0) } catch (_: Exception) {}
            if (am.getStreamVolume(s) == cur) try { am.adjustStreamVolume(s, dir, 0) } catch (_: Exception) {}
            if (am.getStreamVolume(s) == cur && scoActive()) try { am.adjustStreamVolume(6, dir, 0) } catch (_: Exception) {}
            if (am.getStreamVolume(s) == cur) break
        }
        if (am.getStreamVolume(s) != target) callFailed()
    }

    private fun level(id: Int): Float {
        val s = Sliders.streams[id]
        return if (s == -1) {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        } else if (s == -2) {
            p.boost
        } else if (s == -3) {
            p.dark
        } else {
            streamFraction(s)
        }
    }

    private fun setLevel(id: Int, f: Float) {
        val s = Sliders.streams[id]
        try {
            if (s == -2) {
                p.boost = f; updateBoost(f)
            } else if (s == -3) {
                p.dark = f; updateDark(f)
            } else if (s == -1) {
                if (Settings.System.canWrite(this)) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                        (f * 255).roundToInt().coerceIn(1, 255))
                } else {
                    Toast.makeText(this, "Allow 'Modify system settings' in the app", Toast.LENGTH_SHORT).show()
                }
            } else {
                if (s == AudioManager.STREAM_VOICE_CALL) setCallFraction(f) else setStreamFraction(s, f)
            }
        } catch (_: SecurityException) {
            Toast.makeText(this, "Not allowed (check Do Not Disturb)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun syncSlider() {
        slider?.let {
            val call = inCall()
            it.iconId = if (call) 3 else 0
            it.fraction = streamFraction(if (call) AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC)
        }
        multiSliders.forEach { (id, v) -> v.fraction = level(id) }
    }

    private fun change(dir: Int) {
        if (inCall()) adjustCall(dir) else am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, uiFlag())
        syncSlider()
        showSliderTemporarily()
    }

    // ---------------- show / hide sliders ----------------
    private fun multiVisible() = multiPanel?.let { shown[it] == true } ?: false

    private fun showSliderTemporarily() {
        interact()
        val s = slider ?: return
        if (!p.sliderAutoHide || multiVisible()) return
        setShown(s, true, sliderBase(), sliderW)
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, p.hideDelay * 1000L)
    }

    private fun toggleMulti() {
        val mp = multiPanel ?: return
        if (multiVisible()) closeMulti() else {
            syncSlider()
            handler.removeCallbacks(hideRunnable)
            hideInstant(slider)
            setShown(mp, true, 1f, multiW)
            showMultiTemporarily()
        }
    }

    private fun showMultiTemporarily() {
        handler.removeCallbacks(hideMultiRunnable)
        handler.postDelayed(hideMultiRunnable, maxOf(p.hideDelay, 3) * 1000L)
    }

    private fun closeMulti() {
        handler.removeCallbacks(hideMultiRunnable)
        multiPanel?.let { setShown(it, false, 1f, multiW) }
        if (!p.sliderAutoHide) slider?.let { setShown(it, true, sliderBase(), sliderW) }
    }

    /** Called when the user touches anywhere outside our buttons. */
    private fun dismissSliders() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(hideMultiRunnable)
        if (multiVisible()) closeMulti()
        if (p.sliderAutoHide) slider?.let { setShown(it, false, sliderBase(), sliderW) }
    }

    // ---------------- dark overlay & booster ----------------
    /**
     * The dark layer is created once and only its window alpha changes afterwards, so our buttons are
     * never re-added while a finger is on them. The alpha stays at or below 0.8, because Android 12+
     * blocks touches that pass through an overlay that is more opaque than that.
     */
    private fun ensureDarkView() {
        if (darkView != null || !Settings.canDrawOverlays(this)) return
        val v = View(this).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE }
        val lp2 = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { alpha = 0f }
        try {
            wm.addView(v, lp2)
            darkView = v
            darkParams = lp2
        } catch (_: Exception) {}
    }

    private fun updateDark(f: Float) {
        ensureDarkView()
        val v = darkView ?: return
        val lp2 = darkParams ?: return
        val a = if (darkSuspended) 0f else (f * 0.8f).coerceIn(0f, 0.8f)
        if (a < 0.015f) { v.visibility = View.GONE; lp2.alpha = 0f }
        else { v.visibility = View.VISIBLE; lp2.alpha = a }
        try { wm.updateViewLayout(v, lp2) } catch (_: Exception) {}
    }

    private fun updateBoost(f: Float) {
        try {
            if (enhancer == null) enhancer = LoudnessEnhancer(0)
            enhancer?.setTargetGain((f * 1000).toInt())
            enhancer?.enabled = f > 0.02f
        } catch (_: Exception) {
            Toast.makeText(this, "Media booster is not supported on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------- per app / keyboard (called by ControlService) ----------------
    fun onForegroundApp(pkg: String) {
        if (!p.perApp) { setAppHidden(false); return }
        if (pkg == lastPkg) return
        lastPkg = pkg
        val cfg = p.appCfg(pkg)
        setAppHidden(cfg?.hide == true)
        if (cfg != null) {
            if (cfg.media >= 0) setLevel(0, cfg.media / 100f)
            if (cfg.bright >= 0) setLevel(4, cfg.bright / 100f)
            syncSlider()
        }
    }

    private fun setAppHidden(h: Boolean) {
        if (appHidden == h) return
        appHidden = h
        refreshDarkSuspend()
        updateVisible()
    }

    fun onKeyboard(top: Int) {
        kbTop = top
        applyPosition()
    }

    private fun applyPosition() {
        val r = root ?: return
        val params = lp ?: return
        var y = p.posY
        if (p.keyboardSensitive && kbTop > 0) {
            val maxY = kbTop - r.height - dp(8)
            if (y > maxY) y = maxY.coerceAtLeast(0)
        }
        y = y.coerceIn(0, (screenH() - r.height).coerceAtLeast(0))
        if (params.y != y) {
            params.y = y
            try { wm.updateViewLayout(r, params) } catch (_: Exception) {}
        }
    }

    // ---------------- proximity sensor ----------------
    private fun stopProximity() {
        proxListener?.let { sensorManager?.unregisterListener(it) }
        proxListener = null
        lastNear = null
    }

    private fun setupProximity() {
        stopProximity()
        if (p.proxNear == 0 && p.proxAway == 0) return
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY, true)
            ?: sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) ?: return
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val near = e.values[0] < sensor.maximumRange.coerceAtMost(5f)
                val prev = lastNear
                lastNear = near
                if (prev == null || prev == near) return
                if (near && p.proxNear == 1 && Build.VERSION.SDK_INT >= 28)
                    ControlService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                if (!near && p.proxAway == 1) wakeScreen()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager = sm
        proxListener = l
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "avb:prox"
        ).acquire(3000)
    }

    // ---------------- gestures / idle fade / auto-hide ----------------
    fun syncFromOutside() { handler.post { syncSlider() } }

    private fun actionLambda(id: Int): (() -> Unit)? = if (id == 0) null else ({ runAction(id) })

    private fun runAction(id: Int) {
        when (id) {
            1 -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, uiFlag())
                syncSlider(); showSliderTemporarily()
            }
            2 -> {
                val n = Profiles.next(this)
                Toast.makeText(this, "Profile: ${Profiles.emojis[n]} ${Profiles.names[n]}", Toast.LENGTH_SHORT).show()
            }
            3 -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            4 -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            5 -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            6 -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            7 -> hideButtons()
            8 -> handler.post { setTouchLock(!touchLocked) }
            9 -> enterBankingMode()
        }
    }

    private val idleRunnable = Runnable {
        val r = root
        if (r != null && p.idleFade && shown[r] != false) {
            val busy = multiVisible() || (p.sliderAutoHide && (slider?.let { shown[it] == true } == true))
            if (busy) armIdle()
            else r.animate().alpha(p.idleOpacity / 100f).setDuration(400).start()
        }
    }

    private fun armIdle() {
        handler.removeCallbacks(idleRunnable)
        if (p.idleFade) handler.postDelayed(idleRunnable, p.idleDelay * 1000L)
    }

    /** Called whenever the user touches a button or the volume changes. */
    private fun interact() {
        val r = root ?: return
        if (r.alpha < 0.999f && shown[r] != false) r.animate().alpha(1f).setDuration(150).start()
        armIdle()
    }

    private fun updateVisible() {
        root?.let { r -> setShown(r, touchLocked || !(appHidden || autoHidden), 1f, r.width) }
    }

    private fun updateAutoHide() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val h = (p.hideLandscape && land) || (p.hideFullscreen && fullscreenHidden)
        if (h == autoHidden) return
        autoHidden = h
        updateVisible()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post { updateAutoHide(); applyPosition() }
    }

    private fun levelAccent(id: Int, auto: Int): Int {
        val c = p.levelColor(id)
        return if (c == 0) auto else c
    }

    // ---------------- touch lock (kids mode) ----------------
    fun toggleTouchLock() { handler.post { setTouchLock(!touchLocked) } }

    private fun lockMinutes() = intArrayOf(0, 5, 15, 30, 60)[p.lockTimeout.coerceIn(0, 4)]

    private fun lockAlpha() = intArrayOf(0, 0x30, 0x99)[p.lockDim.coerceIn(0, 2)]

    private fun lockMessage() =
        if (p.lockSafeUnlock) "\uD83D\uDD12 Touch locked \u00B7 press and hold the lock button to unlock"
        else "\uD83D\uDD12 Touch locked \u00B7 double-tap the lock button to unlock"

    private fun setTouchLock(on: Boolean) {
        handler.removeCallbacks(autoUnlockRunnable)
        touchLocked = on
        p.locked = on
        if (on) {
            val mins = lockMinutes()
            p.lockUntil = if (mins > 0) System.currentTimeMillis() + mins * 60_000L else 0L
            if (mins > 0) handler.postDelayed(autoUnlockRunnable, mins * 60_000L)
            addLockView()
        } else {
            p.lockUntil = 0L
            removeLockView()
        }
        build(false)
    }

    /** Called when the service starts: keep the lock if it was on, drop it if the timer ran out. */
    private fun restoreLock() {
        handler.removeCallbacks(autoUnlockRunnable)
        var on = p.locked
        if (on && p.lockUntil > 0L) {
            val left = p.lockUntil - System.currentTimeMillis()
            if (left <= 0L) { on = false; p.locked = false; p.lockUntil = 0L }
            else handler.postDelayed(autoUnlockRunnable, left)
        }
        touchLocked = on
        if (on) addLockView() else removeLockView()
    }

    private fun addLockView() {
        if (lockView != null || !Settings.canDrawOverlays(this)) return
        val hint = TextView(this).apply {
            text = lockMessage()
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(14), dp(20), dp(14))
            background = GradientDrawable().apply { setColor(0xE6202534.toInt()); cornerRadius = dp(22).toFloat() }
            visibility = View.GONE
        }
        val fl = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(lockAlpha(), 0, 0, 0))
            isClickable = true
            addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER).apply {
                marginStart = dp(24); marginEnd = dp(24)
            })
            setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) showLockHint()
                true
            }
        }
        val lp2 = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(fl, lp2)
        lockView = fl
        lockHint = hint
        // keep our own button above the blocker so it can still be pressed
        val r = root; val l = lp
        if (r != null && l != null) {
            try { wm.removeView(r); wm.addView(r, l) } catch (_: Exception) {}
        }
    }

    private fun removeLockView() {
        handler.removeCallbacks(hideHintRunnable)
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        lockHint = null
    }

    /** The locked screen stays completely normal: no pop-up or message is ever shown when it is touched. */
    private fun showLockHint() {}

    private fun styleSlider(v: VolumeSliderView) {
        v.onDoubleTap = if (p.sliderDoubleHide) ({ hideButtons() }) else null
        v.showIcon = p.sliderIcons
        v.iconStyle = p.sliderIconStyle
        v.iconTop = p.sliderIconPos == 1
        v.iconSizePct = p.sliderIconSize
        v.showPercent = p.sliderPercent
        v.customLevel = p.lvMode != 0
        v.fillAlpha = p.lvAlpha * 255 / 100
        v.trackAlpha = p.lvTrack * 255 / 100
        v.iconOverride = when (p.iconColorMode) {
            1 -> Color.WHITE
            2 -> 0xFF2A2F3A.toInt()
            else -> null
        }
    }

    // ---------------- build overlay ----------------
    private fun build(animateIn: Boolean) {
        removeOverlay()
        if (hidden) return
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        val style = p.style
        val right = p.side == 1
        val d = dp(24) + dp(p.btnSize) * 4 / 5
        val accent = p.accent()
        val sliderAccent = p.sliderAccent()
        val red = 0xFFE53935.toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
            x = dp(4); y = p.posY
        }
        lp = params

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panel.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && p.tapOutside) dismissSliders()
            false
        }

        // ---- button column ----
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val gap = dp(p.btnGap)
        fun addBtn(v: View, size: Int = d) {
            col.addView(v, LinearLayout.LayoutParams(size, size).apply { topMargin = if (col.childCount > 0) gap else 0 })
        }
        if (touchLocked) {
            val unlock: () -> Unit = { handler.post { setTouchLock(false) } }
            addBtn(makeButton(StyledButton.LOCK, 0xFFFFB020.toInt(),
                onTap = { showLockHint() },
                onLong = if (p.lockSafeUnlock) unlock else null,
                onDouble = if (p.lockSafeUnlock) null else unlock,
                longDelay = 1500L))
            panel.addView(col)
            root = panel
            panel.visibility = View.VISIBLE
            shown[panel] = true
            wm.addView(panel, params)
            panel.post { applyPosition() }
            return
        }
        if (p.powerEnabled) {
            addBtn(makeButton(StyledButton.POWER, red,
                onTap = { global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) },
                onLong = { powerLongAction() }, onDouble = actionLambda(p.pwDouble)))
        }
        if (p.showVolButtons) {
            addBtn(makeButton(StyledButton.PLUS, accent, onTap = { change(AudioManager.ADJUST_RAISE) }))
            addBtn(makeButton(StyledButton.MINUS, accent, onTap = { change(AudioManager.ADJUST_LOWER) }))
        }
        if (p.multiEnabled) {
            addBtn(makeButton(StyledButton.SLIDERS, p.sbAccent(),
                onTap = { toggleMulti() }, onLong = { multiLongAction() }, design = p.sbIcon,
                swipe = p.swipeVolume, onDouble = actionLambda(p.sbDouble)),
                d * p.sbScale / 100)
        }

        val sw = dp(p.sliderWidth)
        val g12 = dp(12)
        sliderW = sw + g12

        // ---- single media slider (appears while adjusting) ----
        val sv = VolumeSliderView(this, style, 0) { f ->
            if (inCall()) setCallFraction(f) else setStreamFraction(AudioManager.STREAM_MUSIC, f)
            interact()
            showSliderTemporarily()
        }
        sv.accent = levelAccent(0, sliderAccent)
        styleSlider(sv)
        sv.alpha = sliderBase()
        slider = sv
        val svLp = LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply {
            if (right) marginEnd = g12 else marginStart = g12
        }

        // ---- multi sliders panel ----
        var mp: LinearLayout? = null
        if (p.multiEnabled) {
            val m = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
            var n = 0
            for (id in Sliders.names.indices) {
                if (p.multiMask and (1 shl id) == 0) continue
                val v = VolumeSliderView(this, style, id) { f ->
                    setLevel(id, f)
                    interact()
                    showMultiTemporarily()
                }
                v.accent = levelAccent(id, sliderAccent)
                styleSlider(v)
                v.alpha = sliderBase()
                m.addView(v, LinearLayout.LayoutParams(sw, dp(p.sliderHeight)).apply {
                    if (right) marginEnd = g12 else marginStart = g12
                })
                multiSliders.add(id to v); n++
            }
            multiW = n * (sw + g12)
            mp = m
            multiPanel = m
            shown[m] = false
        }

        // order depends on which edge we are on: buttons always touch the edge
        if (!right) {
            panel.addView(col); panel.addView(sv, svLp); mp?.let { panel.addView(it) }
        } else {
            mp?.let { panel.addView(it) }; panel.addView(sv, svLp); panel.addView(col)
        }

        sv.visibility = if (p.sliderAutoHide) View.GONE else View.VISIBLE
        shown[sv] = !p.sliderAutoHide

        root = panel
        autoHidden = (p.hideLandscape && resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) ||
            (p.hideFullscreen && fullscreenHidden)
        val offNow = appHidden || autoHidden
        panel.visibility = if (offNow) View.GONE else View.VISIBLE
        shown[panel] = !offNow
        val doAnim = animateIn && !offNow && p.animEnabled
        if (doAnim) hiddenState(panel, dp(80), right)
        wm.addView(panel, params)
        if (Build.VERSION.SDK_INT >= 30) {
            panel.setOnApplyWindowInsetsListener { _, insets ->
                if (p.hideFullscreen) {
                    val fs = !insets.isVisible(WindowInsets.Type.statusBars())
                    if (fs != fullscreenHidden) { fullscreenHidden = fs; handler.post { updateAutoHide() } }
                }
                insets
            }
            panel.requestApplyInsets()
        }
        armIdle()
        syncSlider()
        panel.post {
            applyPosition()
            if (doAnim) animateView(panel, true, 1f, panel.width, false)
        }
    }

    // ---------------- drag along the screen edges ----------------
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun startDrag(params: WindowManager.LayoutParams) {
        val r = root ?: return
        if ((params.gravity and Gravity.RELATIVE_HORIZONTAL_GRAVITY_MASK) == Gravity.END) {
            params.x = screenW() - r.width - params.x
            params.gravity = Gravity.TOP or Gravity.START
        }
    }

    private fun endDrag(params: WindowManager.LayoutParams) {
        val r = root ?: return
        val newSide = if (params.x + r.width / 2 < screenW() / 2) 0 else 1
        val margin = dp(4)
        val targetX = if (newSide == 0) margin else screenW() - r.width - margin
        val targetY = params.y.coerceIn(0, (screenH() - r.height).coerceAtLeast(0))
        val startX = params.x; val startY = params.y
        p.side = newSide; p.posY = targetY
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 180
            addUpdateListener {
                val f = it.animatedValue as Float
                params.x = startX + ((targetX - startX) * f).toInt()
                params.y = startY + ((targetY - startY) * f).toInt()
                try { wm.updateViewLayout(r, params) } catch (_: Exception) {}
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { build(false) }
            })
            start()
        }
    }

    private fun makeButton(
        kind: Int, accent: Int, onTap: () -> Unit, onLong: (() -> Unit)? = null, design: Int = 0,
        swipe: Boolean = false, onDouble: (() -> Unit)? = null, longDelay: Long = 600L
    ): View {
        val v = StyledButton(this, kind, p.btnStyle, p.btnShape, accent, p.iconScale / 100f, design)
        v.alpha = 1f - p.btnTransparency / 100f

        var downX = 0f; var downY = 0f; var sx = 0; var sy = 0
        var dragging = false; var swiping = false; var steps = 0
        var longFired = false; var lastTap = 0L
        val longRun = Runnable { if (!dragging && !swiping) { longFired = true; onLong?.invoke() } }
        val singleRun = Runnable { onTap() }

        v.setOnTouchListener { _, e ->
            val params = lp ?: return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    interact()
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                    downX = e.rawX; downY = e.rawY
                    dragging = false; swiping = false; steps = 0; longFired = false
                    if (onLong != null) handler.postDelayed(longRun, longDelay)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (swiping) {
                        val target = (-(e.rawY - downY) / dp(20)).toInt()
                        while (steps < target) { steps++; swipeStep(v, true) }
                        while (steps > target) { steps--; swipeStep(v, false) }
                    } else if (dragging) {
                        params.x = (sx + (e.rawX - downX)).toInt()
                        params.y = (sy + (e.rawY - downY)).toInt()
                        root?.let { try { wm.updateViewLayout(it, params) } catch (_: Exception) {} }
                    } else if (hypot(e.rawX - downX, e.rawY - downY) > dp(8)) {
                        handler.removeCallbacks(longRun)
                        if (swipe && kotlin.math.abs(e.rawY - downY) > kotlin.math.abs(e.rawX - downX)) {
                            swiping = true; downY = e.rawY; steps = 0
                        } else if (!p.pinned) {
                            dragging = true
                            startDrag(params)
                            sx = params.x; sy = params.y
                            downX = e.rawX; downY = e.rawY
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                    if (dragging) endDrag(params)
                    else if (!swiping && !longFired) {
                        if (p.haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        if (onDouble != null) {
                            val now = SystemClock.uptimeMillis()
                            if (now - lastTap < 300) {
                                lastTap = 0; handler.removeCallbacks(singleRun); onDouble()
                            } else {
                                lastTap = now; handler.postDelayed(singleRun, 300)
                            }
                        } else onTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRun)
                    v.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                }
            }
            true
        }
        return v
    }

    private fun swipeStep(v: View, up: Boolean) {
        if (p.haptic) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        change(if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER)
    }
}
