package com.example.assistvolume

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*

class AppConfigActivity : Activity() {
    private lateinit var p: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        applyAppTheme()
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        list.addView(TextView(this).apply {
            text = "Config per app\nTap an app to set what happens when it opens"
            setTextColor(C.TEXT); textSize = 17f; setPadding(0, 0, 0, dp(12))
        })
        for ((pkg, label) in apps) {
            val row = TextView(this).apply {
                setTextColor(C.TEXT); textSize = 16f
                setPadding(0, dp(12), 0, dp(12))
            }
            row.text = rowText(pkg, label)
            row.setOnClickListener { showDialog(pkg, label, row) }
            list.addView(row)
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(C.BG)
            addView(list)
        })
        applyBars()
    }

    private fun rowText(pkg: String, label: String): String {
        val c = p.appCfg(pkg) ?: return label
        val parts = mutableListOf<String>()
        if (c.hide) parts.add("hidden")
        if (c.media >= 0) parts.add("media ${c.media}%")
        if (c.bright >= 0) parts.add("brightness ${c.bright}%")
        return "$label  \u2713  (${parts.joinToString(", ")})"
    }

    private fun showDialog(pkg: String, label: String, row: TextView) {
        val cur = p.appCfg(pkg)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
        }
        val hide = Switch(this).apply { text = "Hide buttons in this app"; isChecked = cur?.hide ?: false }
        val mediaCb = CheckBox(this).apply { text = "Set media volume"; isChecked = (cur?.media ?: -1) >= 0 }
        val mediaSb = SeekBar(this).apply { max = 100; progress = (cur?.media ?: 50).coerceAtLeast(0) }
        val brCb = CheckBox(this).apply { text = "Set brightness"; isChecked = (cur?.bright ?: -1) >= 0 }
        val brSb = SeekBar(this).apply { max = 100; progress = (cur?.bright ?: 50).coerceAtLeast(0) }
        for (v in listOf<View>(hide, mediaCb, mediaSb, brCb, brSb)) box.addView(v)

        AlertDialog.Builder(this)
            .setTitle(label)
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val c = AppCfg(
                    hide.isChecked,
                    if (mediaCb.isChecked) mediaSb.progress else -1,
                    if (brCb.isChecked) brSb.progress else -1
                )
                p.setAppCfg(pkg, if (!c.hide && c.media < 0 && c.bright < 0) null else c)
                row.text = rowText(pkg, label)
            }
            .setNeutralButton("Clear") { _, _ -> p.setAppCfg(pkg, null); row.text = label }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
