package com.example.assistvolume

import android.content.Context
import android.graphics.Color
import android.media.AudioManager

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

data class AppCfg(val hide: Boolean, val media: Int, val bright: Int)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)

    var enabled: Boolean get() = b("enabled", false); set(v) { sp.edit().putBoolean("enabled", v).apply() }
    var pinned: Boolean get() = b("pinned", false); set(v) { sp.edit().putBoolean("pinned", v).apply() }
    var useSystemSlider: Boolean get() = b("sys", false); set(v) { sp.edit().putBoolean("sys", v).apply() }
    var sliderAutoHide: Boolean get() = b("sah", true); set(v) { sp.edit().putBoolean("sah", v).apply() }
    var powerEnabled: Boolean get() = b("pe", false); set(v) { sp.edit().putBoolean("pe", v).apply() }
    var powerLong: Int get() = i("pl", 0); set(v) { sp.edit().putInt("pl", v).apply() }
    var powerPos: Int get() = i("pp", 0); set(v) { sp.edit().putInt("pp", v).apply() }
    var multiEnabled: Boolean get() = b("me", false); set(v) { sp.edit().putBoolean("me", v).apply() }
    var multiMask: Int get() = i("mm", 1); set(v) { sp.edit().putInt("mm", v).apply() }
    var multiLong: Int get() = i("ml", 0); set(v) { sp.edit().putInt("ml", v).apply() }
    var proxNear: Int get() = i("pn", 0); set(v) { sp.edit().putInt("pn", v).apply() }
    var proxAway: Int get() = i("pa", 0); set(v) { sp.edit().putInt("pa", v).apply() }
    var keyboardSensitive: Boolean get() = b("ks", true); set(v) { sp.edit().putBoolean("ks", v).apply() }
    var perApp: Boolean get() = b("pap", false); set(v) { sp.edit().putBoolean("pap", v).apply() }
    var boost: Float get() = sp.getFloat("boost", 0f); set(v) { sp.edit().putFloat("boost", v).apply() }
    var dark: Float get() = sp.getFloat("dark", 0f); set(v) { sp.edit().putFloat("dark", v).apply() }

    fun appCfg(pkg: String): AppCfg? {
        val s = sp.getString("app:$pkg", null) ?: return null
        return try {
            val a = s.split(",")
            AppCfg(a[0] == "1", a[1].toInt(), a[2].toInt())
        } catch (e: Exception) { null }
    }

    fun setAppCfg(pkg: String, c: AppCfg?) {
        val e = sp.edit()
        if (c == null) e.remove("app:$pkg")
        else e.putString("app:$pkg", "${if (c.hide) 1 else 0},${c.media},${c.bright}")
        e.apply()
    }

    /** 0 Solid, 1 Glass, 2 Neon, 3 Gradient, 4 Outline */
    var btnStyle: Int get() = i("bst", 3); set(v) { sp.edit().putInt("bst", v).apply() }
    /** 0 circle, 1 rounded square */
    var btnShape: Int get() = i("bsh", 0); set(v) { sp.edit().putInt("bsh", v).apply() }
    var iconScale: Int get() = i("isc", 55); set(v) { sp.edit().putInt("isc", v).apply() }
    var btnGap: Int get() = i("bgap", 12); set(v) { sp.edit().putInt("bgap", v).apply() }
    var sliderWidth: Int get() = i("sw", 56); set(v) { sp.edit().putInt("sw", v).apply() }
    var hideDelay: Int get() = i("hd", 3); set(v) { sp.edit().putInt("hd", v).apply() }
    var tapOutside: Boolean get() = b("to", true); set(v) { sp.edit().putBoolean("to", v).apply() }
    var applyStyleColors: Boolean get() = b("asc", true); set(v) { sp.edit().putBoolean("asc", v).apply() }

    /** 0 = Android, 1 = Android 12, 2 = iOS */
    var style: Int get() = i("style", 1); set(v) { sp.edit().putInt("style", v).apply() }
    var bgColor: Int get() = i("bg", Color.WHITE); set(v) { sp.edit().putInt("bg", v).apply() }
    var btnTransparency: Int get() = i("bt", 50); set(v) { sp.edit().putInt("bt", v).apply() }
    var btnSize: Int get() = i("bs", 50); set(v) { sp.edit().putInt("bs", v).apply() }
    var sliderTransparency: Int get() = i("st", 0); set(v) { sp.edit().putInt("st", v).apply() }
    var sliderHeight: Int get() = i("sh", 304); set(v) { sp.edit().putInt("sh", v).apply() }
    var posX: Int get() = i("px", 40); set(v) { sp.edit().putInt("px", v).apply() }
    var posY: Int get() = i("py", 500); set(v) { sp.edit().putInt("py", v).apply() }
}

object Sliders {
    val names = listOf("Media", "Ring", "Notification", "Call", "Brightness", "Media booster", "Darkness")
    val icons = listOf("\u266A", "\uD83D\uDD14", "\uD83D\uDCAC", "\uD83D\uDCDE", "\u2600", "\uD83D\uDD0A", "\uD83C\uDF11")
    /** -1 = brightness, -2 = media booster, -3 = darkness */
    val streams = listOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL, -1, -2, -3
    )
}
