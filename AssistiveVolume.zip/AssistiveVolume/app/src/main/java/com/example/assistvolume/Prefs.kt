package com.example.assistvolume

import android.content.Context
import android.graphics.Color
import android.media.AudioManager
import org.json.JSONObject

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

data class AppCfg(val hide: Boolean, val media: Int, val bright: Int)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)

    var enabled: Boolean get() = b("enabled", false); set(v) { sp.edit().putBoolean("enabled", v).apply() }
    var pinned: Boolean get() = b("pinned", false); set(v) { sp.edit().putBoolean("pinned", v).apply() }
    var useSystemSlider: Boolean get() = b("sys", false); set(v) { sp.edit().putBoolean("sys", v).apply() }
    var sliderAutoHide: Boolean get() = b("sah", true); set(v) { sp.edit().putBoolean("sah", v).apply() }
    var powerEnabled: Boolean get() = b("pe", true); set(v) { sp.edit().putBoolean("pe", v).apply() }
    var powerLong: Int get() = i("pl", 0); set(v) { sp.edit().putInt("pl", v).apply() }
    var powerPos: Int get() = i("pp", 0); set(v) { sp.edit().putInt("pp", v).apply() }
    var multiEnabled: Boolean get() = b("me", true); set(v) { sp.edit().putBoolean("me", v).apply() }
    var multiMask: Int get() = i("mm", 1); set(v) { sp.edit().putInt("mm", v).apply() }
    var multiLong: Int get() = i("ml", 0); set(v) { sp.edit().putInt("ml", v).apply() }
    var proxNear: Int get() = i("pn", 0); set(v) { sp.edit().putInt("pn", v).apply() }
    var proxAway: Int get() = i("pa", 0); set(v) { sp.edit().putInt("pa", v).apply() }
    var keyboardSensitive: Boolean get() = b("ks", true); set(v) { sp.edit().putBoolean("ks", v).apply() }
    var perApp: Boolean get() = b("pap", false); set(v) { sp.edit().putBoolean("pap", v).apply() }
    var boost: Float get() = sp.getFloat("boost", 0f); set(v) { sp.edit().putFloat("boost", v).apply() }
    var dark: Float get() = sp.getFloat("dark", 0f); set(v) { sp.edit().putFloat("dark", v).apply() }

    fun appCfg(pkg: String): AppCfg? {
        val s = sp.getString("app:$pkg", null) ?: return null
        return try {
            val a = s.split(",")
            AppCfg(a[0] == "1", a[1].toInt(), a[2].toInt())
        } catch (e: Exception) { null }
    }

    fun setAppCfg(pkg: String, c: AppCfg?) {
        val e = sp.edit()
        if (c == null) e.remove("app:$pkg")
        else e.putString("app:$pkg", "${if (c.hide) 1 else 0},${c.media},${c.bright}")
        e.apply()
    }

    /** 0 Solid, 1 Glass, 2 Neon, 3 Gradient, 4 Outline */
    var btnStyle: Int get() = i("bst", 5); set(v) { sp.edit().putInt("bst", v).apply() }
    /** 0 circle, 1 rounded square */
    var btnShape: Int get() = i("bsh", 0); set(v) { sp.edit().putInt("bsh", v).apply() }
    var iconScale: Int get() = i("isc", 55); set(v) { sp.edit().putInt("isc", v).apply() }
    var btnGap: Int get() = i("bgap", 12); set(v) { sp.edit().putInt("bgap", v).apply() }
    var sliderWidth: Int get() = i("sw", 56); set(v) { sp.edit().putInt("sw", v).apply() }
    var hideDelay: Int get() = i("hd", 3); set(v) { sp.edit().putInt("hd", v).apply() }
    var tapOutside: Boolean get() = b("to", true); set(v) { sp.edit().putBoolean("to", v).apply() }
    var showVolButtons: Boolean get() = b("svb", false); set(v) { sp.edit().putBoolean("svb", v).apply() }
    /** 0 = left edge, 1 = right edge */
    var side: Int get() = i("side", 1); set(v) { sp.edit().putInt("side", v).apply() }
    var animEnabled: Boolean get() = b("ae", true); set(v) { sp.edit().putBoolean("ae", v).apply() }
    /** 0 Fade, 1 Slide, 2 Zoom, 3 Bounce, 4 Flip */
    var animType: Int get() = i("at", 1); set(v) { sp.edit().putInt("at", v).apply() }
    var animDuration: Int get() = i("ad", 250); set(v) { sp.edit().putInt("ad", v).apply() }
    var haptic: Boolean get() = b("hap", true); set(v) { sp.edit().putBoolean("hap", v).apply() }
    var bootStart: Boolean get() = b("boot", true); set(v) { sp.edit().putBoolean("boot", v).apply() }
    var iconVariant: Int get() = i("iv", 0); set(v) { sp.edit().putInt("iv", v).apply() }

    fun accent(): Int = if (applyStyleColors) when (btnStyle) {
        1, 5 -> Color.WHITE
        2 -> 0xFF00E5FF.toInt()
        3 -> 0xFF7C4DFF.toInt()
        else -> 0xFF1A73E8.toInt()
    } else bgColor

    fun sliderAccent(): Int = if (applyStyleColors) when (btnStyle) {
        5 -> 0xFF5AA9FF.toInt()
        2 -> 0xFF00E5FF.toInt()
        3 -> 0xFF7C4DFF.toInt()
        else -> 0xFF1A73E8.toInt()
    } else bgColor

    fun resetAll() { sp.edit().clear().apply() }

    fun exportJson(): String {
        val o = JSONObject()
        for ((k, v) in sp.all) when (v) {
            is Boolean, is Int, is String -> o.put(k, v)
            is Float -> o.put(k, v.toDouble())
        }
        o.put("_app", "AssistiveVolume")
        return o.toString()
    }

    fun importJson(s: String): Boolean = try {
        val o = JSONObject(s)
        if (o.optString("_app") != "AssistiveVolume") false else {
            val e = sp.edit()
            for (k in o.keys()) {
                if (k == "_app") continue
                val v = o.get(k)
                if (k == "boost" || k == "dark") { e.putFloat(k, (v as Number).toFloat()); continue }
                when (v) {
                    is Boolean -> e.putBoolean(k, v)
                    is Int -> e.putInt(k, v)
                    is String -> e.putString(k, v)
                }
            }
            e.apply(); true
        }
    } catch (e: Exception) { false }

    // slider icon options
    var sliderIcons: Boolean get() = b("sic", true); set(v) { sp.edit().putBoolean("sic", v).apply() }
    /** 0 Line, 1 Bold, 2 Filled */
    var sliderIconStyle: Int get() = i("sis", 2); set(v) { sp.edit().putInt("sis", v).apply() }
    /** 0 bottom, 1 top */
    var sliderIconPos: Int get() = i("sip", 0); set(v) { sp.edit().putInt("sip", v).apply() }
    var sliderIconSize: Int get() = i("siz", 100); set(v) { sp.edit().putInt("siz", v).apply() }
    var sliderPercent: Boolean get() = b("spc", false); set(v) { sp.edit().putBoolean("spc", v).apply() }
    // Sliders button design
    var sbIcon: Int get() = i("sbi", 1); set(v) { sp.edit().putInt("sbi", v).apply() }
    var sbScale: Int get() = i("sbs", 100); set(v) { sp.edit().putInt("sbs", v).apply() }
    var sbCustomColor: Boolean get() = b("sbc", false); set(v) { sp.edit().putBoolean("sbc", v).apply() }
    var sbColor: Int get() = i("sbcol", 0xFF00BFA5.toInt()); set(v) { sp.edit().putInt("sbcol", v).apply() }
    fun sbAccent(): Int = if (sbCustomColor) sbColor else accent()

    var glassAnim: Boolean get() = b("gan", true); set(v) { sp.edit().putBoolean("gan", v).apply() }
    var theme: Int get() = i("theme", 4); set(v) { sp.edit().putInt("theme", v).apply() }
    var wizardDone: Boolean get() = b("wiz", false); set(v) { sp.edit().putBoolean("wiz", v).apply() }
    var swipeVolume: Boolean get() = b("swv", true); set(v) { sp.edit().putBoolean("swv", v).apply() }
    var sbDouble: Int get() = i("sbd", 1); set(v) { sp.edit().putInt("sbd", v).apply() }
    var pwDouble: Int get() = i("pwd", 0); set(v) { sp.edit().putInt("pwd", v).apply() }
    var idleFade: Boolean get() = b("idf", false); set(v) { sp.edit().putBoolean("idf", v).apply() }
    var idleDelay: Int get() = i("idd", 4); set(v) { sp.edit().putInt("idd", v).apply() }
    var idleOpacity: Int get() = i("ido", 30); set(v) { sp.edit().putInt("ido", v).apply() }
    var hideLandscape: Boolean get() = b("hls", false); set(v) { sp.edit().putBoolean("hls", v).apply() }
    var hideFullscreen: Boolean get() = b("hfs", false); set(v) { sp.edit().putBoolean("hfs", v).apply() }
    var curProfile: Int get() = i("cprof", -1); set(v) { sp.edit().putInt("cprof", v).apply() }
    fun profileRaw(idx: Int): String? = sp.getString("prof$idx", null)
    fun setProfileRaw(idx: Int, s: String?) {
        val e = sp.edit()
        if (s == null) e.remove("prof$idx") else e.putString("prof$idx", s)
        e.apply()
    }
    fun schedRaw(idx: Int): String? = sp.getString("sch$idx", null)
    fun setSchedRaw(idx: Int, s: String) { sp.edit().putString("sch$idx", s).apply() }

    var applyStyleColors: Boolean get() = b("asc", true); set(v) { sp.edit().putBoolean("asc", v).apply() }

    /** 0 = Android, 1 = Android 12, 2 = iOS */
    var style: Int get() = i("style", 5); set(v) { sp.edit().putInt("style", v).apply() }
    var bgColor: Int get() = i("bg", Color.WHITE); set(v) { sp.edit().putInt("bg", v).apply() }
    var btnTransparency: Int get() = i("bt", 50); set(v) { sp.edit().putInt("bt", v).apply() }
    var btnSize: Int get() = i("bs", 50); set(v) { sp.edit().putInt("bs", v).apply() }
    var sliderTransparency: Int get() = i("st", 0); set(v) { sp.edit().putInt("st", v).apply() }
    var sliderHeight: Int get() = i("sh", 304); set(v) { sp.edit().putInt("sh", v).apply() }
    var posX: Int get() = i("px", 40); set(v) { sp.edit().putInt("px", v).apply() }
    var posY: Int get() = i("py", 500); set(v) { sp.edit().putInt("py", v).apply() }
}

object Sliders {
    val names = listOf("Media", "Ring", "Notification", "Call", "Brightness", "Media booster", "Darkness")
    /** icon path (24 grid) for each slider */
    val paths = listOf(SvgIcon.MUSIC, SvgIcon.BELL, SvgIcon.CHAT, SvgIcon.CALL, SvgIcon.SUN, SvgIcon.SPEAKER, SvgIcon.MOON)
    /** -1 = brightness, -2 = media booster, -3 = darkness */
    val streams = listOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL, -1, -2, -3
    )
    /** designs for the Sliders button face */
    val btnDesignNames = listOf("Mixer", "Tune", "Equalizer", "Waveform", "Speaker", "Grid")
    val btnPaths = listOf("", SvgIcon.TUNE, SvgIcon.EQUALIZER, SvgIcon.WAVE, SvgIcon.SPEAKER, SvgIcon.GRID)
}
