package com.example.assistvolume

import android.content.Context
import android.graphics.Color

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)

    var enabled: Boolean get() = b("enabled", false); set(v) { sp.edit().putBoolean("enabled", v).apply() }
    var pinned: Boolean get() = b("pinned", false); set(v) { sp.edit().putBoolean("pinned", v).apply() }
    var useSystemSlider: Boolean get() = b("sys", false); set(v) { sp.edit().putBoolean("sys", v).apply() }
    var sliderAutoHide: Boolean get() = b("sah", true); set(v) { sp.edit().putBoolean("sah", v).apply() }
    var applyStyleColors: Boolean get() = b("asc", true); set(v) { sp.edit().putBoolean("asc", v).apply() }

    /** 0 = Android, 1 = Android 12, 2 = iOS */
    var style: Int get() = i("style", 1); set(v) { sp.edit().putInt("style", v).apply() }
    var bgColor: Int get() = i("bg", Color.WHITE); set(v) { sp.edit().putInt("bg", v).apply() }
    var btnTransparency: Int get() = i("bt", 50); set(v) { sp.edit().putInt("bt", v).apply() }
    var btnSize: Int get() = i("bs", 50); set(v) { sp.edit().putInt("bs", v).apply() }
    var sliderTransparency: Int get() = i("st", 0); set(v) { sp.edit().putInt("st", v).apply() }
    var sliderHeight: Int get() = i("sh", 304); set(v) { sp.edit().putInt("sh", v).apply() }
    var posX: Int get() = i("px", 40); set(v) { sp.edit().putInt("px", v).apply() }
    var posY: Int get() = i("py", 500); set(v) { sp.edit().putInt("py", v).apply() }
}
