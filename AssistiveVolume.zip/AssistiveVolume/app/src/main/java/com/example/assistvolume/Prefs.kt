package com.example.assistvolume

import android.content.Context
import android.graphics.Color
import android.media.AudioManager

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)

    var enabled: Boolean get() = b("enabled", false); set(v) { sp.edit().putBoolean("enabled", v).apply() }
    var pinned: Boolean get() = b("pinned", false); set(v) { sp.edit().putBoolean("pinned", v).apply() }
    var useSystemSlider: Boolean get() = b("sys", false); set(v) { sp.edit().putBoolean("sys", v).apply() }
    var sliderAutoHide: Boolean get() = b("sah", true); set(v) { sp.edit().putBoolean("sah", v).apply() }
    var powerEnabled: Boolean get() = b("pe", false); set(v) { sp.edit().putBoolean("pe", v).apply() }
    var powerLong: Int get() = i("pl", 0); set(v) { sp.edit().putInt("pl", v).apply() }
    var powerPos: Int get() = i("pp", 0); set(v) { sp.edit().putInt("pp", v).apply() }
    var multiEnabled: Boolean get() = b("me", false); set(v) { sp.edit().putBoolean("me", v).apply() }
    var multiMask: Int get() = i("mm", 1); set(v) { sp.edit().putInt("mm", v).apply() }
    var multiLong: Int get() = i("ml", 0); set(v) { sp.edit().putInt("ml", v).apply() }
    var applyStyleColors: Boolean get() = b("asc", true); set(v) { sp.edit().putBoolean("asc", v).apply() }

    /** 0 = Android, 1 = Android 12, 2 = iOS */
    var style: Int get() = i("style", 1); set(v) { sp.edit().putInt("style", v).apply() }
    var bgColor: Int get() = i("bg", Color.WHITE); set(v) { sp.edit().putInt("bg", v).apply() }
    var btnTransparency: Int get() = i("bt", 50); set(v) { sp.edit().putInt("bt", v).apply() }
    var btnSize: Int get() = i("bs", 50); set(v) { sp.edit().putInt("bs", v).apply() }
    var sliderTransparency: Int get() = i("st", 0); set(v) { sp.edit().putInt("st", v).apply() }
    var sliderHeight: Int get() = i("sh", 304); set(v) { sp.edit().putInt("sh", v).apply() }
    var posX: Int get() = i("px", 40); set(v) { sp.edit().putInt("px", v).apply() }
    var posY: Int get() = i("py", 500); set(v) { sp.edit().putInt("py", v).apply() }
}

object Sliders {
    val names = listOf("Media", "Ring", "Notification", "Call", "Brightness")
    val icons = listOf("\u266A", "\uD83D\uDD14", "\uD83D\uDCAC", "\uD83D\uDCDE", "\u2600")
    /** -1 = screen brightness */
    val streams = listOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL, -1
    )
}
