package com.example.assistvolume

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var applyColors: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "Assistive volume button"
            setTextColor(Color.WHITE); textSize = 22f
        })

        // ---- Show / behaviour ----
        val show = toggle("Show volume buttons", p.enabled) { on -> setEnabled(on) }
        root.addView(show)
        root.addView(toggle("Pin buttons at its position", p.pinned) { p.pinned = it; refresh() })
        root.addView(toggle("Use system volume slider", p.useSystemSlider) { p.useSystemSlider = it; refresh() })

        // ---- Style ----
        root.addView(header("Select style"))
        val rg = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Android", "Android 12", "iOS").forEachIndexed { i, n ->
            rg.addView(RadioButton(this).apply {
                id = View.generateViewId(); text = n; tag = i; setTextColor(Color.WHITE)
            })
        }
        (rg.getChildAt(p.style) as RadioButton).isChecked = true
        rg.setOnCheckedChangeListener { g, id ->
            p.style = g.findViewById<View>(id).tag as Int
            refresh()
        }
        root.addView(rg)

        // ---- Colors ----
        root.addView(header("Color settings"))
        applyColors = toggle("Apply style colors", p.applyStyleColors) { p.applyStyleColors = it; refresh() }
        root.addView(applyColors)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        listOf(
            Color.WHITE, 0xFF1A73E8.toInt(), 0xFFE53935.toInt(), 0xFF43A047.toInt(),
            0xFFFB8C00.toInt(), 0xFF8E24AA.toInt(), Color.BLACK
        ).forEach { c ->
            chips.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(1), Color.GRAY)
                }
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) }
                setOnClickListener {
                    p.bgColor = c; p.applyStyleColors = false
                    applyColors.isChecked = false
                    refresh()
                }
            })
        }
        root.addView(TextView(this).apply { text = "Button background color"; setTextColor(Color.LTGRAY) })
        root.addView(chips)

        // ---- Button settings ----
        root.addView(header("Button settings"))
        root.addView(seek("Transparency", 0, 90, p.btnTransparency, "%") { p.btnTransparency = it; refresh() })
        root.addView(seek("Size", 10, 100, p.btnSize, "") { p.btnSize = it; refresh() })

        // ---- Slider settings ----
        root.addView(header("Slider settings"))
        root.addView(seek("Transparency", 0, 90, p.sliderTransparency, "%") { p.sliderTransparency = it; refresh() })
        root.addView(seek("Height", 100, 600, p.sliderHeight, "") { p.sliderHeight = it; refresh() })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF121212.toInt())
            addView(root)
        })
    }

    private fun setEnabled(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                p.enabled = false
                return
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            p.enabled = true
            refresh()
        } else {
            p.enabled = false
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    private fun refresh() {
        if (p.enabled) startForegroundService(Intent(this, OverlayService::class.java))
    }

    override fun onResume() {
        super.onResume()
        // overlay permission just granted? user can flip the switch again
    }

    // ---------- UI helpers ----------
    private fun header(t: String) = TextView(this).apply {
        text = t; setTextColor(0xFF8AB4F8.toInt()); textSize = 15f; setPadding(0, dp(22), 0, dp(6))
    }

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 16f
        setPadding(0, dp(10), 0, dp(10))
        isChecked = checked
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun seek(label: String, min: Int, max: Int, cur: Int, suffix: String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        val tv = TextView(this).apply { setTextColor(Color.WHITE); text = "$label: $cur$suffix" }
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                val v = pr + min
                tv.text = "$label: $v$suffix"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv); box.addView(sb)
        return box
    }
}
