package com.example.assistvolume

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var content: FrameLayout
    private lateinit var navBar: LinearLayout
    private val navIcons = mutableListOf<NavIcon>()
    private val navHolders = mutableListOf<FrameLayout>()
    private val navLabels = mutableListOf<TextView>()
    private var tab = 0
    private var preview: LivePreview? = null
    private var previewCard: LinearLayout? = null
    private var currentScroll: ScrollView? = null
    private var shownTab = -1
    private val scrollPos = IntArray(5)
    private var statusPill: TextView? = null

    private val tabNames = listOf("Home", "Style", "Behavior", "Settings", "About")

    override fun onCreate(savedInstanceState: Bundle?) {
        applyAppTheme()
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        savedInstanceState?.let { b ->
            tab = b.getInt("tab", 0).coerceIn(0, 4)
            b.getIntArray("scroll")?.let { a -> a.copyInto(scrollPos, 0, 0, minOf(a.size, scrollPos.size)) }
        }

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (!C.glass) setBackgroundColor(C.BG)
        }
        content = FrameLayout(this)
        rootLayout.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            if (C.glass) background = glassBg(30) else setBackgroundColor(C.SURFACE)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        tabNames.forEachIndexed { i, name ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val holder = FrameLayout(this)
            val icon = NavIcon(this, i)
            holder.addView(icon, FrameLayout.LayoutParams(dp(54), dp(30), Gravity.CENTER))
            item.addView(holder, LinearLayout.LayoutParams(dp(54), dp(30)))
            val label = tv(name, 11f, C.TEXT2, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) }
            item.addView(label)
            item.setOnClickListener { showTab(i) }
            navBar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
            navIcons.add(icon); navHolders.add(holder); navLabels.add(label)
        }
        rootLayout.addView(navBar, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            if (C.glass) setMargins(dp(14), dp(4), dp(14), dp(10))
        })
        setContentView(rootLayout)
        applyBars()
        try { ScheduleManager.scheduleAll(this) } catch (_: Exception) {}
        showTab(tab)
        if (!p.wizardDone && !p.enabled) startActivity(Intent(this, WizardActivity::class.java))
    }

    override fun onResume() {
        super.onResume()
        showTab(tab)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        currentScroll?.let { if (shownTab in scrollPos.indices) scrollPos[shownTab] = it.scrollY }
        outState.putInt("tab", tab)
        outState.putIntArray("scroll", scrollPos)
    }

    private fun showTab(i: Int) {
        // remember where the user was reading, so rebuilding the page never throws them back to the top
        currentScroll?.let { if (shownTab in scrollPos.indices) scrollPos[shownTab] = it.scrollY }
        tab = i
        content.removeAllViews()
        statusPill = null
        val page = when (i) {
            0 -> homePage()
            1 -> stylePage()
            2 -> behaviorPage()
            3 -> settingsPage()
            else -> aboutPage()
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(page)
        }
        val host = lin()
        if (i == 1 || i == 2) host.addView(previewContainer())
        host.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        content.addView(host, FrameLayout.LayoutParams(MATCH, MATCH))
        scroll.restoreScroll(scrollPos[i])
        currentScroll = scroll
        shownTab = i
        navIcons.forEachIndexed { k, ic ->
            val on = k == i
            ic.active = on
            navHolders[k].background = if (on) gradient(15) else null
            navLabels[k].setTextColor(if (on) C.PRIMARY_LIGHT else C.TEXT2)
        }
    }

    /** The live preview stays pinned above the settings on the Style and Behavior tabs. */
    private fun previewContainer(): View {
        previewCard?.let { (it.parent as? ViewGroup)?.removeView(it); return it }
        val lp = LivePreview(this, p)
        preview = lp
        val box = lin().apply { setPadding(dp(14), dp(8), dp(14), dp(2)) }
        val head = lin(false).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, 0, dp(6)) }
        head.addView(tv("LIVE PREVIEW", 11.5f, C.TEXT2, true).apply { letterSpacing = 0.08f },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        val toggle = tv(if (p.previewHidden) "Show \u25BE" else "Hide \u25B4", 12.5f, C.PRIMARY_LIGHT, true)
            .apply { setPadding(dp(10), dp(4), dp(10), dp(4)) }
        head.addView(toggle)
        box.addView(head)
        box.addView(lp, LinearLayout.LayoutParams(MATCH, dp(PREVIEW_HEIGHT)))
        lp.visibility = if (p.previewHidden) View.GONE else View.VISIBLE
        toggle.setOnClickListener {
            p.previewHidden = !p.previewHidden
            lp.visibility = if (p.previewHidden) View.GONE else View.VISIBLE
            toggle.text = if (p.previewHidden) "Show \u25BE" else "Hide \u25B4"
            if (!p.previewHidden) lp.update()
        }
        previewCard = box
        return box
    }

    private fun page(build: LinearLayout.() -> Unit): LinearLayout {
        val l = lin().apply { setPadding(dp(14), dp(18), dp(14), dp(24)) }
        l.build()
        return l
    }

    private fun changed() {
        refresh()
        preview?.update()
    }

    private fun refresh() {
        if (p.enabled) startForegroundService(Intent(this, OverlayService::class.java))
    }

    // =========================================================================================
    // HOME
    // =========================================================================================
    private fun homePage() = page {
        // hero
        val hero = lin().apply {
            background = glossy(GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#5B54F0"), Color.parseColor("#2D8CFF"))).apply { cornerRadius = dp(26).toFloat() }, 26)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        val top = lin(false).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this@MainActivity).apply { setImageResource(IconManager.logos[p.iconVariant]) },
            LinearLayout.LayoutParams(dp(56), dp(56)))
        val tcol = lin().apply { setPadding(dp(14), 0, 0, 0) }
        tcol.addView(tv("Assistive Volume", 20f, Color.WHITE, true))
        tcol.addView(tv("Floating shortcuts for your phone", 12.5f, Color.parseColor("#DCE6FF")))
        top.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        hero.addView(top)

        val running = p.enabled
        val statusRow = lin(false).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(20), 0, 0) }
        val scol = lin()
        scol.addView(tv("Floating shortcut", 16f, Color.WHITE, true))
        val sp1 = pill(if (running) "\u25CF Running" else "\u25CF Stopped", Color.WHITE)
        sp1.background = shape(Color.argb(60, 255, 255, 255), 12)
        statusPill = sp1
        scol.addView(sp1, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        statusRow.addView(scol, LinearLayout.LayoutParams(0, WRAP, 1f))
        val master = Switch(this@MainActivity).apply {
            isChecked = running
            scaleX = 1.25f; scaleY = 1.25f
            setOnCheckedChangeListener { _, on -> setEnabled(on) }
        }
        statusRow.addView(master)
        hero.addView(statusRow)
        addView(hero)

        // setup checklist
        addView(sectionLabel("Setup checklist"))
        val setup = card()
        setup.addRow(permRow("\uD83E\uDEA7", C.PRIMARY, "Display over other apps", "Required to show the shortcut",
            Settings.canDrawOverlays(this@MainActivity)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        setup.addRow(permRow("\u267F", C.PRIMARY2, "Accessibility service", "Power menu, lock, screenshot, per-app, keyboard",
            ControlService.instance != null) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        setup.addRow(permRow("\uD83D\uDD14", C.AMBER, "Notifications", "Keeps the service alive reliably", notifOk) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        setup.addRow(permRow("\u2600\uFE0F", C.AMBER, "Modify system settings", "Optional, only for the brightness slider",
            Settings.System.canWrite(this@MainActivity)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        addView(setup)

        // shortcut buttons
        addView(sectionLabel("Shortcut buttons"))
        val btns = card()
        btns.addRow(switchRow("\u23FB", C.RED, "Power button", "Tap to lock, long press for more", p.powerEnabled) { p.powerEnabled = it; refresh() })
        btns.addRow(switchRow("\uD83C\uDF9A\uFE0F", C.PRIMARY, "Sliders button", "Opens Media, Ring, Brightness and more", p.multiEnabled) { p.multiEnabled = it; refresh() })
        btns.addRow(switchRow("\uD83D\uDD0A", C.PRIMARY2, "Volume \u25B2 \u25BC buttons", "Show + and \u2212 buttons on screen", p.showVolButtons) { p.showVolButtons = it; refresh() })
        btns.addRow(switchRow("\uD83D\uDCCC", C.GREEN, "Pin position", "Stop the shortcut from moving", p.pinned) { p.pinned = it; refresh() })
        addView(btns)

        addView(sectionLabel("Volume profiles"))
        val pf = card()
        val pscroll = HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false }
        val prow = lin(false).apply { setPadding(dp(12), dp(14), dp(12), dp(14)) }
        Profiles.names.forEachIndexed { i, n ->
            val on = p.curProfile == i
            val t = lin().apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(12), dp(16), dp(12))
                background = if (on) gradient(16) else shape(C.SURFACE2, 16, C.STROKE, 1)
                setOnClickListener {
                    Profiles.apply(this@MainActivity, i)
                    Toast.makeText(this@MainActivity, "${Profiles.emojis[i]} $n applied", Toast.LENGTH_SHORT).show()
                    showTab(0)
                }
            }
            t.addView(tv(Profiles.emojis[i], 22f))
            t.addView(tv(n, 12f, if (on) Color.WHITE else C.TEXT2, true).apply { setPadding(0, dp(4), 0, 0) })
            prow.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(10) })
        }
        pscroll.addView(prow)
        pf.addView(pscroll)
        pf.addRow(navRow("\uD83D\uDDD3\uFE0F", C.PRIMARY, "Edit profiles & schedule", "Automatic Night mode and more") {
            startActivity(Intent(this@MainActivity, ProfilesActivity::class.java))
        })
        addView(pf)

        addView(tv("Tip: drag the shortcut up or down, and let go near the left or right edge. It always snaps to an edge.",
            12.5f, C.TEXT2).apply { setPadding(dp(8), dp(14), dp(8), 0) })
    }

    private fun permRow(emoji: String, tint: Int, title: String, sub: String, ok: Boolean, grant: () -> Unit): View {
        val trailing: View = if (ok) pill("Granted", C.GREEN) else tv("Grant", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(14), dp(7), dp(14), dp(7)); background = gradient(12)
        }
        return settingRow(emoji, tint, title, sub, trailing, if (ok) null else grant)
    }

    private fun setEnabled(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                p.enabled = false
                showTab(0)
                return
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            p.enabled = true
            startForegroundService(Intent(this, OverlayService::class.java))
        } else {
            p.enabled = false
            p.locked = false
            p.lockUntil = 0L
            stopService(Intent(this, OverlayService::class.java))
        }
        statusPill?.text = if (on) "\u25CF Running" else "\u25CF Stopped"
    }

    // =========================================================================================
    // STYLE
    // =========================================================================================
    private fun stylePage() = page {
        addView(pageTitle("Style", "Make the shortcut look the way you like"))


        addView(sectionLabel("Buttons"))
        val c1 = card()
        c1.addView(tv("Button style", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(14), 0, 0) })
        c1.addView(chipRow(BTN_STYLE_NAMES, BTN_STYLE_IDS.indexOf(p.btnStyle).coerceAtLeast(0)) { p.btnStyle = BTN_STYLE_IDS[it]; changed() })
        c1.addView(tv("Shape", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(2), 0, 0) })
        c1.addView(chipRow(listOf("Circle", "Rounded square"), p.btnShape) { p.btnShape = it; changed() })
        addView(c1)

        addView(sectionLabel("Colors"))
        val c2 = card()
        c2.addRow(switchRow("\u2728", C.PRIMARY, "Use style colors", "Automatic colors for each style", p.applyStyleColors) {
            p.applyStyleColors = it; changed()
        })
        c2.addView(tv("Accent color", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(10), 0, 0) })
        c2.addView(swatchRow(
            listOf(Color.WHITE, 0xFF1A73E8.toInt(), 0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFEC407A.toInt(),
                0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFF43A047.toInt(), Color.BLACK),
            if (p.applyStyleColors) null else p.bgColor
        ) { p.bgColor = it; p.applyStyleColors = false; changed(); showTab(1) })
        addView(c2)

        addView(sectionLabel("Size"))
        val c3 = card()
        c3.addRow(seekRow("\u2B55", C.PRIMARY, "Button size", 10, 100, p.btnSize, "") { p.btnSize = it; changed() })
        c3.addRow(seekRow("\u2795", C.PRIMARY2, "Icon size", 30, 90, p.iconScale, "%") { p.iconScale = it; changed() })
        c3.addRow(seekRow("\u2195\uFE0F", C.GREEN, "Space between buttons", 0, 40, p.btnGap, "") { p.btnGap = it; changed() })
        c3.addRow(seekRow("\uD83D\uDC7B", C.AMBER, "Button transparency", 0, 90, p.btnTransparency, "%") { p.btnTransparency = it; changed() })
        addView(c3)

        addView(sectionLabel("Sliders"))
        val c4 = card()
        c4.addView(tv("Slider style", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(14), 0, 0) })
        c4.addView(chipRow(SLIDER_STYLE_NAMES, SLIDER_STYLE_IDS.indexOf(p.style).coerceAtLeast(0)) { p.style = SLIDER_STYLE_IDS[it]; changed() })
        c4.addRow(seekRow("\u2194\uFE0F", C.PRIMARY, "Slider width", 30, 120, p.sliderWidth, "") { p.sliderWidth = it; changed() })
        c4.addRow(seekRow("\u2195\uFE0F", C.PRIMARY2, "Slider height", 100, 600, p.sliderHeight, "") { p.sliderHeight = it; changed() })
        c4.addRow(seekRow("\uD83D\uDC7B", C.AMBER, "Slider transparency", 0, 90, p.sliderTransparency, "%") { p.sliderTransparency = it; changed() })
        addView(c4)

        addView(sectionLabel("Level colors"))
        val c8 = card()
        c8.addRow(choiceRow("\uD83C\uDFA8", C.PRIMARY, "Level color",
            listOf("Automatic (match style)", "One color for all sliders", "A different color for each slider"), p.lvMode) {
            p.lvMode = it; changed(); showTab(1)
        })
        if (p.lvMode == 1) {
            c8.addRow(colorRow("\uD83D\uDD8C\uFE0F", C.PRIMARY2, "Pick the color", p.lvColor) {
                p.lvColor = it; changed(); showTab(1)
            })
        }
        if (p.lvMode == 2) {
            Sliders.names.forEachIndexed { i, n ->
                c8.addRow(colorRow(SLIDER_EMOJI[i], C.PRIMARY, n, p.levelColor(i)) {
                    p.setLevelColorFor(i, it); changed(); showTab(1)
                })
            }
        }
        c8.addRow(seekRow("\uD83D\uDCA7", C.PRIMARY, "Level opacity", 20, 100, p.lvAlpha, "%") { p.lvAlpha = it; changed() })
        c8.addRow(seekRow("\uD83C\uDF2B\uFE0F", C.AMBER, "Empty part opacity", 0, 100, p.lvTrack, "%") { p.lvTrack = it; changed() })
        c8.addRow(choiceRow("\uD83D\uDD24", C.GREEN, "Icon and number color", listOf("Automatic", "White", "Dark"), p.iconColorMode) {
            p.iconColorMode = it; changed()
        })
        c8.addRow(navRow("\u267B\uFE0F", C.RED, "Reset level colors", null) {
            p.lvMode = 0; p.lvAlpha = 100; p.lvTrack = 100; p.iconColorMode = 0
            changed(); showTab(1)
        })
        addView(c8)

        addView(sectionLabel("Slider icons"))
        val c6 = card()
        c6.addRow(switchRow("\uD83D\uDDBC\uFE0F", C.PRIMARY, "Show icons", "An icon inside every slider", p.sliderIcons) { p.sliderIcons = it; changed() })
        c6.addView(tv("Icon design", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(10), 0, 0) })
        c6.addView(chipRow(listOf("Line", "Bold", "Filled"), p.sliderIconStyle) { p.sliderIconStyle = it; changed() })
        c6.addView(tv("Icon position", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(2), 0, 0) })
        c6.addView(chipRow(listOf("Bottom", "Top"), p.sliderIconPos) { p.sliderIconPos = it; changed() })
        c6.addRow(seekRow("\uD83D\uDD0D", C.PRIMARY2, "Icon size", 50, 150, p.sliderIconSize, "%") { p.sliderIconSize = it; changed() })
        c6.addRow(switchRow("\uD83D\uDD22", C.GREEN, "Show percentage", "Number inside the slider", p.sliderPercent) { p.sliderPercent = it; changed() })
        addView(c6)

        addView(sectionLabel("Sliders button"))
        val c7 = card()
        c7.addView(tv("Button icon design", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(14), 0, 0) })
        c7.addView(chipRow(Sliders.btnDesignNames, p.sbIcon) { p.sbIcon = it; changed() })
        c7.addRow(seekRow("\uD83D\uDCCF", C.PRIMARY, "Button size", 70, 150, p.sbScale, "%") { p.sbScale = it; changed() })
        c7.addRow(switchRow("\uD83C\uDFA8", C.AMBER, "Custom button color", "Different from the other buttons", p.sbCustomColor) {
            p.sbCustomColor = it; changed(); showTab(1)
        })
        if (p.sbCustomColor) {
            c7.addView(swatchRow(
                listOf(0xFF00BFA5.toInt(), 0xFF1A73E8.toInt(), 0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFEC407A.toInt(),
                    0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFF43A047.toInt(), Color.WHITE, Color.BLACK),
                p.sbColor
            ) { p.sbColor = it; changed(); showTab(1) })
        }
        addView(c7)

        addView(sectionLabel("App icon"))
        val c5 = card()
        c5.addView(tv("Pick the icon shown on your home screen", 12.5f, C.TEXT2).apply { setPadding(dp(16), dp(14), dp(16), 0) })
        val tiles = lin(false).apply { setPadding(dp(10), dp(12), dp(10), dp(14)) }
        IconManager.names.forEachIndexed { i, name ->
            val t = lin().apply { gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)) }
            val img = ImageView(this@MainActivity).apply { setImageResource(IconManager.logos[i]) }
            val frame = FrameLayout(this@MainActivity).apply {
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = if (i == p.iconVariant) shape(Color.TRANSPARENT, 18, C.PRIMARY_LIGHT, 2) else null
            }
            frame.addView(img, FrameLayout.LayoutParams(dp(52), dp(52)))
            t.addView(frame)
            t.addView(tv(name, 11f, if (i == p.iconVariant) C.PRIMARY_LIGHT else C.TEXT2, true).apply { gravity = Gravity.CENTER })
            t.setOnClickListener {
                IconManager.apply(this@MainActivity, i)
                Toast.makeText(this@MainActivity, "$name icon applied. Your launcher may take a few seconds to update.", Toast.LENGTH_LONG).show()
                showTab(1)
            }
            tiles.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        c5.addView(tiles)
        addView(c5)
    }

    // =========================================================================================
    // BEHAVIOR
    // =========================================================================================
    private fun behaviorPage() = page {
        addView(pageTitle("Behavior", "How the shortcut acts"))

        addView(sectionLabel("Position"))
        val pos = card()
        pos.addRow(choiceRow("\u2194\uFE0F", C.PRIMARY, "Screen edge", listOf("Left edge", "Right edge"), p.side) { p.side = it; changed() })
        addView(pos)

        addView(sectionLabel("Auto hide"))
        val ah = card()
        ah.addRow(switchRow("\uD83D\uDC41\uFE0F", C.PRIMARY, "Show slider only when adjusting", "Slider appears when you change volume", p.sliderAutoHide) { p.sliderAutoHide = it; changed() })
        ah.addRow(switchRow("\uD83D\uDC46", C.PRIMARY2, "Hide when I touch elsewhere", "Tap anywhere on screen to close at once", p.tapOutside) { p.tapOutside = it; refresh() })
        ah.addRow(seekRow("\u23F1\uFE0F", C.AMBER, "Hide after", 1, 15, p.hideDelay, " s") { p.hideDelay = it; changed() })
        addView(ah)

        addView(sectionLabel("Gestures"))
        val gs = card()
        gs.addRow(switchRow("\uD83D\uDC46", C.PRIMARY, "Swipe on Sliders button", "Swipe up or down to change volume. Drag sideways to move the shortcut.", p.swipeVolume) { p.swipeVolume = it; refresh() })
        gs.addRow(choiceRow("\u270C\uFE0F", C.PRIMARY2, "Double-tap Sliders button", Actions.names, p.sbDouble) { p.sbDouble = it; refresh() })
        gs.addRow(choiceRow("\u270C\uFE0F", C.RED, "Double-tap Power button", Actions.names, p.pwDouble) { p.pwDouble = it; refresh() })
        addView(gs)
        addView(tv("Double-tap on the Power button turns on the Touch lock (kids mode). Double-tap it again to unlock.",
            12.5f, C.TEXT2).apply { setPadding(dp(8), dp(8), dp(8), 0) })

        addView(sectionLabel("Touch lock (kids mode)"))
        val tl = card()
        tl.addRow(navRow("\uD83D\uDD12", C.AMBER, "Lock the screen now", "Every touch on the screen is ignored") {
            val s = OverlayService.instance
            if (s == null) Toast.makeText(this@MainActivity, "Turn on the floating shortcut first", Toast.LENGTH_SHORT).show()
            else s.toggleTouchLock()
        })
        tl.addRow(choiceRow("\uD83C\uDF13", C.PRIMARY, "Dim the screen while locked", listOf("Don't dim", "Slightly", "Dark"), p.lockDim) { p.lockDim = it; preview?.demoLock() })
        tl.addRow(switchRow("\uD83D\uDEE1\uFE0F", C.GREEN, "Safer unlock", "Press and hold the lock button for 1.5 s instead of double-tap", p.lockSafeUnlock) {
            p.lockSafeUnlock = it; refresh(); preview?.demoLock()
        })
        tl.addRow(choiceRow("\u23F2\uFE0F", C.AMBER, "Auto-unlock after",
            listOf("Never", "5 minutes", "15 minutes", "30 minutes", "1 hour"), p.lockTimeout) { p.lockTimeout = it; preview?.demoLock() })
        addView(tl)
        addView(tv("While locked only the lock button works. Android's own Home and Back gestures and the phone's volume and power keys cannot be blocked by any app. For full protection also turn on Android's Screen pinning.",
            12.5f, C.TEXT2).apply { setPadding(dp(8), dp(8), dp(8), 0) })

        addView(sectionLabel("Fade & hide"))
        val fh = card()
        fh.addRow(switchRow("\uD83C\uDF2B\uFE0F", C.PRIMARY, "Fade when idle", "Shortcut becomes see-through when you are not using it", p.idleFade) { p.idleFade = it; changed() })
        fh.addRow(seekRow("\u23F1\uFE0F", C.AMBER, "Fade after", 2, 15, p.idleDelay, " s") { p.idleDelay = it; changed() })
        fh.addRow(seekRow("\uD83D\uDC7B", C.PRIMARY2, "Idle opacity", 10, 80, p.idleOpacity, "%") { p.idleOpacity = it; changed() })
        fh.addRow(switchRow("\uD83D\uDCF1", C.GREEN, "Hide in landscape", "Useful for videos and games", p.hideLandscape) { p.hideLandscape = it; refresh() })
        fh.addRow(switchRow("\uD83C\uDFAC", C.AMBER, "Hide in full-screen apps (beta)", "Hides when an app hides the status bar. Works on most phones.", p.hideFullscreen) { p.hideFullscreen = it; refresh() })
        addView(fh)

        addView(sectionLabel("Animation"))
        val an = card()
        an.addRow(switchRow("\uD83C\uDFAC", C.PRIMARY, "Animations", "Animate opening and closing", p.animEnabled) { p.animEnabled = it; preview?.replay() })
        an.addRow(choiceRow("\uD83E\uDE84", C.PRIMARY2, "Animation type",
            listOf("Fade", "Slide", "Zoom", "Bounce", "Flip"), p.animType) { p.animType = it; preview?.replay(); OverlayService.instance?.previewAnimation() })
        an.addRow(seekRow("\u23F3", C.AMBER, "Animation time", 100, 1000, p.animDuration, " ms") { p.animDuration = it; preview?.replay() })
        val pb = ghostButton("\u25B6  Preview animation") {
            preview?.replay()
            OverlayService.instance?.previewAnimation()
        }
        an.addView(pb, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(6), dp(16), dp(16)) })
        addView(an)

        addView(sectionLabel("Power button"))
        val pw = card()
        pw.addRow(choiceRow("\u23FB", C.RED, "Long press action",
            listOf("Open power dialog", "Open notifications", "Take screenshot"), p.powerLong) { p.powerLong = it; refresh() })
        addView(pw)
        addView(tv("Tap on the power button locks the screen.", 12.5f, C.TEXT2).apply { setPadding(dp(8), dp(8), dp(8), 0) })

        addView(sectionLabel("Sliders button"))
        val ms = card()
        ms.addView(tv("Sliders to show", 13f, C.TEXT2, true).apply { setPadding(dp(16), dp(14), 0, 0) })
        ms.addView(multiChipRow(Sliders.names, p.multiMask) { m ->
            val addedBrightness = (m and (1 shl 4)) != 0 && (p.multiMask and (1 shl 4)) == 0
            p.multiMask = m
            if (addedBrightness && !Settings.System.canWrite(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "Allow 'Modify system settings' for brightness", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            }
            changed()
        })
        ms.addRow(choiceRow("\uD83D\uDC49", C.PRIMARY, "Long press action",
            listOf("Hide buttons", "Screen off", "Open notifications", "Mute media volume", "Take screenshot", "Next volume profile"), p.multiLong) { p.multiLong = it; refresh() })
        addView(ms)

        addView(sectionLabel("Proximity sensor"))
        val px = card()
        px.addRow(choiceRow("\uD83E\uDD1A", C.GREEN, "When covered (in pocket)", listOf("No action", "Screen off"), p.proxNear) { p.proxNear = it; refresh() })
        px.addRow(choiceRow("\uD83D\uDC4B", C.AMBER, "When uncovered", listOf("No action", "Screen on"), p.proxAway) { p.proxAway = it; refresh() })
        addView(px)

        addView(sectionLabel("Smart"))
        val sm = card()
        sm.addRow(switchRow("\uD83D\uDCF1", C.PRIMARY, "Config per app", "Hide buttons or set volume per app", p.perApp) { p.perApp = it; refresh() })
        sm.addRow(navRow("\uD83D\uDDC2\uFE0F", C.PRIMARY2, "Choose apps", "Set rules for each app") {
            startActivity(Intent(this@MainActivity, AppConfigActivity::class.java))
        })
        sm.addRow(switchRow("\u2328\uFE0F", C.GREEN, "Sensitive to keyboard", "Move buttons up when the keyboard opens", p.keyboardSensitive) { p.keyboardSensitive = it; refresh() })
        sm.addRow(navRow("\uD83C\uDF9A\uFE0F", C.AMBER, "Volume profiles", "Presets and automatic schedule") {
            startActivity(Intent(this@MainActivity, ProfilesActivity::class.java))
        })
        addView(sm)
    }

    // =========================================================================================
    // SETTINGS
    // =========================================================================================
    private fun settingsPage() = page {
        addView(pageTitle("Settings", "General options and data"))

        addView(sectionLabel("Appearance"))
        val ap = card()
        ap.addRow(choiceRow("\uD83C\uDFA8", C.PRIMARY, "Theme", THEME_NAMES, THEME_IDS.indexOf(p.theme).coerceAtLeast(0)) {
            p.theme = THEME_IDS[it]
            recreate()
        })
        addView(ap)

        addView(sectionLabel("General"))
        val g = card()
        g.addRow(switchRow("\uD83D\uDE80", C.PRIMARY, "Start on boot", "Start the shortcut after the phone restarts", p.bootStart) { p.bootStart = it })
        g.addRow(switchRow("\uD83D\uDCF3", C.PRIMARY2, "Haptic feedback", "Small vibration when you tap a button", p.haptic) { p.haptic = it })
        g.addRow(switchRow("\uD83D\uDD0A", C.GREEN, "Use system volume panel", "Also show Android's own volume bar", p.useSystemSlider) { p.useSystemSlider = it; refresh() })
        addView(g)

        addView(sectionLabel("Keep it running"))
        val k = card()
        k.addRow(navRow("\uD83D\uDD0B", C.AMBER, "Battery optimization", "Set to 'Not optimized' so Android does not stop the app") {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        })
        k.addRow(navRow("\u2699\uFE0F", C.PRIMARY, "App info", "Permissions, storage, auto-start") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        k.addRow(navRow("\uD83D\uDE80", C.PRIMARY2, "Auto-start", "Allow the app to start after the phone restarts (Xiaomi, Oppo, Vivo...)") {
            Autostart.open(this@MainActivity)
        })
        k.addRow(navRow("\uD83E\uDDED", C.GREEN, "Setup guide", "Run the first-time setup again") {
            startActivity(Intent(this@MainActivity, WizardActivity::class.java))
        })
        addView(k)

        addView(sectionLabel("Backup"))
        val b = card()
        b.addRow(navRow("\uD83D\uDCE4", C.PRIMARY2, "Back up settings", "Copy all settings to the clipboard") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("AssistiveVolume backup", p.exportJson()))
            Toast.makeText(this@MainActivity, "Backup copied. Paste it in Notes or a chat to keep it.", Toast.LENGTH_LONG).show()
        })
        b.addRow(navRow("\uD83D\uDCE5", C.GREEN, "Restore settings", "Paste a backup from the clipboard") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            if (p.importJson(txt)) {
                Toast.makeText(this@MainActivity, "Settings restored", Toast.LENGTH_SHORT).show()
                refresh(); showTab(3)
            } else Toast.makeText(this@MainActivity, "No valid backup found in the clipboard", Toast.LENGTH_LONG).show()
        })
        b.addRow(navRow("\u267B\uFE0F", C.RED, "Reset to default", "Clear all your settings") {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Reset all settings?")
                .setMessage("This returns every option to its default value.")
                .setPositiveButton("Reset") { _, _ ->
                    val was = p.enabled
                    p.resetAll()
                    if (was) stopService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Settings reset", Toast.LENGTH_SHORT).show()
                    showTab(3)
                }
                .setNegativeButton("Cancel", null).show()
        })
        addView(b)
    }

    // =========================================================================================
    // ABOUT
    // =========================================================================================
    private fun aboutPage() = page {
        val pi = packageManager.getPackageInfo(packageName, 0)
        val vName = pi.versionName ?: "2.0"
        val vCode = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        val updated = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(pi.lastUpdateTime))

        val head = lin().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        head.addView(ImageView(this@MainActivity).apply { setImageResource(IconManager.logos[p.iconVariant]) },
            LinearLayout.LayoutParams(dp(92), dp(92)))
        head.addView(tv("Assistive Volume", 22f, C.TEXT, true).apply { setPadding(0, dp(12), 0, 0) })
        head.addView(tv("Version $vName", 13.5f, C.TEXT2).apply { setPadding(0, dp(2), 0, 0) })
        addView(head)

        addView(sectionLabel("Version details"))
        val v = card()
        v.addRow(infoRow("\uD83C\uDFF7\uFE0F", C.PRIMARY, "Version", vName))
        v.addRow(infoRow("\uD83D\uDD22", C.PRIMARY2, "Build number", vCode.toString()))
        v.addRow(infoRow("\uD83D\uDCC5", C.GREEN, "Last updated", updated))
        v.addRow(infoRow("\uD83D\uDCE6", C.AMBER, "Package", packageName))
        v.addRow(infoRow("\uD83E\uDD16", C.GREEN, "Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"))
        v.addRow(infoRow("\uD83D\uDCF1", C.PRIMARY, "Device", "${Build.MANUFACTURER} ${Build.MODEL}"))
        addView(v)

        addView(sectionLabel("Developer"))
        val dv = card()
        val dr = lin(false).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        dr.addView(tv("SA", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(C.PRIMARY, C.PRIMARY2); orientation = GradientDrawable.Orientation.TL_BR
            }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        val dc = lin().apply { setPadding(dp(14), 0, 0, 0) }
        dc.addView(tv("Suhail Ahamed", 17f, C.TEXT, true))
        dc.addView(tv("Developer & designer", 13f, C.TEXT2))
        dr.addView(dc)
        dv.addView(dr)
        dv.addRow(navRow("\u2709\uFE0F", C.PRIMARY, "Email", DEV_EMAIL) { email("Assistive Volume feedback", "") })
        dv.addRow(navRow("\uD83D\uDC1E", C.RED, "Report a problem", "Opens your email app with device details") {
            email("Assistive Volume problem report (v$vName)",
                "Describe the problem here:\n\n\n---\nApp: $vName ($vCode)\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nDevice: ${Build.MANUFACTURER} ${Build.MODEL}")
        })
        addView(dv)

        addView(sectionLabel("Information"))
        val inf = card()
        inf.addRow(navRow("\u2728", C.PRIMARY, "What's new", "Version $vName") { infoDialog("What's new in $vName", WHATS_NEW) })
        inf.addRow(navRow("\u2753", C.PRIMARY2, "Help & FAQ", "Setup and troubleshooting") { infoDialog("Help & FAQ", FAQ) })
        inf.addRow(navRow("\uD83D\uDD10", C.GREEN, "Permissions explained", "Why each permission is needed") { infoDialog("Permissions", PERMS) })
        inf.addRow(navRow("\uD83D\uDEE1\uFE0F", C.AMBER, "Privacy policy", "Your data stays on your phone") { infoDialog("Privacy policy", PRIVACY) })
        inf.addRow(navRow("\uD83D\uDCC3", C.PRIMARY, "Terms of use", null) { infoDialog("Terms of use", TERMS) })
        inf.addRow(navRow("\uD83E\uDDE9", C.PRIMARY2, "Open-source licences", "No third-party libraries") { infoDialog("Open-source licences", LICENSES) })
        addView(inf)

        addView(sectionLabel("Share"))
        val sh = card()
        sh.addRow(navRow("\uD83D\uDCE4", C.GREEN, "Share this app", null) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Try Assistive Volume, floating power and volume shortcuts. Made by Suhail Ahamed.")
            }, "Share via"))
        })
        addView(sh)

        addView(tv("\u00A9 2026 Suhail Ahamed. All rights reserved.", 12f, C.TEXT2).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(22), 0, dp(4))
        })
        addView(tv("Made with care", 11.5f, C.TEXT2).apply { gravity = Gravity.CENTER })
    }

    private fun email(subject: String, body: String) {
        val i = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(DEV_EMAIL))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        try { startActivity(i) }
        catch (_: Exception) { Toast.makeText(this, "No email app found. Write to $DEV_EMAIL", Toast.LENGTH_LONG).show() }
    }

    companion object {
        const val PREVIEW_HEIGHT = 210
        const val DEV_EMAIL = "ApkDeveloperTool@gmail.com"
        val BTN_STYLE_NAMES = listOf("Gradient", "Solid", "Glass", "Neon", "Outline", "Crystal Glass (experimental)")
        val BTN_STYLE_IDS = listOf(3, 0, 1, 2, 4, 5)
        val SLIDER_STYLE_NAMES = listOf("Android 12", "iOS", "Android", "Glass", "Segments", "Crystal Glass (experimental)")
        val SLIDER_STYLE_IDS = listOf(1, 2, 0, 3, 4, 5)
        val THEME_NAMES = listOf("Dark", "AMOLED black", "Light", "Auto (follow phone)")
        val THEME_IDS = listOf(0, 1, 2, 3)
        val SLIDER_EMOJI = listOf("\uD83C\uDFB5", "\uD83D\uDD14", "\uD83D\uDCAC", "\uD83D\uDCDE", "\u2600\uFE0F", "\uD83D\uDD0A", "\uD83C\uDF11")
        const val WHATS_NEW = "\u2022 Live preview pinned on the Style and Behavior tabs: every change is visible at once\n" +
            "\u2022 The preview replays open, close, hide-after, fade and the touch lock screen\n" +
            "\u2022 Fixed: the Darkness slider no longer blocks touches or stops while dragging\n" +
            "\u2022 Fixed: the page stays where you were after every change (no jump to the top or to Home)\n" +
            "\n" +
            "Version 2.4\n" +
            "\u2022 \u2022 Back to the clean Dark and AMOLED themes (also Light and Auto)\n" +
            "\u2022 Level colors: one color for all sliders, or a different color for each slider, with a color picker\n" +
            "\u2022 Level opacity, empty-part opacity and icon / number color\n" +
            "\u2022 Touch lock for kids: double-tap the Power button to block all touches, double-tap again to unlock\n" +
            "\u2022 Touch lock options: dim the screen, safer press-and-hold unlock, auto-unlock timer\n" +
            "\u2022 Crystal Glass is now only an optional button and slider style\n" +
            "\n" +
            "Version 2.3\n" +
            "\u2022 Crystal Glass buttons and sliders with a springy press effect\n" +
            "\n" +
            "Version 2.2\n" +
            "\u2022 First-run setup guide that walks you through every permission\n" +
            "\u2022 Volume profiles: Silent, Meeting, Night, Outdoor, Driving (editable)\n" +
            "\u2022 Automatic schedules, e.g. Night mode at 10 pm\n" +
            "\u2022 Gestures: swipe on the Sliders button to change volume, double-tap actions\n" +
            "\u2022 Fade when idle, hide in landscape and full-screen apps\n" +
            "\u2022 Themes: Dark, AMOLED black, Light and Auto\n" +
            "\u2022 More reliable start after the phone restarts or the app updates\n" +
            "\u2022 Every setting is kept exactly as you left it\n" +
            "\n" +
            "Version 2.1\n" +
            "\u2022 Volume-themed app icons, vector slider icons, Sliders button designs\n" +
            "\n" +
            "Version 2.0\n" +
            "\u2022 Edge shortcut, animations, button styles, backup & restore"

        const val FAQ = "Buttons do not show?\nTurn on the main switch on Home and allow 'Display over other apps'.\n\n" +
            "Power menu / lock / screenshot do nothing?\nEnable the Accessibility service on Home.\n\n" +
            "Shortcut disappears after some time?\nOpen Settings > Battery optimization and choose 'Not optimized'. On Xiaomi, Oppo, Vivo, Huawei and similar phones also allow Auto-start in App info.\n\n" +
            "Brightness slider does not work?\nAllow 'Modify system settings'.\n\n" +
            "Media booster does nothing?\nSome phones do not support it.\n\n" +
            "Does it start after a restart?\nIt should. If not, open Settings > Auto-start and Battery optimization (or the Setup guide) and allow both. Your settings are never reset by a restart.\n\nIcon did not change?\nSome launchers need a few seconds, or a restart of the launcher.\n\nStill stuck?\nEmail $DEV_EMAIL from About > Report a problem."

        const val PERMS = "Display over other apps: draws the floating shortcut above other apps.\n\n" +
            "Accessibility service: performs Power menu, Lock screen, Notifications and Screenshot, detects which app is open and whether the keyboard is showing. It does not read, store or send anything on your screen.\n\n" +
            "Notifications: shows the small 'Running' notification that keeps the service alive.\n\n" +
            "Modify system settings: only for the brightness slider.\n\n" +
            "Wake lock: turns the screen on when you take the phone out of your pocket (proximity option).\n\n" +
            "Receive boot completed: starts the shortcut after a restart."

        const val PRIVACY = "Assistive Volume does not collect, store or share any personal data.\n\n" +
            "The app has no internet permission, so nothing can leave your phone. All settings are saved only on your device.\n\n" +
            "You can clear everything at any time from Settings > Reset to default, or by uninstalling the app.\n\nQuestions: $DEV_EMAIL"

        const val TERMS = "This app is provided 'as is' without warranty of any kind. You use it at your own risk.\n\n" +
            "The developer is not responsible for any loss or damage arising from the use of this app.\n\n" +
            "The name, logo and design belong to Suhail Ahamed."

        const val LICENSES = "This app is built only with the Android SDK and Kotlin. It uses no third-party libraries."
    }
}
