package com.example.assistvolume

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var root: LinearLayout
    private lateinit var cur: LinearLayout
    private lateinit var applyColors: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(22), dp(14), dp(32))
        }
        cur = root

        // ---- header with logo ----
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, 0, dp(8))
        }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.logo_app) },
            LinearLayout.LayoutParams(dp(60), dp(60)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        titles.addView(TextView(this).apply {
            text = "Assistive Volume"; setTextColor(Color.WHITE); textSize = 22f
        })
        titles.addView(TextView(this).apply {
            text = "by SN"; setTextColor(0xFF9AA0B4.toInt()); textSize = 13f
        })
        head.addView(titles)
        root.addView(head)

        // ---- main card ----
        section(null)
        cur.addView(Button(this).apply {
            text = "Enable accessibility service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        cur.addView(toggle("Show volume buttons", p.enabled) { on -> setEnabled(on) })
        cur.addView(toggle("Pin buttons at its position", p.pinned) { p.pinned = it; refresh() })
        cur.addView(toggle("Use system volume slider", p.useSystemSlider) { p.useSystemSlider = it; refresh() })

        // ---- auto hide ----
        section("Auto hide")
        cur.addView(toggle("Show slider only when adjusting volume", p.sliderAutoHide) { p.sliderAutoHide = it; refresh() })
        cur.addView(toggle("Hide at once when I touch the screen elsewhere", p.tapOutside) { p.tapOutside = it; refresh() })
        cur.addView(seek("Hide after", 1, 15, p.hideDelay, " s") { p.hideDelay = it })

        // ---- button style ----
        section("Button style")
        cur.addView(radios(listOf("Solid", "Glass", "Neon", "Gradient", "Outline"), p.btnStyle) { p.btnStyle = it; refresh() })
        cur.addView(label("Button shape"))
        cur.addView(radios(listOf("Circle", "Rounded square"), p.btnShape) { p.btnShape = it; refresh() })

        // ---- slider style ----
        section("Slider style")
        cur.addView(radios(listOf("Android", "Android 12", "iOS"), p.style) { p.style = it; refresh() })

        // ---- colors ----
        section("Color settings")
        applyColors = toggle("Apply style colors", p.applyStyleColors) { p.applyStyleColors = it; refresh() }
        cur.addView(applyColors)
        cur.addView(label("Accent color"))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(8)) }
        listOf(
            Color.WHITE, 0xFF1A73E8.toInt(), 0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFEC407A.toInt(),
            0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFF43A047.toInt(), Color.BLACK
        ).forEach { c ->
            chips.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(1), Color.GRAY)
                }
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(8) }
                setOnClickListener {
                    p.bgColor = c; p.applyStyleColors = false
                    applyColors.isChecked = false
                    refresh()
                }
            })
        }
        cur.addView(HorizontalScrollView(this).apply { addView(chips) })

        // ---- button sizes ----
        section("Button settings")
        cur.addView(seek("Transparency", 0, 90, p.btnTransparency, "%") { p.btnTransparency = it; refresh() })
        cur.addView(seek("Button size", 10, 100, p.btnSize, "") { p.btnSize = it; refresh() })
        cur.addView(seek("Icon size", 30, 90, p.iconScale, "%") { p.iconScale = it; refresh() })
        cur.addView(seek("Space between buttons", 0, 40, p.btnGap, "") { p.btnGap = it; refresh() })

        // ---- slider sizes ----
        section("Slider settings")
        cur.addView(seek("Transparency", 0, 90, p.sliderTransparency, "%") { p.sliderTransparency = it; refresh() })
        cur.addView(seek("Height", 100, 600, p.sliderHeight, "") { p.sliderHeight = it; refresh() })
        cur.addView(seek("Width", 30, 120, p.sliderWidth, "") { p.sliderWidth = it; refresh() })

        // ---- power button ----
        section("Power button")
        cur.addView(toggle("Enable power button", p.powerEnabled) { p.powerEnabled = it; refresh() })
        cur.addView(label("Tap: lock screen.  Long press:"))
        cur.addView(radios(listOf("Open power dialog", "Open notifications", "Take screenshot"), p.powerLong) {
            p.powerLong = it; refresh()
        })
        cur.addView(label("Position"))
        cur.addView(radios(listOf("Above", "Below"), p.powerPos) { p.powerPos = it; refresh() })

        // ---- multi sliders ----
        section("Single button - Multi sliders")
        cur.addView(toggle("Enable multi sliders button", p.multiEnabled) { p.multiEnabled = it; refresh() })
        cur.addView(label("Select sliders (tap the button to open them)"))
        Sliders.names.forEachIndexed { i, n ->
            cur.addView(CheckBox(this).apply {
                text = n; setTextColor(Color.WHITE)
                isChecked = (p.multiMask and (1 shl i)) != 0
                setOnCheckedChangeListener { _, c ->
                    p.multiMask = if (c) p.multiMask or (1 shl i) else p.multiMask and (1 shl i).inv()
                    if (i == 4 && c && !Settings.System.canWrite(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Allow 'Modify system settings' for brightness", Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                    }
                    refresh()
                }
            })
        }
        cur.addView(label("Long press on the button:"))
        cur.addView(radios(
            listOf("Hide buttons", "Screen off", "Open notifications", "Mute media volume", "Take screenshot"),
            p.multiLong
        ) { p.multiLong = it; refresh() })

        // ---- proximity ----
        section("Proximity sensor")
        cur.addView(label("Near (phone covered / in pocket)"))
        cur.addView(radios(listOf("No action", "Screen off"), p.proxNear) { p.proxNear = it; refresh() })
        cur.addView(label("Away"))
        cur.addView(radios(listOf("No action", "Screen on"), p.proxAway) { p.proxAway = it; refresh() })

        // ---- config per app ----
        section("Config per app")
        cur.addView(toggle("Enable config per app", p.perApp) { p.perApp = it; refresh() })
        cur.addView(label("Hide buttons, set media volume or brightness automatically when an app opens"))
        cur.addView(Button(this).apply {
            text = "Choose apps"
            setOnClickListener { startActivity(Intent(this@MainActivity, AppConfigActivity::class.java)) }
        })

        // ---- keyboard ----
        section("Sensitive to keyboard")
        cur.addView(toggle("Move buttons up when keyboard opens", p.keyboardSensitive) { p.keyboardSensitive = it; refresh() })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F1115.toInt())
            addView(root)
        })
    }

    private fun setEnabled(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                p.enabled = false
                return
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            p.enabled = true
            refresh()
        } else {
            p.enabled = false
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    private fun refresh() {
        if (p.enabled) startForegroundService(Intent(this, OverlayService::class.java))
    }

    // ---------- UI helpers ----------
    /** Starts a new rounded card; everything added to `cur` afterwards goes inside it. */
    private fun section(title: String?) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(0xFF1A1D24.toInt()); cornerRadius = dp(18).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        if (title != null) {
            card.addView(TextView(this).apply {
                text = title; setTextColor(0xFF8AB4F8.toInt()); textSize = 16f
                setPadding(0, dp(2), 0, dp(6))
            })
        }
        root.addView(card)
        cur = card
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(0xFFB0B4C0.toInt()); textSize = 13f; setPadding(0, dp(10), 0, dp(4))
    }

    private fun radios(options: List<String>, selected: Int, onSelect: (Int) -> Unit): RadioGroup {
        val rg = RadioGroup(this).apply { orientation = LinearLayout.VERTICAL }
        options.forEachIndexed { i, n ->
            rg.addView(RadioButton(this).apply {
                id = View.generateViewId(); text = n; tag = i; setTextColor(Color.WHITE)
            })
        }
        (rg.getChildAt(selected) as RadioButton).isChecked = true
        rg.setOnCheckedChangeListener { g, id -> onSelect(g.findViewById<View>(id).tag as Int) }
        return rg
    }

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 15f
        setPadding(0, dp(8), 0, dp(8))
        isChecked = checked
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun seek(label: String, min: Int, max: Int, cur: Int, suffix: String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        val tv = TextView(this).apply { setTextColor(Color.WHITE); text = "$label: $cur$suffix" }
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                val v = pr + min
                tv.text = "$label: $v$suffix"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv); box.addView(sb)
        return box
    }
}
