package com.example.assistvolume

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.CheckBox
import android.widget.ScrollView

class HideAppsActivity : Activity() {
    private lateinit var p: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        applyAppTheme()
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }
        val selected = p.hideAppSet().toMutableSet()

        val col = lin().apply { setPadding(dp(14), dp(18), dp(14), dp(28)) }
        col.addView(pageTitle("Choose apps", "The shortcut hides only when these apps open"))
        val c = card()
        for ((pkg, label) in apps) {
            c.addRow(CheckBox(this).apply {
                text = label
                setTextColor(C.TEXT)
                textSize = 15f
                setPadding(dp(16), dp(12), dp(16), dp(12))
                isChecked = selected.contains(pkg)
                setOnCheckedChangeListener { _, on ->
                    if (on) selected.add(pkg) else selected.remove(pkg)
                    p.hideApps = selected.joinToString(",")
                }
            })
        }
        col.addView(c)
        setContentView(ScrollView(this).apply {
            if (!C.glass) setBackgroundColor(C.BG)
            addView(col)
        })
        applyBars()
    }
}
