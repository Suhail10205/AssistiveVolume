plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.assistvolume"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.assistvolume"
        minSdk = 26
        targetSdk = 34
        // GitHub run number increases on every build, so new APKs can update the old one
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "2.7"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("avb.keystore")
            storePassword = "android"
            keyAlias = "avb"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
