# Assistive Volume Button
Build with GitHub Actions (see build.yml) or Android Studio.
The APK is signed with the fixed key app/avb.keystore so new builds update the installed app.
