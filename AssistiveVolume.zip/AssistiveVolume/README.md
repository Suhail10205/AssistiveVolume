# Assistive Volume Button (Phase 1)

Build steps
1. Install Android Studio (latest).
2. File > Open > select this AssistiveVolume folder. Let Gradle sync (allow it to download).
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).
4. Open the app, turn on "Show volume buttons", and allow "Display over other apps".

Phase 1 features: floating + / - buttons, volume slider (Android / Android 12 / iOS style),
transparency, size, slider height, button color, pin position, system volume slider toggle.
Drag a button to move the panel (unless pinned).
